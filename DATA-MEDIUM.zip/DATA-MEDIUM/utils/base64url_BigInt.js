const base64url = require('base64url');

// convert base64url to BigInt
function base64urlToBigInt(b64url) {
    const buffer = base64url.toBuffer(b64url);
    hex = '0x'+buffer.toString('hex');
    return BigInt(hex);
}

// convert BigInt to base64url
function bigintToBase64url(bigint) {
    const hex = bigint.toString(16);
    const buffer = Buffer.from(hex, 'hex');
    return base64url(buffer);
}

module.exports = { base64urlToBigInt, bigintToBase64url };