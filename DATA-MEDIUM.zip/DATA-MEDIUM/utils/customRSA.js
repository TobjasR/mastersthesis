const forge = require('node-forge');

// we need to implement a custom signing function, because we only have a quasi public key, 
// so we have to use raw RSA instead and need to en/decode the message hash with PSS manually
function customSignPSS(msgHash, ssk, rsaPssParams) {
    const pss = forge.pss.create(rsaPssParams);
    const encodedHash = pss.encode(msgHash, ssk.n.bitLength());
    const signature = ssk.encrypt(encodedHash, 'RAW');
    return signature;
}

// we also need a custom RSA OAEP decryption fuction, because we only have a quasi public key
function customDecryptOAEP(ciphertext, svk, rsaOAEPParams) {
    const encodedMessage = svk.encrypt(ciphertext, "RAW");
    const message = forge.pkcs1.decode_rsa_oaep(svk, encodedMessage, rsaOAEPParams);
    return message;
}

module.exports = { customSignPSS, customDecryptOAEP };