const { base64urlToBigInteger, bigIntegerToBase64url } = require('./base64url_BigInteger.js');
const forge = require('node-forge');
const BigInteger = forge.jsbn.BigInteger;
const ONE = BigInteger.ONE;
const TWO = new BigInteger("2");

// Generate a private key from p and q
function privateKeyFromPQ(p, q) {
    // Calculate n, phi(n), d, dp, dq, and qi from p and q
    const n = p.multiply(q); // Public modulus
    const phi = p.subtract(ONE).multiply(q.subtract(ONE)); // Euler's totient function
    const e = new BigInteger("65537"); // Public exponent
    const d = e.modInverse(phi); // Private exponent
    const dp = d.mod(p.subtract(ONE));
    const dq = d.mod(q.subtract(ONE));
    const qi = q.modPow(p.subtract(TWO), p);
    const privKey = forge.rsa.setPrivateKey(n, e, d, p, q, dp, dq, qi);
    return privKey;
}
module.exports = privateKeyFromPQ;