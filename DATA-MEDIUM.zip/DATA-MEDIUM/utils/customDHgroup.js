const crypto = require('crypto-browserify');
// Custom Diffie-Hellman group creation function for Browser and Node.js
function createDiffieHellmanGroup(type) {
    if ("modp14" !== type) {
        throw new Error("Only modp14 is supported at the moment.");
    }
    const MODP14_P = "ffffffffffffffffc90fdaa22168c234c4c6628b80dc1cd129024e088a67cc74"+
                     "020bbea63b139b22514a08798e3404ddef9519b3cd3a431b302b0a6df25f1437"+
                     "4fe1356d6d51c245e485b576625e7ec6f44c42e9a637ed6b0bff5cb6f406b7ed"+
                     "ee386bfb5a899fa5ae9f24117c4b1fe649286651ece45b3dc2007cb8a163bf05"+
                     "98da48361c55d39a69163fa8fd24cf5f83655d23dca3ad961c62f356208552bb"+
                     "9ed529077096966d670c354e4abc9804f1746c08ca18217c32905e462e36ce3b"+
                     "e39e772c180e86039b2783a2ec07a28fb5c55df06f4c52c9de2bcbf695581718"+
                     "3995497cea956ae515d2261898fa051015728e5a8aacaa68ffffffffffffffff";
    return crypto.createDiffieHellman(MODP14_P, 'hex');
}
module.exports = createDiffieHellmanGroup;