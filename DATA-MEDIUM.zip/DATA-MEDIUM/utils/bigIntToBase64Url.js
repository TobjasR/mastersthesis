const base64url = require('base64url');

function bigIntToBase64Url(bigInt) {
    // Convert BigInteger to a byte array
    const byteArray = bigInt.toByteArray();
    // Convert byte array to buffer
    const buffer = Buffer.from(byteArray);
    let base64Url = base64url(buffer);
    return base64Url;
}

module.exports = bigIntToBase64Url;