// Hashes a blob with SHA256
// test if this is running in a browser or in Node.js
const isBrowser = typeof window !== 'undefined';
const crypto = (isBrowser)? window.crypto : require('crypto');

async function hashWithSHA256(blob) {
    if (isBrowser) {
        const encoder = new TextEncoder();
        const data = encoder.encode(blob);
        const hashBuffer = await crypto.subtle.digest('SHA-256', data);
        const hashArray = Array.from(new Uint8Array(hashBuffer)); 
        const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join(''); 
        return hashHex;
    } else {
        const hash = crypto.createHash('sha256');
        hash.update(blob);
        const hashHex = hash.digest('hex');
        return hashHex;
    }
}
module.exports = hashWithSHA256;