const forge = require('node-forge');
const BigInteger = forge.jsbn.BigInteger;
const ZERO = BigInteger.ZERO;
const ONE = BigInteger.ONE;

function deriveRSAVerifierKey(d, phi) {
    if (!(d.gcd(phi).equals(ONE))) {
        throw new Error("Custom exponent is not coprime with (p-1)(q-1)");
    }
    const e = d.modInverse(phi);
    if (e.equals(ZERO)) {
        throw new Error("Invalid verifier key");
    }
    return e.toString(10);
}
module.exports = deriveRSAVerifierKey;