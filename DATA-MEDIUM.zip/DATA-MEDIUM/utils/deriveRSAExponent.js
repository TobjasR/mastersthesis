const forge = require('node-forge');
const BigInteger = forge.jsbn.BigInteger;
const ONE = BigInteger.ONE;

// Derive RSA exponent of length nBits - 1 from OPRF output as seed
function deriveRSAExponent(seed, nBits) {
    const expBits = nBits - 1;
    // Convert Uint8Array to Buffer
    const seed_buf = Buffer.from(seed);
    // desired bit length is in bytes (accounting for the leading 0-byte)
    const empty = Buffer.alloc(0);
    const info = 'RSA exponent derivation';
    const bytes = Math.ceil(expBits / 8);
    // Use HKDF to expand the OPRF output to the desired length
    // const expanded = crypto.hkdfSync('sha256', buf, empty, info, bytes);
    const expanded = forge.pbkdf2(seed_buf, empty, 1000, bytes, 'sha256');
    // Convert the expanded ascii string to a hexadecimal string
    const expanded_buf = Buffer.from(expanded, 'ascii');
    // Convert to BigInt using the hexadecimal string
    let exp = new BigInteger(expanded_buf.toString('hex'), 16);
    // Ensure the number is of the desired bit length
    const shiftBits = exp.bitLength() - expBits;
    exp = exp.shiftRight(shiftBits);
    console.log("exponent length is:", exp.bitLength(), "bits", 
                "\nand should be:", expBits, "bits");
    // Ensure the number is odd
    exp = exp.or(ONE);
    return exp.toString(10);
}
module.exports = deriveRSAExponent;