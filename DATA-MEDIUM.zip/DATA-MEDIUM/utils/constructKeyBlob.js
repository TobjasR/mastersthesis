const forge = require('node-forge');

function constructKeyBlob(n, e) {
    // Convert "ssh-rsa" to binary
    const keyType = Buffer.from('ssh-rsa');
    // Convert modulus and exponent to binary using forge
    const modulusBuffer = Buffer.from(forge.util.hexToBytes(n.toString(16)));
    const exponentBuffer = Buffer.from(forge.util.hexToBytes(e.toString(16)));
    // Concatenate the buffers
    return Buffer.concat([keyType, exponentBuffer, modulusBuffer]);
}

module.exports = constructKeyBlob;