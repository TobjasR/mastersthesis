const forge = require('node-forge');
const BigInteger = forge.jsbn.BigInteger;
const ZERO = BigInteger.ZERO;
const ONE = BigInteger.ONE;
const TWO = new BigInteger("2");

function recoverPQ(n, e, d) {
    // Step 1: Let k = de – 1. If k is odd, then go to the error handling at the end
    const k = d.multiply(e).subtract(ONE);
    if (k.isEven()) {
        let r = k.clone();
        let t = ZERO;
        // Step 2: Write m as m = 2tr, where r is the largest odd integer dividing m, and t ≥ 1.
        while (r.isEven()) {
            r = r.divide(TWO);
            t = t.add(ONE);
        }
        // Step 3: For i = 1 to 100 do:
        for (let i = 1; i <= 100; i++) {
            // 3a: Generate a random integer g in the range [0, n−1].
            let randomBytes = forge.random.getBytesSync(n.bitLength() / 8);
            let hexString = forge.util.bytesToHex(randomBytes);
            let g = new forge.jsbn.BigInteger(hexString, 16);
            let y = g.modPow(r, n);
            // 3b: If y = 1 or y = n – 1, then continue to the next iteration.
            if (y.equals(ONE) || y.equals(n.subtract(ONE))) {
                continue;
            }
            // 3c: For j = 1 to t – 1 do:
            for (let j = 0; j < t; j++) {
                let x = y.modPow(TWO, n);
                // 3d: If x = 1, then the prime factors have been found.
                if (x.equals(ONE)) {
                    let p = y.subtract(ONE).gcd(n);
                    let q = n.divide(p);
                    return [p, q];
                }
                // 3e: If x = n – 1, then break and go to the next iteration.
                if (x.equals(n.subtract(ONE))) {
                    break;
                }
                y = x;
            }
        }
    }
    // If the function hasn't returned by this point, throw an error.
    throw new Error("Cannot compute P and Q");
}

module.exports = recoverPQ;