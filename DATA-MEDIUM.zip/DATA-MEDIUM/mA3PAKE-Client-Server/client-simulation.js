const forge = require('node-forge');
const pki = forge.pki;
const BigInteger = forge.jsbn.BigInteger;
const ONE = BigInteger.ONE;
const crypto = require('crypto-browserify');
const generateSafePrimeKey = require('./generateSafePrimeKey.js');
const hashWithSHA256 = require('../utils/hashWithSHA256.js');
const generatefingerprintRandomart = require('../utils/fingerprint.js');
const oprfClient = require('../utils/oprfClient.js');
const deriveRSAExponent = require('../utils/deriveRSAExponent.js');
const deriveVerifierKey = require('../utils/deriveVerifierKey.js');
const createDiffieHellmanGroup = require('../utils/customDHgroup.js');
const recoverPQ = require('../utils/recoverPQ.js');
const { exit } = require('node:process');
const { customSignPSS, customDecryptOAEP } = require('../utils/customRSA.js');

const radix = 10; // number base (decimal/hex/binary)
const nBits = 1024 ; // RSA modulus size (bits)
// check if this is running in a browser or in Node.js
const isBrowser = typeof window !== 'undefined';
// number of threads to use for key generation (number of detected CPU cores)
const threads = isBrowser ? navigator.hardwareConcurrency : require('os').cpus().length;; 
// RSA-OAEP and RSA-PSS parameters
const rsaOAEPParams = { md: forge.md.sha256.create() };
const rsaPssParams = {
    md: forge.md.sha256.create(),
    mgf: forge.mgf.mgf1.create(forge.md.sha256.create()),
    saltLength: 32
}
const pssObj = forge.pss.create(rsaPssParams);
const horizonalLine = "--------------------------------------------------------------------------------";

async function preparationPhase() {
    console.log(`### PREPARATION PHASE ###
Before Alice can register with Bob, she needs to generate a key-pair generator base.
In case of RSA, the key base consists of (p,q), where both are safe primes.`);
    // gemerate RSA key base
    console.log("Starting RSA key base generation for", nBits, "bit RSA with", threads, "threads ...");
    const keybase = await generateSafePrimeKey(nBits, threads);
    console.log(`Successfully generated RSA key base.`);
    const p = new BigInteger(keybase.p);
    const q = new BigInteger(keybase.q);
    const n = p.multiply(q);
    const n_buf = Buffer.from(forge.util.hexToBytes(n.toString(16)));
    const fingerprint = await hashWithSHA256(n_buf);
    console.log("hashed modulus:", fingerprint);
    const fingerprintRandomart = generatefingerprintRandomart(fingerprint);
    console.log(`Key base fingerprintRandomart (hashed modulus) as randomart:\n${fingerprintRandomart}
Alice should remember her fingerprint (as randomart).
Optionally, she can store the key base in a key vault app on a trusted device,
so she can later use it for registrations with other servers with the same fingerprint.
Instead of the key vault:
She can also recover p and q from any verifier exponent v and corresponding secret exponent s.
For this, she permits the server to send her the verifier exponent v after successful authentication.
This permit is part of the regsitration and optionally commitment (registration authority) process.`);
    return keybase;
}
// REGISTRATION PHASE
async function registrationPhase(browser, user) {
    console.log("### REGISTRATION PHASE ###");
    const keybase = browser.keybase;
    const [registrationServer, username, password, svkRetrieval, oprfServer] =
        [user.registrationServer, user.username, user.password, user.svkRetrieval, user.oprfServer];
    const p = new BigInteger(keybase.p);
    const q = new BigInteger(keybase.q);
    const n = p.multiply(q);
    const phi = p.subtract(ONE).multiply(q.subtract(ONE));
    console.log("Now, Alice is ready to register with Bob's server,", registrationServer, ",",
            "\nand clicks on the registration link: https://", registrationServer, "/register",
            "\nHer browser sends a normal GET request for that URL to the server (HTTP Request 1).");
    console.log(horizonalLine); 
    ////////////////////////////////////////////////////////
    console.log("Bob's server receives HTTP Request 1. ",
            "\nBecause it's for the /register endpoint, he initiates a registration process.");
    let messageType = "user registration invitation";
    const oprfServerBob = "oprf.example.net";
    console.log("\nHe generates a Diffie-Hellman key pair, e.g. using Modp14 …");
    const keyexchangeType = "modp14";
    const keyexchangeServer = createDiffieHellmanGroup(keyexchangeType);
    const keyexchangePubkeyServerBuffer = keyexchangeServer.generateKeys();
    const keyexchangePubkeyServer = keyexchangePubkeyServerBuffer.toString('hex');
    console.log("Bob's DH public key:", keyexchangePubkeyServer);
    console.log("Regarding OPRF, Bob can suggest his default OPRF server to Alice (she can customize):", oprfServerBob,
            "\nNow, he replies (HTTP Request 1) with an authorization header containing:",
            "\n - the message type (user registration invitation),\n - his server name\n - his default OPRF server,",
            "\n - if he's willing to send his (encrypted) svk after successful authentication or not ",
            "\n - his DH public and \n - a timestamp.");
    let timestamp = Date.now();
    let registrationMessage = { messageType, timestamp, registrationServer, 
                                svkRetrieval, oprfServer: oprfServerBob,
                                keyexchangeType, keyexchangePubkeyServer};
    console.log("Registration request message (HTTP Response 1):", registrationMessage);
    console.log(horizonalLine);
    ////////////////////////////////////////////////////////
    console.log("Alice's browser receives the HTTP authorization header with the rgistration invitation.",
            "\nHe verifies the timestamp and asks user Alice if she wants to register with", registrationServer,
            "\nAlice confirms and her browser asks her if she wants to use the default OPRF server", oprfServerBob,
            "\nThe browser might also be configured to override it with a custom OPRF server by default.",
            "\n(In any case, her choice should be based on the trustworthiness of the OPRF server,",
            "\nas well as her privacy and availability preferences.)");
    const oprfURL = "https://" + oprfServer;
    console.log("She chose a custom OPRF server", oprfServer);
    // This can be any OPRF client identifier (e.g. a random alphanumeric string, email address, username, etc.)
    const oprfID = "0x0pRfC1i3ntId"; 
    console.log("Her browser checks if the OPRF server is available, generates a random OPRF client ID,",
            "\ndisplays it and waits for her to confirm:", oprfID,
            "\nIn most cases, she will just confirm, but she can also customize it (e.g. her email address or username).",
            "\nIn case Bob's server offers svkRetrieval, Alice can decide if wants to use it to recover her key base later.",
            "\nAfter OPRF server and client ID selection/confirmation, and svkRetrieval decision,",
            "\nAlice' browser promts her to enter her username and password.");
    console.log("Alice enters her username and password:\n", username, "\n", password);
    console.log("Her browser is starting the OPRF evaluation of her password, now ...");
    let passseed;
    try {
        passseed = await oprfClient(oprfURL, oprfID, password, "hex");
        console.log("OPRF has been successfully evaluated. The password-derived seed (passseed) is:\n", 
        Buffer.from(passseed).toString('hex'));
    } catch (error) {
        console.error("An error occurred:", error);
    }
    console.log("Starting derivation of secret (signing) exponent s from passseed ...");
    const s = new BigInteger(deriveRSAExponent(passseed, nBits - 1));
    console.log("Exponent s has been derived:", s.toString(radix));
    console.log("Starting derivation of verifier exponent v from s and phi ...");
    const v = new BigInteger(deriveVerifierKey(s, phi));
    console.log("Exponent v has been derived:", v.toString(radix));
    console.log("Browser creates the signing key ssk (s, n) ...");
    const ssk = pki.setRsaPublicKey(n, s);
    console.log("…and verifier key svk (v, n) ...");
    const svk = pki.setRsaPublicKey(n, v);
    console.log("ssk and svk have been created.");
    console.log("Alice's browser generates a Diffie-Hellman key pair …");
    const keyexchangeClient = createDiffieHellmanGroup(keyexchangeType);
    const keyexchangePubkeyClientBuffer = keyexchangeClient.generateKeys();
    const keyexchangePubkeyClient = keyexchangePubkeyClientBuffer.toString('hex');
    console.log("Alice's DH public key:", keyexchangePubkeyClient);
    console.log("Finalizing the Diffie-Hellman key exchange ...");
    const keyexchangeSecretClient = keyexchangeClient.computeSecret(keyexchangePubkeyServerBuffer, null, 'hex');
    console.log("Alice's shared secret:", keyexchangeSecretClient);
    console.log("Alice's browser encrypts svk with the shared DH-Key ...");
    const svkString =  JSON.stringify({n: svk.n.toString(), e: svk.e.toString()});
    console.log("svkString:", svkString);
    const svkBuffer = forge.util.createBuffer(svkString);
    // hash DH-Key to get AES-256 key
    const clientAESkey = await hashWithSHA256(Buffer.from(keyexchangeSecretClient, 'hex'));
    const clientAESkeyBinary = forge.util.hexToBytes(clientAESkey);
    console.log("Alice' AES key:", clientAESkey.toString('hex'));
    var verifierKeyEncryptedIvBytes = forge.random.getBytesSync(16);
    var verifierKeyEncryptedIV = forge.util.bytesToHex(verifierKeyEncryptedIvBytes);
    const svkCipher = forge.cipher.createCipher('AES-CBC', clientAESkeyBinary);
    svkCipher.start({iv: verifierKeyEncryptedIvBytes});
    svkCipher.update(svkBuffer);
    svkCipher.finish();
    const verifierKeyEncryptedBuffer = svkCipher.output;
    var verifierKeyEncrypted = verifierKeyEncryptedBuffer.toHex();
    console.log("Encrypted verifier key:", verifierKeyEncrypted);
    console.log("Alice' browser updates the registration message:",
        "\n - updates the message type (user registration request),",
        "\n - adds her username,\n - updates custom OPRF server,",
        "\n - dis/allow svkRetrieval \n - adds Client's DH public key,",
        "\n - adds her fingerprint (hashed Modulus) and\n - adds the encrypted verifier key (and IV):");
    messageType = "user registration request";
    const n_buf = Buffer.from(n.toString(16), 'hex');
    const fingerprint = await hashWithSHA256(n_buf);
    console.log("hashed modulus:", fingerprint);
    registrationMessage = { messageType, timestamp, registrationServer, user, fingerprint,
                            svkRetrieval, oprfServer, oprfID, 
                            verifierKeyEncrypted, verifierKeyEncryptedIV, 
                            keyexchangeType, keyexchangePubkeyServer, keyexchangePubkeyClient};
    console.log("Updated registration message:", registrationMessage);
    console.log("Alice browser signs the registration message with ssk ...");
    const regMsgString = JSON.stringify(registrationMessage);
    const regMsgMd = forge.md.sha256.create();
    const regMsgHash = regMsgMd.update(regMsgString);
    const signatureClient = customSignPSS(regMsgHash, ssk, rsaPssParams);
    const signatureClientBuffer = forge.util.createBuffer(signatureClient);
    console.log("Alice' signature:", signatureClientBuffer.toHex());
    console.log("HTTP Request 2:");
    console.log("Alice's browser sends the updated registration message (including signature) to Bob's server.");
    console.log(horizonalLine);
    ////////////////////////////////////////////////////////
    console.log("Bob's server receives the user registration request message (HTTP Request 2) and checks:", 
            "\n - if the registration servername, keyexchange server public key and timestamp are matching,",
            "\n - if the username is available (ideally to be handled by the application prior to the registration process).",
            "\nIf everything matches, he starts processing Alice' registration request.",
            "\nHe enters the username, fingerprint, OPRF server and client ID into the user database,",
            "\nand updates the registration process with the provided information...");
    console.log("Bob's server uses Alice' DH public key to compute the shared secret ...");
    const keyexchangeSecretServer = keyexchangeServer.computeSecret(keyexchangePubkeyClientBuffer, null, 'hex');
    console.log("Bobs's shared secret is the same as Alice':", keyexchangeSecretServer === keyexchangeSecretClient);
    console.log("Bob's server decrypts the verifier key with the shared DH-Key ...",
                "For this, he needs to hash the shared DH-Key to get the AES-256 key.");
    const serverAESkey = await hashWithSHA256(Buffer.from(keyexchangeSecretServer, 'hex'));
    const serverAESkeyBytes = forge.util.hexToBytes(serverAESkey);
    console.log("Bob's AES key:", serverAESkey.toString('hex'));
    const svkDecipher = forge.cipher.createDecipher('AES-CBC', serverAESkeyBytes);
    svkDecipher.start({iv: verifierKeyEncryptedIvBytes}); 
    svkDecipher.update(verifierKeyEncryptedBuffer);
    svkDecipher.finish();
    const svkStringDecrypted = svkDecipher.output.toString();
    console.log("Decrypted verifier key:", svkStringDecrypted);
    console.log("Bob's server decrypted the verifier key successfully:", svkStringDecrypted === svkString);
    console.log("Bob's server calculates the fingerprint (hashed modulus) from the verifier key ...");
    const svkJSON = JSON.parse(svkStringDecrypted);
    console.log("svkJSON:", svkJSON);
    svkN = new BigInteger(svkJSON.n);
    const verifierKeyN_buf = Buffer.from(svkN.toString(16), 'hex');
    const fingerprint2 = await hashWithSHA256(verifierKeyN_buf);
    console.log("fingerpring2:", fingerprint2);
    console.log("Bob's server checks if the fingerprint matches the one in the registration message:", 
            fingerprint2 === fingerprint);
    console.log("Bob's server checks if the signature is valid ...");
    const verifiedClient = svk.verify(regMsgHash.digest().bytes(), signatureClient, pssObj);
    console.log("Bob's server was able to verify Alice' signature using his decrypted verifier key (svk):", 
            verifiedClient,
            "\nHe adds the fingerprint and the decrypted verifier key to Alice's database record,",
            "\nand signs the registration message (hash) himself (using svk),",
            "\nand encrypts his signature with the shared AES-key:");
    const signatureServer = customSignPSS(regMsgHash, svk, rsaPssParams);
    const signatureServerBuffer = forge.util.createBuffer(signatureServer);
    console.log("Bob's signature:", signatureServerBuffer.toHex());
    console.log("... and AES-encrypts his signature with the DH-Key");
    var signatureServerEncryptedIvBytes = forge.random.getBytesSync(16);
    var signatureServerEncryptedIV = forge.util.bytesToHex(signatureServerEncryptedIvBytes);
    const signatureCipher = forge.cipher.createCipher('AES-CBC', serverAESkeyBytes);
    signatureCipher.start({iv: signatureServerEncryptedIvBytes});
    signatureCipher.update(signatureServerBuffer);
    signatureCipher.finish();
    var signatureServerEncryptedBuffer = signatureCipher.output;
    var signatureServerEncrypted = signatureServerEncryptedBuffer.toHex();
    console.log("Bob's AES-encrypted signature:", signatureServerEncrypted);
    console.log("Finally, he sends the confirmation message with AES-encrypted signature (and IV) to Alice's browser.");
    messageType = "user registration confirmation";
    registrationMessage = { messageType, timestamp, registrationServer, user, fingerprint, 
                            signatureServerEncrypted, signatureServerEncryptedIV};
    console.log("Confirmation message (HTTP Response 2):\n", registrationMessage);
    console.log(horizonalLine);
    ////////////////////////////////////////////////////////
    console.log("Alice's browser decrypts the AES-encrypted signature with her DH-Key ...");
    const signatureServerFromHex = forge.util.hexToBytes(registrationMessage.signatureServerEncrypted);
    const signatureServerFromHexBuffer = forge.util.createBuffer(signatureServerFromHex);
    const signatureDecipher = forge.cipher.createDecipher('AES-CBC', clientAESkeyBinary);
    signatureDecipher.start({iv: signatureServerEncryptedIvBytes});
    signatureDecipher.update(signatureServerFromHexBuffer);
    signatureDecipher.finish();
    const signatureServerDecrypted = signatureDecipher.output;
    const signatureServerBytes = signatureServerDecrypted.bytes(); // Get the binary representation
    console.log("Alice decrypted Bob's signature:", forge.util.bytesToHex(signatureServerBytes));
    console.log("... and now verifies it with her signing key ssk.");
    const verifiedServerSignature = ssk.verify(regMsgHash.digest().bytes(), signatureServerBytes, pssObj);
    console.log("Alice' browser was able to verify Bob's signature:", verifiedServerSignature,
            "\n... and displays a confirmation message to Alice, that she has successfully registered with", 
            registrationServer);
    console.log("Alice should remember her fingerprintRandomart and keep the registration message for later use.",
            "\nShe can now forget her key base, the passseed, OPRF server and client ID, etc.",
            "\nshe only needs to remember her username, password and fingerprint (randomart).");
    console.log("\nOptional steps: a) Bob sends a confirmation email to Alice.",
                "\nb) Alice commits to her verifier key via a trusted regisstration authority.");
    console.log(horizonalLine);
    return {fingerprint, svkString, oprfID, svkRetrieval};
}
// AUTHENTICATION PHASE
async function authenticationPhase(client, server) {
    const [registrationServer, username, password, svkRetrieval] 
     = [client.registrationServer, client.username, client.password, client.svkRetrieval];
    const [fingerprint, svkStr, oprfServer, oprfID]
     = [server.fingerprint, server.svkString, server.oprfServer, server.oprfID];
    svkJSON = JSON.parse(svkStr);
    const svk = pki.setRsaPublicKey(new BigInteger(svkJSON.n), new BigInteger(svkJSON.e));
    console.log("\n### AUTHENTICATION PHASE ###");
    const authenticationServer = "bob.example.com";
    console.log("Alice wants to log into her account with " + authenticationServer + ", again.",
            "\nShe clicks on the login link: https://", registrationServer, "/login",
            "\nand her browser sends a regular GET request for that URL to Bob's server (HTTP Request 1).");
    console.log(horizonalLine);
    ////////////////////////////////////////////////////////
    console.log("Bob's server receives HTTP Request 1. ",
            "\nBecause it's for the /login endpoint, he initiates a login/authentication process.");
    messageType = "user login invitation";
    const nonceServerBytes = forge.random.getBytesSync(32);
    const nonceServer = forge.util.bytesToHex(nonceServerBytes);
    timestamp = Date.now()
    loginMessage = {messageType, timestamp, authenticationServer, 
                    nonceServer
                };
    console.log("Bob's server generates a nonce and a timestamp,",
            "\nand sends a HTTP authorization header with an login invitation to Alice's browser (HTTP Response 1):\n", 
            loginMessage);
    console.log(horizonalLine);
    ////////////////////////////////////////////////////////
    console.log("Alice's browser receives the HTTP authorization header with the login message,",
            "\nand asks her to enter her if she wants to login with", authenticationServer,
            "\nIf she confirms, he prompt her for her username and password.",
            "\nShe enters the same username and password as before:\n",
            "username:", username, "\npassword:", password);
    messageType = "user login request";
    const nonceClientBytes = forge.random.getBytesSync(32);
    const nonceClient = forge.util.bytesToHex(nonceClientBytes);
    loginMessage = {messageType, timestamp, authenticationServer, username, 
                    nonceServer, nonceClient
                };
    console.log("Alice's browser updates the loginMessage with the username and a nonce,",
            "\nand sends it to Bob's server (HTTP Request 2):\n", loginMessage);
    console.log(horizonalLine);
    ////////////////////////////////////////////////////////
    console.log("Bob's server receives the login request and checks if the username exists in his database.",
            "\nIf so, Bob's server creates an login message containing:",
            "\nAlice' username, her OPRF server and client ID, her modulus and her fingerprint.");
    messageType = "user login challenge";
    const modulus = svk.n.toString();
    loginMessage = {messageType, timestamp, authenticationServer, username, fingerprint, modulus, 
                    svkRetrieval, oprfServer, oprfID,
                    nonceServer, nonceClient 
                };
    console.log("Bob's server sends the login challenge message to Alice's browser (HTTP Response 2):\n", 
                loginMessage);
    console.log(horizonalLine);
    ////////////////////////////////////////////////////////
    console.log("\nAlice's browser receives the login challenge, validates it, and calculates the modulus fingerprint,",
            "\ncompares it with the one in the message, displays it's randomart image and asks Alice to verify it.",
            "\nIf Alice confirms, her browser now starts the OPRF evaluation of her password ...");
    let passseed; 
    const oprfURL = "https://" + oprfServer;
    try {
        passseed = await oprfClient(oprfURL, oprfID, password, "hex");
        console.log("OPRF has been evaluated. Passseed:", Buffer.from(passseed).toString('hex'));
    } catch (error) {
        console.error("An error occurred:", error);
    }
    console.log("Alice's browser derives the secret exponent s from the passseed ...");
    const s = new BigInteger(deriveRSAExponent(passseed, nBits - 1));
    console.log("Exponent s has been derived:", s.toString(radix));
    console.log("Construct ssk from s and n ...");
    const n = new BigInteger(modulus);
    const ssk = pki.setRsaPublicKey(n, s);
    console.log("Alice's browser signs the authentication message with ssk ...");
    const loginMsgString = JSON.stringify(loginMessage);
    const md2 = forge.md.sha256.create();
    const loginMsgHash = md2.update(loginMsgString);
    const signatureClientBytes = customSignPSS(loginMsgHash, ssk, rsaPssParams);
    const signatureClient = forge.util.bytesToHex(signatureClientBytes);
    console.log("Alice's signature:", signatureClient);
    console.log("Alice' browser creates a random AES key and OAEP-encrypts it with ssk ...");
    const aesKey = forge.random.getBytesSync(32);
    console.log("Alice's AES key:", aesKey.toString('hex'));
    const aesKeyEncryptedBytes = ssk.encrypt(aesKey, "RSA-OAEP", rsaOAEPParams);
    const encryptedKey = forge.util.bytesToHex(aesKeyEncryptedBytes);
    console.log("Alice's browser updates the login message with the signature and the encrypted AES key ...");
    messageType = "user login response";
    loginMessage = {messageType, timestamp, authenticationServer, username, fingerprint, modulus, 
                    svkRetrieval, oprfServer, oprfID,
                    nonceServer, nonceClient,
                    signatureClient, encryptedKey
                };
    console.log("Alice's browser sends the login response (and signature) to Bob's server (HTTP Request 3):\n",
                loginMessage);
    console.log(horizonalLine);
    ////////////////////////////////////////////////////////
    console.log("Bob's server receives the login response and verifies the signature with Alice' verifier key svk.",
            "\nIf the signature is valid, he sends a login confirmation message to Alice's browser.",
            "\nIf Alice has registered with svkRetrieval and requesets it now, he includes the encrypted svk.");
    const signatureClientBytesFromHex = forge.util.hexToBytes(loginMessage.signatureClient);
    const md3 = forge.md.sha256.create();
    const loginMsgHash2 = md3.update(loginMsgString);
    const verifiedClient2 = svk.verify(loginMsgHash.digest().bytes(), signatureClientBytes, pssObj);
    console.log("Bob's server was able to verify Alice' signature:", verifiedClient2);
    console.log("He decrypts the encrypted AES key with svk ...");

    const encryptedKeyFromHex = forge.util.hexToBytes(loginMessage.encryptedKey);
    const aesKey2DecryptedBytes = customDecryptOAEP(encryptedKeyFromHex, svk, rsaOAEPParams);
    const aesKey2Decrypted = forge.util.bytesToHex(aesKey2DecryptedBytes);
    console.log("Bob's server decrypted the AES key successfully:", aesKey2Decrypted);
    console.log("He encrypts svk with the AES key ...");
    const svkString = JSON.stringify({n: svk.n.toString(), e: svk.e.toString()});
    const svkBuffer = forge.util.createBuffer(svkString);
    const aesKey2DecryptedBinary = forge.util.hexToBytes(aesKey2Decrypted.toString('hex'));
    const svkCipher = forge.cipher.createCipher('AES-CBC', aesKey2DecryptedBinary);
    var verifierKeyEncryptedIvBytes = forge.random.getBytesSync(16);
    var verifierKeyEncryptedIV = forge.util.bytesToHex(verifierKeyEncryptedIvBytes);
    svkCipher.start({iv: verifierKeyEncryptedIvBytes});
    svkCipher.update(svkBuffer);
    svkCipher.finish();
    const verifierKeyEncryptedBuffer = svkCipher.output;
    var verifierKeyEncrypted = verifierKeyEncryptedBuffer.toHex();
    console.log("Bob's AES-encrypted verifier key:", verifierKeyEncrypted);
    console.log("Bob's server updates the login message with the encrypted verifier key and IV and signs it ...");
    messageType = "user login confirmation";
    loginMessage = {messageType, timestamp, authenticationServer, username, fingerprint, 
                    nonceServer, nonceClient,
                    verifierKeyEncrypted, verifierKeyEncryptedIV
                };
    const loginMsgString2 = JSON.stringify(loginMessage);
    const md4 = forge.md.sha256.create();
    const loginMsgHash3 = md4.update(loginMsgString2);
    const signatureServer2Bytes = customSignPSS(loginMsgHash3, svk, rsaPssParams);
    const signatureServer2 = forge.util.bytesToHex(signatureServer2Bytes);
    console.log("Bob's signature:", signatureServer2);
    console.log("Bob's server encrypts the signature with the AES key ...");
    const signatureServer2Buffer = forge.util.createBuffer(signatureServer2Bytes);
    const signatureCipher2 = forge.cipher.createCipher('AES-CBC', aesKey2DecryptedBinary);
    var signatureServerEncryptedIvBytes = forge.random.getBytesSync(16);
    var signatureServerEncryptedIV = forge.util.bytesToHex(signatureServerEncryptedIvBytes);
    signatureCipher2.start({iv: signatureServerEncryptedIvBytes});
    signatureCipher2.update(signatureServer2Buffer);
    signatureCipher2.finish();
    var signatureServerEncryptedBytes = signatureCipher2.output;
    var signatureServerEncrypted = forge.util.bytesToHex(signatureServerEncryptedBytes);
    console.log("Bob's AES-encrypted signature:", signatureServerEncrypted);
    console.log("Bob's server updates the login message with the encrypted signature and IV ...");
    loginMessage = {messageType, timestamp, authenticationServer, username, fingerprint, 
                    nonceServer, nonceClient,
                    verifierKeyEncrypted, verifierKeyEncryptedIV,
                    signatureServerEncrypted, signatureServerEncryptedIV
                };
    
    console.log("Bob's server updates the login confirmation with the encrypted svk and signature, and IVs ...");
    console.log("He sends the login confirmation message to Alice's browser (HTTP Response 3):\n",
                loginMessage);
    console.log(horizonalLine);
    ////////////////////////////////////////////////////////
    console.log("Alice's browser receives the login confirmation and decrypts the encrypted signature with her AES key ...");
    const signatureServerFromHex2 = forge.util.hexToBytes(loginMessage.signatureServerEncrypted);
    const signatureServerIVFromHex2 = forge.util.hexToBytes(loginMessage.signatureServerEncryptedIV);
    const signatureDecipher2 = forge.cipher.createDecipher('AES-CBC', aesKey2DecryptedBinary);
    signatureDecipher2.start({iv: signatureServerIVFromHex2});
    signatureDecipher2.update(forge.util.createBuffer(signatureServerFromHex2));
    signatureDecipher2.finish();
    const signatureServerDecrypted2Buffer = signatureDecipher2.output;
    const signatureServerDecrypted2Bytes = signatureServerDecrypted2Buffer.bytes();
    const signatureServerDecrypted2 = forge.util.bytesToHex(signatureServerDecrypted2Bytes);
    console.log("Alice decrypted Bob's signature:", signatureServerDecrypted2);
    console.log("... and now verifies it with her signing key ssk.");
    const md5 = forge.md.sha256.create();
    const loginMsgHash4 = md5.update(loginMsgString2);
    const verifiedServerSignature2 = ssk.verify(loginMsgHash4.digest().bytes(), signatureServerDecrypted2Bytes, pssObj);
    console.log("Alice's browser decrypts the encrypted verifier key with her AES key ...");
    const verifierKeyEncryptedFromHex = forge.util.hexToBytes(loginMessage.verifierKeyEncrypted);
    const verifierKeyEncryptedIVFromHex = forge.util.hexToBytes(loginMessage.verifierKeyEncryptedIV);
    const verifierKeyDecipher = forge.cipher.createDecipher('AES-CBC', aesKey2DecryptedBinary);
    verifierKeyDecipher.start({iv: verifierKeyEncryptedIVFromHex});
    verifierKeyDecipher.update(forge.util.createBuffer(verifierKeyEncryptedFromHex));
    verifierKeyDecipher.finish();
    const verifierKeyDecryptedBuffer = verifierKeyDecipher.output;
    const verifierKeyDecrypted = verifierKeyDecryptedBuffer.toString();
    console.log("Alice's browser decrypted the verifier key successfully:", verifierKeyDecrypted);
    console.log("Alice's browser checks the modulus of the decrypted verifier key against the one in the login message ...");
    const verifierKeyDecryptedJSON = JSON.parse(verifierKeyDecrypted);
    const verifierKeyDecryptedN = new BigInteger(verifierKeyDecryptedJSON.n);
    console.log("The modulus matches the one in the login message:", verifierKeyDecryptedN.equals(ssk.n));
    const verfierKeyDecryptedE = new BigInteger(verifierKeyDecryptedJSON.e);
    const v = verfierKeyDecryptedE;
    console.log("Alice's browser is starting PQrecovery from s and v ...");
    const [rp, rq] = recoverPQ(n, s, v);
    console.log("rp:", rp.toString());
    console.log("rq:", rq.toString());
    console.log("Alice' browser successfully recovered her key-pair generator base (p, q) from s and v.",
                "\nAs long as her browser is caching the key base, she can register with other servers,",
                "\nwith the same fingerprint.");
    return {signatureClient};
}
async function main() {
    const keybase = await preparationPhase();
    console.log(horizonalLine);
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    const registrationServer = "bob.example.com";
    const username = "alice1";
    const password = "password12345";
    const oprfServer = "oprf.reich.org";
    const svkRetrievalUser = true;
    const browser = {keybase}
    const user = {registrationServer, username, password, oprfServer, svkRetrievalUser};
    const {fingerprint, svkString, oprfID, svkRetrieval} = await registrationPhase(browser, user);
    console.log("svk:", svkString);
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    const client = {registrationServer, username, password, svkRetrieval};
    const server = {fingerprint, svkString, oprfServer, oprfID};
    const authenticationResult = authenticationPhase(client, server);
    console.log(horizonalLine);
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    console.log("### RE-REGISTRATION PHASE ###");
    console.log("Alice wants to register with another server, e.g. https://charlie.example.com/register",
        "\nShe clicks on the registration link,",
        "\nand her browser sends a regular GET request for that URL to Charlie's server (HTTP Request 1).");
    console.log(horizonalLine);
    ////////////////////////////////////////////////////////
    console.log("The registration process is the same as with Bob's server.");
}
main();