/** #region Introductory comments
 * This is a client-server implementation of the 'Mutually Authenticated Auditable aPAKE' (mA3PAKE) protocol.
 * It was designed and implemented by Tobias Reich, and described, analyzed, and proposed in his Master's Thesis:
 * 'Non-repudiable Password Authentication Using Mutually Authenticated Auditable aPAKE Protocols' (2023).
 * It enhances the 'Auditable aPAKE' (A2PAKE) protocol with a novel cryptographic primitive for mutual authentication,  
 * based on key-pair generator fingerprints, preventing server impersonating adversaries from password-guessing attacks.
 * It also implements the HTTP Mutual Authentication Protocol, in accordance to RFC8120 where applicable: 
 * https://datatracker.ietf.org/doc/html/rfc8120 (see page 5).
 * 
 * Note: Comments with `// #region` and `// #endregion` are meant to create foldable sections in Visual Studio Code.
 * They can be "folded" and "unfolded" in the editor to hide/show the code within, making large files easier to navigate.
 * These tags do not affect the execution of the code in any way and are purely for the developer's convenience.
 * 
 * Note: mA3PAKE is a "Mutual Authenticated" (mA) variant of the Auditable aPAKE (A2PAKE) protocol
 * (mA + A2PAKE = mA3PAKE), and at the same time implements the HTTP Mutual Authentication Protocol.
 * 
 * #endregion
 */

// #region Imports, constants, and global variables
// Detect environment
const isBrowser = typeof window !== 'undefined';
const isNodeJs = typeof process !== 'undefined' 
            && process.versions != null && process.versions.node != null;

let crypto;
if (isNodeJs) { // Node.js environment
    crypto = require('node:crypto');
} else if (isBrowser) { // Browser environment
    crypto = require('crypto-browserify');
} else {
    throw new Error("Unknown environment.");
}
const jose = require('node-jose');
const jwt = require('jsonwebtoken');
const JWS = jwt;
const { JWK, JWE } = jose;
const forge = require('node-forge');
const BigInteger = forge.jsbn.BigInteger;
const ONE = new BigInteger('1');
const TWO = new BigInteger('2');
const { bigIntegerToBase64url, base64urlToBigInteger } = require('../utils/backups/base64url_BigInteger.js');
const hashWithSHA256 = require('../utils/hashWithSHA256.js');
const { timeStamp, log, error, time } = require('console');
const http = require('http');
const parsers = require('www-authenticate').parsers;
const oprfClient = require('../utils/oprfClient.js');
//const generateKeyPairSync = crypto.generateKeyPairSync;
//const { customSignPSS, customDecryptOAEP } = require('../utils/customRSA.js'); 
// Server parameters
const registrationServer = "http://bob.example.com:80";
const oprfServerDefault = "oprf.example.net";
const svkRetrievalSupport = true;
// Protocol parameters
const version = "1";
const algorithm = "mA3PAKE" 
const validation = "PS256"; // JWT signature algorithm
const protocolParams = `version="${version}", algorithm="${algorithm}", validation="${validation}"`;
// Keyexchange parameters
const serverDHkty = "EC";
const serverDHcurve = "P-256";
const serverDHcurveName = "secp256r1";
// RSA parameters
const nBits = 1024;
// JWE parameters
const jweAlg = "A256GCM";
const jweEnc = "A256GCM";
// Output formatting
const radix = 16;
const horizonalLine = "------------------------------------------------------------";
// Realm names
const realmRegister = "User Registration";
const realmLogin = "User Login";
const realmLogout = "User Logout";
const realmTransaction = "User Transaction";
// Message types
const msgTypeRegInvitation = "User Registration Invitation";
const msgTypeRegRequest = "User Registration Request";
const msgTypeRegChallenge = "User Registration Challenge";
const msgTypeRegConfirmation = "User Registration Confirmation";
const msgTypeLoginInvitation = "User Login Invitation";
const msgTypeLoginRequest = "User Login Request";
const msgTypeLoginChallenge = "User Login Challenge";
const msgTypeLoginConfirmation = "User Login Confirmation";
const msgTypeLogoutInvitation = "User Logout Invitation";
const msgTypeLogoutRequest = "User Logout Request";
const msgTypeLogoutChallenge = "User Logout Challenge";
const msgTypeLogoutConfirmation = "User Logout Confirmation";
 /** 
  * Example of 'error' codes and 'error descriptions' in WWW-Authenticate header:
  * error="invalid_token", error_description="The access token is invalid"
  * TODO: replace the 'error' "messages" with error codes and descriptions as in the example above 
  * Error messages:
*/
const errMsgInvalidMsgType = "invalid message type";
const errMsgInvalidProtParams = "invalid protocol parameters";
const errMsgInvalidRealm = "invalid realm";
const errMsgInvalidRegKc1 = "invalid kc1 session parameter (server, keyexchange or timestamp mismatch)";
const errMsgUsernameTaken = "username already taken";
const errMsgFingerprintMismatch = "fingerprint mismatch";
const errMsgInvalidSignature = "invalid signature";
const errMsgUserMismatch = "user mismatch";
// RSA-OAEP and RSA-PSS parameters
const rsaOAEPParams = { md: forge.md.sha256.create() };
const rsaPssParams = {
    md: forge.md.sha256.create(),
    mgf: forge.mgf.mgf1.create(forge.md.sha256.create()),
    saltLength: 32
}
const pssObj = forge.pss.create(rsaPssParams);
// Session caches and user "database"
const registrationSessions = {};
const loginSessions = {};
const loggedInUsers = {};
const logoutSessions = {};
const userDB = {};
// HTML welcome page
const welcomeHTML = `
<html><head>
<title>Bob's Server</title>
<style>
body {background-color: #f2f2f2;}
h1 {color: #000000; text-align: center;}
p {font-family: "Courier New", monospace;}
</style>
</head>
<body>
<h1>Welcome to Bob's server!</h1>
<p> 
- Register at <a href="/register">/register</a></br>
- Login at <a href="/login">/login</a></br>
- Logout at <a href="/logout">/logout</a></br>
- Transactions at <a href="/transaction">/transaction</a> (not implemented yet)</br>
</p>
</body>
</html>
`;
// #endregion

/** Oiwa, et al. - Experimental RFC 8120 - Mutual Authentication Protocol for HTTP - April 2017
    2.  Protocol Overview
   The protocol, as a whole, is designed as a natural extension to HTTP
   [RFC7230] and uses the framework defined in [RFC7235].  Internally,
   the server and the client will first perform a cryptographic key
   exchange, using the secret password as a "tweak" to the exchange.
   The key exchange will only succeed when the secrets used by both
   peers are correctly related (i.e., generated from the same password).
   Then, both peers will verify the authentication results by confirming
   the sharing of the exchanged key.  This section provides a brief
   outline of the protocol and the exchanged messages.

    2.1.  Messages
   The authentication protocol uses six kinds of messages to perform
   mutual authentication.  These messages have specific names within
   this specification.
   o  Authentication request messages: used by the servers to request
      that clients start mutual authentication.
      *  401-INIT message: a general message to start the authentication
         protocol.  It is also used as a message indicating an
         authentication failure.
      *  401-STALE message: a message indicating that the client has to
         start a new key exchange.
   o  Authenticated key exchange messages: used by both peers to perform
      authentication and the sharing of a cryptographic secret.
      *  req-KEX-C1 message: a message sent from the client.
      *  401-KEX-S1 message: an intermediate response to a req-KEX-C1
         message from the server.
   o  Authentication verification messages: used by both peers to verify
      the authentication results.
      *  req-VFY-C message: a message used by the client to request that
         the server authenticate and authorize the client.
      *  200-VFY-S message: a response used by the server to indicate
         that client authentication succeeded.  It also contains
         information necessary for the client to check the authenticity
         of the server.
   In addition to the above six kinds of messages, a request or response
   without any HTTP headers related to this specification will be
   hereafter called a "normal request" or "normal response",
   respectively.

    2.2.  Typical Flows of the Protocol
   In typical cases, client access to a resource protected by the
   Mutual authentication scheme will use the following protocol
   sequence:
          Client                                 Server
            |                                      |
            |  ---- (1) normal request --------->  |
        GET / HTTP/1.1                             |
            |                                      |
            |  <---------------- (2) 401-INIT ---  |
            |            401 Unauthorized          |
            |            WWW-Authenticate: Mutual realm="a realm"
            |                                      |
   [user,   |                                      |
    pass]-->|                                      |
            |  ---- (3) req-KEX-C1 ------------->  |
        GET / HTTP/1.1                             |
        Authorization: Mutual user="john",         |--> [user DB]
                       kc1="...", ...              |<-- [user info]
            |                                      |
            |  <-------------- (4) 401-KEX-S1 ---  |
            |           401 Unauthorized           |
            |           WWW-Authenticate: Mutual sid=..., ks1="...", ...
            |                                      |
        [compute] (5) compute session secret   [compute]
            |                                      |
            |                                      |
            |  ---- (6) req-VFY-C -------------->  |
        GET / HTTP/1.1                             |--> [verify (6)]
        Authorization: Mutual sid=...,             |<-- OK
                       vkc="...", ...              |
            |                                      |
            |  <--------------- (7) 200-VFY-S ---  |
   [verify  |           200 OK                     |
     (7)]<--|           Authentication-Info: Mutual vks="..."
            |                                      |
            v                                      v

     Figure 1: Typical Communication Flow for First Access to Resource

   o  As is typical in general HTTP protocol designs, a client will at
      first request a resource without any authentication attempt (1).
      If the requested resource is protected by the Mutual
      authentication protocol, the server will respond with a message
      requesting authentication (401-INIT) (2).
   o  The client processes the body of the message and waits for the
      user to input the username and password.  If the username and
      password are available, the client will send a message with the
      authenticated key exchange (req-KEX-C1) to start the
      authentication (3).
   o  If the server has received a req-KEX-C1 message, the server
      looks up the user's authentication information within its user
      database.  Then, the server creates a new session identifier (sid)
      that will be used to identify sets of the messages that follow it
      and responds with a message containing a server-side authenticated
      key exchange value (401-KEX-S1) (4).
   o  At this point (5), both peers calculate a shared "session secret"
      using the exchanged values in the key exchange messages.  Only
      when both the server and the client have used secret credentials
      generated from the same password will the session secret values
      match.  This session secret will be used for access authentication
      of every individual request/response pair after this point.
   o  The client will send a request with a client-side authentication
      verification value (req-VFY-C) (6), calculated from the
      client-generated session secret.  The server will check the
      validity of the verification value using its own version of the
      session secret.
   o  If the authentication verification value from the client was
      correct, then the client definitely owns the credential based on
      the expected password (i.e., the client authentication succeeded).
      The server will respond with a successful message (200-VFY-S) (7).
      Unlike the usual one-way authentication (e.g., HTTP Basic
      authentication or POP APOP authentication [RFC1939]), this message
      also contains a server-side authentication verification value.
      When the client's verification value is incorrect (e.g., because
      the user-supplied password was incorrect), the server will respond
      with a 401-INIT message (the same message as the message used
      in (2)) instead.
   o  The client MUST first check the validity of the server-side
      authentication verification value contained in the message (7).
      If the value was equal to the expected value, server
      authentication succeeded.

      If it is not the expected value or the message does not contain
      the authentication verification value, then the mutual
      authentication has been broken for some unexpected reason.  The
      client MUST NOT process any body or header values contained in the
      HTTP response in this case.  (Note: This case should not happen
      between a correctly implemented server and client without any
      active attacks; such a scenario could be caused by either a
      man-in-the-middle attack or incorrect implementation.)
 */

// #region Server class
class mA3PAKEserver {
    constructor(domain, oprfServerDefault, svkRetrievalSupport) {
        this.server = http.createServer((req, res) => this.handleRequest(req, res)); 
        // #region Parameters
        // Server parameters
        this.serverDomain = domain;
        this.serverName = `http://${domain}:80`;
        this.oprfServerDefault = oprfServerDefault;
        this.svkRetrievalSupport = svkRetrievalSupport;
        // Protocol parameters
        this.protocolVersion = "1";
        this.protocolAlgorithm = "mA3PAKE"
        this.protocolValidation = "PS256"; // JWT signature algorithm
        this.protocolParams = `version="${version}", algorithm="${algorithm}", validation="${validation}"`;
        // Keyexchange parameters
        this.dhkty = "EC";
        this.dhcurve = "P-256";
        this.dhcurveName = "secp256r1";
        // JWE parameters
        this.jweAlg = "A256GCM";
        this.jweEnc = "A256GCM";
        // Realm names
        this.realmRegister = "User Registration";
        this.realmLogin = "User Login";
        this.realmLogout = "User Logout";
        this.realmTransaction = "User Transaction";
        // Message types
        this.msgTypeRegInvitation = "User Registration Invitation";
        this.msgTypeRegRequest = "User Registration Request";
        this.msgTypeRegChallenge = "User Registration Challenge";
        this.msgTypeRegConfirmation = "User Registration Confirmation";
        this.msgTypeLoginInvitation = "User Login Invitation";
        this.msgTypeLoginRequest = "User Login Request";
        this.msgTypeLoginChallenge = "User Login Challenge";
        this.msgTypeLoginConfirmation = "User Login Confirmation";
        this.msgTypeLogoutInvitation = "User Logout Invitation";
        this.msgTypeLogoutRequest = "User Logout Request";
        this.msgTypeLogoutChallenge = "User Logout Challenge";
        this.msgTypeLogoutConfirmation = "User Logout Confirmation";
         /** 
          * Example of 'error' codes and 'error descriptions' in WWW-Authenticate header:
          * error="invalid_token", error_description="The access token is invalid"
          * TODO: replace the 'error' "messages" with error codes and descriptions as in the example above 
          * Error messages:
        */
        this.errMsgInvalidMsgType = "invalid message type";
        this.errMsgInvalidProtParams = "invalid protocol parameters";
        this.errMsgInvalidRealm = "invalid realm";
        this.errMsgInvalidRegKc1 = "invalid kc1 session parameter (server, keyexchange or timestamp mismatch)";
        this.errMsgUsernameTaken = "username already taken";
        this.errMsgFingerprintMismatch = "fingerprint mismatch";
        this.errMsgInvalidSignature = "invalid signature";
        this.errMsgUserMismatch = "user mismatch";
        this.errMsgInvalidRequest = "Invalid HTTP Request";
        this.errMsgInvalidSid = "Session ID not found";
        this.errMsgMissingSid = "No session ID provided";
        // RSA-OAEP and RSA-PSS parameters
        this.rsaOAEPParams = { md: forge.md.sha256.create() };
        this.rsaPssParams = {
            md: forge.md.sha256.create(),
            mgf: forge.mgf.mgf1.create(forge.md.sha256.create()),
            saltLength: 32
        }
        this.pssObj = forge.pss.create(rsaPssParams);
        // Session caches and user "database"
        this.registrationSessions = {};
        this.loginSessions = {};
        this.loggedInUsers = {};
        this.logoutSessions = {};
        this.userDB = {};
        // HTML welcome page
        this.welcomeHTML = `
        <html><head>
        <title>Bob's Server</title>
        <style>
        body {background-color: #f2f2f2;}
        h1 {color: #000000; text-align: center;}
        p {font-family: "Courier New", monospace;}
        </style>
        </head>
        <body>
        <h1>Welcome to Bob's server!</h1>
        <p> 
        - Register at <a href="/register">/register</a></br>
        - Login at <a href="/login">/login</a></br>
        - Logout at <a href="/logout">/logout</a></br>
        - Transactions at <a href="/transaction">/transaction</a> (not implemented yet)</br>
        </p>
        </body>
        </html>
        `;
        // #endregion
    }
    async handleRequest(req, res) { 
        // Set headers to comply with RFC 7235 and RFC 8120
        res.setHeader('Content-Type', 'application/json');
        res.setHeader('Cache-Control', 'no-store');
        res.setHeader('Pragma', 'no-cache');
        // HTTP Authentication header of client request
        const authHeader = req.headers.authorization;
        // Handle requests
        try { 
            // Handle the root path (Start page)
            if(req.url === '/'){
                // Set the status code to 200 (OK) and send a welcome message
                res.statusCode = 200;
                res.end(this.welcomeHTML);
            }
            // Handle the register path
            if (req.url === '/register') {
                /**
                 * Check if any "Authorization" header is present, and if not, initiate the registration process.
                */
                if (!authHeader) {
                    await this.registerFlow1(req, res);
                } else 
                /**
                 * Check if the Authorization header for 'Mutual' HTTP Authentication includes the 'kc1' message.
                */
                if (authHeader.startsWith('Mutual ') && authHeader.includes('kc1=')) {
                    await this.registerFlow2(req, res);
                } else 
                /**
                 * Any Authorization header without the 'kc1* parameter is invalid. The server sends a 401-R-INIT
                 * WWW-Authenticate header with error message 'invalid authorization header' and protocol params.
                */
                {    
                    res.statusCode = 401;
                    const errorMessage = "invalid authorization header";
                    res.setHeader('WWW-Authenticate', 
                        `Mutual realm="${realmRegister}", ${protocolParams}, error="${errorMessage}"`);
                    res.end();
                } 
            }
            // #region Login Simulation
            /** ************* Login Simulation: *****************************************************
             * // AUTHENTICATION PHASE
            async function authenticationPhase(client, server) {
            const [registrationServer, username, password, svkRetrieval] 
             = [client.registrationServer, client.username, client.password, client.svkRetrieval];
            const [fingerprint, svkStr, oprfServer, oprfID]
             = [server.fingerprint, server.svkString, server.oprfServer, server.oprfID];
            svkJSON = JSON.parse(svkStr);
            const svk = pki.setRsaPublicKey(new BigInteger(svkJSON.n), new BigInteger(svkJSON.e));
            log("\n### AUTHENTICATION PHASE ###");
            const authenticationServer = "bob.example.com";
            log("Alice wants to log into her account with " + authenticationServer + ", again.",
                    "\nShe clicks on the login link: https://", registrationServer, "/login",
                    "\nand her browser sends a regular GET request for that URL to Bob's server (HTTP Request 1).");
            log(horizonalLine);
            ////////////////////////////////////////////////////////
            log("Bob's server receives HTTP Request 1. ",
                    "\nBecause it's for the /login endpoint, he initiates a login/authentication process.");
            messageType = "user login invitation";
            const nonceServerBytes = forge.random.getBytesSync(32);
            const nonceServer = forge.util.bytesToHex(nonceServerBytes);
            timestamp = Date.now()
            loginMessage = {messageType, timestamp, authenticationServer, 
                            nonceServer
                        };
            log("Bob's server generates a nonce and a timestamp,",
                    "\nand sends a HTTP authorization header with an login invitation to Alice's browser (HTTP Response 1):\n", 
                    loginMessage);
            log(horizonalLine);
            ////////////////////////////////////////////////////////
            log("Alice's browser receives the HTTP authorization header with the login message,",
                    "\nand asks her to enter her if she wants to login with", authenticationServer,
                    "\nIf she confirms, he prompt her for her username and password.",
                    "\nShe enters the same username and password as before:\n",
                    "username:", username, "\npassword:", password);
            messageType = "user login request";
            const nonceClientBytes = forge.random.getBytesSync(32);
            const nonceClient = forge.util.bytesToHex(nonceClientBytes);
            loginMessage = {messageType, timestamp, authenticationServer, username, 
                            nonceServer, nonceClient
                        };
            log("Alice's browser updates the loginMessage with the username and a nonce,",
                    "\nand sends it to Bob's server (HTTP Request 2):\n", loginMessage);
            log(horizonalLine);
            ////////////////////////////////////////////////////////
            log("Bob's server receives the login request and checks if the username exists in his database.",
                    "\nIf so, Bob's server creates an login message containing:",
                    "\nAlice' username, her OPRF server and client ID, her modulus and her fingerprint.");
            messageType = "user login challenge";
            const modulus = svk.n.toString();
            loginMessage = {messageType, timestamp, authenticationServer, username, fingerprint, modulus, 
                            svkRetrieval, oprfServer, oprfID,
                            nonceServer, nonceClient 
                        };
            log("Bob's server sends the login challenge message to Alice's browser (HTTP Response 2):\n", 
                        loginMessage);
            log(horizonalLine);
            ////////////////////////////////////////////////////////
            log("\nAlice's browser receives the login challenge, validates it, and calculates the modulus fingerprint,",
                    "\ncompares it with the one in the message, displays it's randomart image and asks Alice to verify it.",
                    "\nIf Alice confirms, her browser now starts the OPRF evaluation of her password ...");
            let passseed; 
            const oprfURL = "https://" + oprfServer;
            try {
                passseed = await oprfClient(oprfURL, oprfID, password, "hex");
                log("OPRF has been evaluated. Passseed:", Buffer.from(passseed).toString('hex'));
            } catch (error) {
                console.error("An error occurred:", error);
            }
            log("Alice's browser derives the secret exponent s from the passseed ...");
            const s = new BigInteger(deriveRSAExponent(passseed, nBits - 1));
            log("Exponent s has been derived:", s.toString(radix));
            log("Construct ssk from s and n ...");
            const n = new BigInteger(modulus);
            const ssk = pki.setRsaPublicKey(n, s);
            log("Alice's browser signs the authentication message with ssk ...");
            const loginMsgString = JSON.stringify(loginMessage);
            const md2 = forge.md.sha256.create();
            const loginMsgHash = md2.update(loginMsgString);
            const signatureClientBytes = customSignPSS(loginMsgHash, ssk, rsaPssParams);
            const signatureClient = forge.util.bytesToHex(signatureClientBytes);
            log("Alice's signature:", signatureClient);
            log("Alice' browser creates a random AES key and OAEP-encrypts it with ssk ...");
            const aesKey = forge.random.getBytesSync(32);
            log("Alice's AES key:", aesKey.toString('hex'));
            const aesKeyEncryptedBytes = ssk.encrypt(aesKey, "RSA-OAEP", rsaOAEPParams);
            const encryptedKey = forge.util.bytesToHex(aesKeyEncryptedBytes);
            log("Alice's browser updates the login message with the signature and the encrypted AES key ...");
            messageType = "user login response";
            loginMessage = {messageType, timestamp, authenticationServer, username, fingerprint, modulus, 
                            svkRetrieval, oprfServer, oprfID,
                            nonceServer, nonceClient,
                            signatureClient, encryptedKey
                        };
            log("Alice's browser sends the login response (and signature) to Bob's server (HTTP Request 3):\n",
                        loginMessage);
            log(horizonalLine);
            ////////////////////////////////////////////////////////
            log("Bob's server receives the login response and verifies the signature with Alice' verifier key svk.",
                    "\nIf the signature is valid, he sends a login confirmation message to Alice's browser.",
                    "\nIf Alice has registered with svkRetrieval and requesets it now, he includes the encrypted svk.");
            const signatureClientBytesFromHex = forge.util.hexToBytes(loginMessage.signatureClient);
            const md3 = forge.md.sha256.create();
            const loginMsgHash2 = md3.update(loginMsgString);
            const verifiedClient2 = svk.verify(loginMsgHash.digest().bytes(), signatureClientBytes, pssObj);
            log("Bob's server was able to verify Alice' signature:", verifiedClient2);
            log("He decrypts the encrypted AES key with svk ...");
        
            const encryptedKeyFromHex = forge.util.hexToBytes(loginMessage.encryptedKey);
            const aesKey2DecryptedBytes = customDecryptOAEP(encryptedKeyFromHex, svk, rsaOAEPParams);
            const aesKey2Decrypted = forge.util.bytesToHex(aesKey2DecryptedBytes);
            log("Bob's server decrypted the AES key successfully:", aesKey2Decrypted);
            log("He encrypts svk with the AES key ...");
            const svkString = JSON.stringify({n: svk.n.toString(), e: svk.e.toString()});
            const svkBuffer = forge.util.createBuffer(svkString);
            const aesKey2DecryptedBinary = forge.util.hexToBytes(aesKey2Decrypted.toString('hex'));
            const svkCipher = forge.cipher.createCipher('AES-CBC', aesKey2DecryptedBinary);
            var verifierKeyEncryptedIvBytes = forge.random.getBytesSync(16);
            var verifierKeyEncryptedIV = forge.util.bytesToHex(verifierKeyEncryptedIvBytes);
            svkCipher.start({iv: verifierKeyEncryptedIvBytes});
            svkCipher.update(svkBuffer);
            svkCipher.finish();
            const verifierKeyEncryptedBuffer = svkCipher.output;
            var verifierKeyEncrypted = verifierKeyEncryptedBuffer.toHex();
            log("Bob's AES-encrypted verifier key:", verifierKeyEncrypted);
            log("Bob's server updates the login message with the encrypted verifier key and IV and signs it ...");
            messageType = "user login confirmation";
            loginMessage = {messageType, timestamp, authenticationServer, username, fingerprint, 
                            nonceServer, nonceClient,
                            verifierKeyEncrypted, verifierKeyEncryptedIV
                        };
            const loginMsgString2 = JSON.stringify(loginMessage);
            const md4 = forge.md.sha256.create();
            const loginMsgHash3 = md4.update(loginMsgString2);
            const signatureServer2Bytes = customSignPSS(loginMsgHash3, svk, rsaPssParams);
            const signatureServer2 = forge.util.bytesToHex(signatureServer2Bytes);
            log("Bob's signature:", signatureServer2);
            log("Bob's server encrypts the signature with the AES key ...");
            const signatureServer2Buffer = forge.util.createBuffer(signatureServer2Bytes);
            const signatureCipher2 = forge.cipher.createCipher('AES-CBC', aesKey2DecryptedBinary);
            var signatureServerEncryptedIvBytes = forge.random.getBytesSync(16);
            var signatureServerEncryptedIV = forge.util.bytesToHex(signatureServerEncryptedIvBytes);
            signatureCipher2.start({iv: signatureServerEncryptedIvBytes});
            signatureCipher2.update(signatureServer2Buffer);
            signatureCipher2.finish();
            var signatureServerEncryptedBytes = signatureCipher2.output;
            var signatureServerEncrypted = forge.util.bytesToHex(signatureServerEncryptedBytes);
            log("Bob's AES-encrypted signature:", signatureServerEncrypted);
            log("Bob's server updates the login message with the encrypted signature and IV ...");
            loginMessage = {messageType, timestamp, authenticationServer, username, fingerprint, 
                            nonceServer, nonceClient,
                            verifierKeyEncrypted, verifierKeyEncryptedIV,
                            signatureServerEncrypted, signatureServerEncryptedIV
                        };
            
            log("Bob's server updates the login confirmation with the encrypted svk and signature, and IVs ...");
            log("He sends the login confirmation message to Alice's browser (HTTP Response 3):\n",
                        loginMessage);
            log(horizonalLine);
            ////////////////////////////////////////////////////////
            log("Alice's browser receives the login confirmation and decrypts the encrypted signature with her AES key ...");
            const signatureServerFromHex2 = forge.util.hexToBytes(loginMessage.signatureServerEncrypted);
            const signatureServerIVFromHex2 = forge.util.hexToBytes(loginMessage.signatureServerEncryptedIV);
            const signatureDecipher2 = forge.cipher.createDecipher('AES-CBC', aesKey2DecryptedBinary);
            signatureDecipher2.start({iv: signatureServerIVFromHex2});
            signatureDecipher2.update(forge.util.createBuffer(signatureServerFromHex2));
            signatureDecipher2.finish();
            const signatureServerDecrypted2Buffer = signatureDecipher2.output;
            const signatureServerDecrypted2Bytes = signatureServerDecrypted2Buffer.bytes();
            const signatureServerDecrypted2 = forge.util.bytesToHex(signatureServerDecrypted2Bytes);
            log("Alice decrypted Bob's signature:", signatureServerDecrypted2);
            log("... and now verifies it with her signing key ssk.");
            const md5 = forge.md.sha256.create();
            const loginMsgHash4 = md5.update(loginMsgString2);
            const verifiedServerSignature2 = ssk.verify(loginMsgHash4.digest().bytes(), signatureServerDecrypted2Bytes, pssObj);
            log("Alice's browser decrypts the encrypted verifier key with her AES key ...");
            const verifierKeyEncryptedFromHex = forge.util.hexToBytes(loginMessage.verifierKeyEncrypted);
            const verifierKeyEncryptedIVFromHex = forge.util.hexToBytes(loginMessage.verifierKeyEncryptedIV);
            const verifierKeyDecipher = forge.cipher.createDecipher('AES-CBC', aesKey2DecryptedBinary);
            verifierKeyDecipher.start({iv: verifierKeyEncryptedIVFromHex});
            verifierKeyDecipher.update(forge.util.createBuffer(verifierKeyEncryptedFromHex));
            verifierKeyDecipher.finish();
            const verifierKeyDecryptedBuffer = verifierKeyDecipher.output;
            const verifierKeyDecrypted = verifierKeyDecryptedBuffer.toString();
            log("Alice's browser decrypted the verifier key successfully:", verifierKeyDecrypted);
            log("Alice's browser checks the modulus of the decrypted verifier key against the one in the login message ...");
            const verifierKeyDecryptedJSON = JSON.parse(verifierKeyDecrypted);
            const verifierKeyDecryptedN = new BigInteger(verifierKeyDecryptedJSON.n);
            log("The modulus matches the one in the login message:", verifierKeyDecryptedN.equals(ssk.n));
            const verfierKeyDecryptedE = new BigInteger(verifierKeyDecryptedJSON.e);
            const v = verfierKeyDecryptedE;
            log("Alice's browser is starting PQrecovery from s and v ...");
            const [rp, rq] = recoverPQ(n, s, v);
            log("rp:", rp.toString());
            log("rq:", rq.toString());
            log("Alice' browser successfully recovered her key-pair generator base (p, q) from s and v.",
                        "\nAs long as her browser is caching the key base, she can register with other servers,",
                        "\nwith the same fingerprint.");
            return {signatureClient};
            }
         */
              // #endregion
            
            // Handle the login path
            if (req.url === '/login') {
                // Check if authentification header is present.
                // This flow initiates the login process with a login invitation message (401-INIT).
                if (!authHeader) {
                    /** 
                     * As is typical in general HTTP protocol designs, a client will at
                     * first request a resource without any authentication attempt (1).
                     * If the requested resource is protected by the Mutual
                     * authentication protocol, the server will respond with a message
                     * requesting authentication (401-INIT) 
                    */
                    log("Bob's server receives a regular request without any authentication header (HTTP Request 1). ",
                        "\nBecause it's for the /login endpoint, he initiates a login/authentication process.");
                    this.loginFlow1(req, res);
                } else  
                // Check if authentication header is present, starts with 'Mutual ' and contains a kc1 parameter.
                // This flow processes the login request message (401-REQ) and sends a key exchange message (401-KE).
                if (authHeader.startsWith('Mutual ') && authHeader.includes('kc1=')) { 
                    log("Bob's server receives the user login request message (HTTP Request 2)...");
                    this.loginFlow2(req, res);
                } else
                // check if authentication header is present, starts with 'Mutual ' and contains a kc2 parameter
                // This flow processes the key exchange message (401-KE) and sends a login challenge message (401-CH)
                if (authHeader.startsWith('Mutual ') && authHeader.includes('kc2=')) { 
                    log("Bob's server receives the user login response message (HTTP Request 3)...");
                    this.loginFlow3(req, res);
                } else 
                // check if authentication header is present, starts with 'Mutual ' and contains a kc3 parameter
                // This flow processes the login challenge response message (401-CH) and sends a login confirmation message (200-VFY)
                if (authHeader.startsWith('Mutual ') && authHeader.includes('kc3=')) {
                } else { // invalid HTTP Request
                    log("Bob's server receives an invalid HTTP Request.");
                    res.statusCode = 401;
                    const errorMessage = "invalid HTTP Request";
                    res.setHeader('WWW-Authenticate', `Mutual ${protocolParams}", realm="${realmLogin}", error="${errorMessage}"`);
                    res.end();
                }
            } else
            // Handle the logout path
            if (req.url === '/logout') {
                const realmLogout = "User Logout";
                // Check if authentification header is present.
                // This flow initiates the logout process with a logout invitation message (401-INIT).
                if (!authHeader) {
                    log("Bob's server receives HTTP Request 1. ",
                    "\nBecause it's for the /logout endpoint, he initiates a logout process.");
                    this.logoutFlow1(req, res);
                } else  
                // Check if authentication header is present, starts with 'Mutual ' and contains a kc1 parameter.
                // This flow processes the logout request message (401-REQ) and sends a logout confirmation message (200-VFY).
                if (authHeader.startsWith('Mutual ') && authHeader.includes('kc1=')) {
                    log("Bob's server receives the user logout request message (HTTP Request 2)...");
                    this.logoutFlow2(req, res);
                } else { // invalid HTTP Request
                    log("Bob's server receives an invalid HTTP Request.");
                    this.errorFlow(req, res, this.realmLogout);
                }
            } else 
            // Handle transactions 
            if (req.url === '/transaction') {
                // Check if authentification header is present and if the body contains an action object
                // This flow initiates the transaction process with a transaction invitation message (401-INIT).
                if (!authHeader && req.body.action) {
                    /** 
                     * As is typical in general HTTP protocol designs, a client will at
                     * first request a resource without any authentication attempt (1).
                     * If the requested resource is protected by the Mutual
                     * authentication protocol, the server will respond with a message
                     * requesting authentication (401-INIT) 
                    */
                    log("Bob's server receives a regular request without any authentication header (HTTP Request 1). ",
                        "\nBecause it's for the /transaction endpoint, he initiates a transaction process.");
                    this.transactionFlow1(req, res);
                } else  
                // Check if authentication header is present, starts with 'Mutual ' and contains a kc1 parameter.
                // This flow processes the transaction request message (401-REQ) and sends a transaction challenge message (401-CH).
                if (authHeader.startsWith('Mutual ') && authHeader.includes('kc1=')) {
                    log("Bob's server receives the user transaction request message (HTTP Request 2)...");
                    this.transactionFlow2(req, res);
                } else {
                    this.errorFlow(req, res, this.realmTransaction);
                }
            }
        } catch (err) {
            console.error(err);
            res.writeHead(500);
            res.end('Internal Server Error');
        }
    } 
    parseAuthHeader(authHeader) {
        const authHeaderParts = authHeader.split(' ');
        const authHeaderParams = authHeaderParts[1].split(',');
        const authHeaderParamsObj = {};
        authHeaderParams.forEach(param => {
            const [key, value] = param.split('=');
            authHeaderParamsObj[key.trim()] = value.replace(/"/g, '');
        });
        return authHeaderParamsObj;
    }
    // Checks Authorization header for Mutual authentication
    checkAuthHeader(req, res, realmExpected){
        const authHeader = req.headers.authorization;
        let errorMessage;
        if (! (authHeader.version === this.protocolVersion
            && authHeader.algorithm === this.protocolAlgorithm 
            && authHeader.validation === this.protocolValidation)) {
            log(false, "version:", authHeader.version, 
                             "algorithm:", authHeader.algorithm, 
                            "validation:", authHeader.validation);
            res.statusCode = 401;
            errorMessage = this.errMsgInvalidProtParams;
        } else 
        if (authHeader.realm !== realmExpected) {
            log(false, "realm:", authHeader.realm);
            res.statusCode = 401;
            errorMessage = this.errMsgInvalidRealm;
        } 
        if (errorMessage) {
            res.setHeader('WWW-Authenticate', 
                `Mutual realm="${realmExpected}", ${this.protocolParams}, error="${errorMessage}"`);
            res.end();
        } else {
            log(true);
        }
    }
    // Generates a random new session ID (sid)
    newSID() {
        const randomBytes = crypto.randomBytes(16);
        const sid = randomBytes.toString('hex');
        return sid;
    }
    // Checks if session is valid and not expired
    checkSession(req, res, sid, realm){
        let authHeaderResponse = this.protocolParams
        let sessionExpired;
        let session;
        let errorMessage;
        if (sid) {
            authHeaderResponse += `, sid="${sid}"`;
            switch (realm) {
                case this.realmRegister:
                    session = this.registrationSessions[sid];
                    break;
                case this.realmLogin:
                    session = this.loginSessions[sid];
                    break;
                case this.realmLogout:
                    session = this.logoutSessions[sid];
                    break;
                default:
                    session = null;
                    break;
            }
            if (session) {
                const sessionTimestamp = session.timestamp;
                const now = new Date();
                const sessionExpired = (now - sessionTimestamp) > 3600;
                if (sessionExpired) {
                    errorMessage = this.errMsgSessionExpired;
                }    
            } else {
                errorMessage = this.errMsgInvalidSid;
            } 
        } else {
            errorMessage = this.errMsgMissingSid;
        }
        if (session && !sessionExpired) {
            log(true);
        } else {
            log(false, "session:", session, "sessionExpired:", sessionExpired);
            res.statusCode = 401;
            authHeaderResponse += `, error="${errorMessage}"`;
            res.setHeader('WWW-Authenticate', "Mutual " + authHeaderResponse);
            res.end();
        }
    }
    // Checks if registration request is valid
    checkRegRequest(req, res, sid, kc1Payload) {
        let error;
        const sessionKs1 = this.registrationSessions[sid];
        log("Bob's server checks:\n",
                    `- if the message type is "${this.msgTypeRegRequest}",`);
        kc1MessageType = kc1Payload.messageType;
        if (kc1MessageType === this.msgTypeRegRequest) {
            log(true);
        } else {
            log(false);
            error = this.errMsgInvalidMsgType;
        }
        log(" - if the registration servername, timestamp, and server public key are valid,");
        // check if all parameters are valid
        if (kc1Payload.registrationServer === sessionKs1.registrationServer && 
            kc1Payload.timestamp            === sessionKs1.timestampObj.toISOString() &&
            kc1Payload.keyexchangePubkeyServer === sessionKs1.keyexchangePubkeyServer) {
            log(true);
        } else {
            log(false);
            error = this.errMsgInvalidRegKc1;
        }        
        log(" - if the requested username is available",
            "   (ideally handled by the application prior to the registration).");
        // check if username is not already taken
        if (!this.userDB[kc1User]) {
            log(true);
        } else {
            log(false);
            error = this.errMsgUsernameTaken;
        }
        if (error) {
            res.statusCode = 401;
            res.setHeader('WWW-Authenticate', 
                `Mutual realm="${this.realmRegister}", ${this.protocolParams}, error="${error}"`);
            res.end();
        }
    } 
    // Generate the ks1 message
    async generateKs1JSON(messageType){
        let ks1JSON;
        let keyexchangeServerKeypair;
        const timestampObj = new Date();
        const timestamp = timestampObj.toISOString();
        switch (messageType) {
            case this.msgTypeRegInvitation: {
                log("He generates an ECDH-ES key pair...");
                keyexchangeServerKeypair = await JWK.createKey(this.dhkty, this.dhcurveName, {use: 'enc', alg: 'ECDH-ES'});
                log("... exports the public key ...");
                const keyexchangeServerPubkey = keyexchangeServerKeypair.toJSON(false);
                log("Bob's DH keyexchange public key:", keyexchangeServerPubkey);
                log("Regarding OPRF, Bob can suggest his default OPRF server to Alice ...");
                log("Bob's default OPRF server:", this.oprfServerDefault,
                        "\n... but she can customize it to a server of her choice.",
                        "\nNow, he replies with an 401-REG-INIT authorization header containing the ks1 parameter with:",
                        `\n - the message type "${messageType}",`,
                        "\n - his server name",
                        "\n - his default OPRF server,",
                        "\n - whether he supports svkRetrieval (sending his (encrypted) svk to Alice after successful authentication),",
                        "\n - his DH keyexchange public key, and ",
                        "\n - a timestamp.");
                ks1JSON = { messageType, timestamp, registrationServer: this.serverName,
                        oprfServer: this.oprfServerDefault, svkRetrieval: this.svkRetrievalSupport, keyexchangeServerPubkey};
                } break;
            case this.msgTypeLoginInvitation: {
                // TODO
                } break;
            default: {
                // TODO
            } break;
        }
        return {ks1JSON, timestampObj, keyexchangeServerKeypair};
    }
    // Calculate modulus fingerprint of verifier key svk
    modulusFingerprint(verifierKey) {
        const modulus = verifierKey.n;
        const modulusBuf = Buffer.from(modulus, 'base64');
        const modulusHash = crypto.createHash('sha256');
        modulusHash.update(modulusBuf);
        const modulusFingerprintBuf = modulusHash.digest();
        const modulusFingerprint = modulusFingerprintBuf.toString('hex');
        return modulusFingerprint;
    }
    // Verify registration request payload kc1 and extract verifier key svk
    async verifyRegReqPayload(req, res, sid, kc1JSON) {
        const session = this.registrationSessions[sid];
        log("From Alice' registration request message kc1 payload, he now extracts her ECDH public key...");
        const kc1PayloadString = kc1JSON.payload;
        const kc1Payload = JSON.parse(kc1PayloadString);
        const keyexchangePubkeyClient = kc1Payload.keyexchangePubkeyClient;
        const kc1KeyexchangePubkeyClient = await JWK.asKey(keyexchangePubkeyClient);
        log("Alice's ECDH public key (JWK):", kc1KeyexchangePubkeyClient);
        log("... retrieves his ECDH keypair from the cached registration session initiated with ks1 ...");
        const keyexchangeServer = session.keyexchangeServer;
        log("Bob's ECDH keypair (JWK):", keyexchangeServer);
        log("... and uses it to compute their shared secret ...");
        // keyexchangeSharedSecret is the shared secret of data type Buffer
        const keyexchangeSharedSecret = keyexchangeServer.derive(kc1KeyexchangePubkeyClient);
        log("Their shared secret (buffer to hex):", keyexchangeSharedSecret.toString('hex'));
        log("Bob's server now extracts Alice' encrypted verifier key svk (JWE) from the kc1 payload ...");
        const verifierKeyEncryptedJweString = kc1Payload.verifierKeyEncrypted;
        const verifierKeyEncryptedJWE= JSON.parse(verifierKeyEncryptedJweString);
        log("Alice' encrypted verifier key svk (JWE):", verifierKeyEncryptedJWE);
        log("... and decrypts it with the shared secret key ...");
        const verifierKeyBuffer = JWE.decrypt(verifierKeyEncryptedJWE, keyexchangeSharedSecret);
        const verifierKeyString = verifierKeyBuffer.toString();
        const verifierKeyJSON = JSON.parse(verifierKeyString);
        const verifierKey = await jose.JWK.asKey(verifierKeyJSON);
        log("Alice' decrypted verifier key svk (JWE):", verifierKey);
        log("Bob's server now calculates the modulus fingerprint (hash) of the verifier key ...");
        const modulusFingerprint = this.modulusFingerprint(verifierKey);
        log("Modulus fingerprint (hash) of Alice' verifier key svk:", modulusFingerprint);
        log("Bob's server checks if the fingerprint matches the one in the registration message:");
        const kc1Fingerprint = kc1Payload.fingerprint;
        if (kc1Fingerprint === modulusFingerprint) {
            log(true);
        } else {
            log(false);
            res.statusCode = 401;
            const errorMessage = this.errMsgFingerprintMismatch;
            res.setHeader('WWW-Authenticate', `Mutual realm="${this.realmRegister}", sid="${sid}", error="${errorMessage}"`);
            res.end();
        }
        return {verifierKey, modulusFingerprint, keyexchangeSharedSecret};
    }
    // Process registration request message (3) in header parameter kc1 from client (flow 2)
    async processRegRequest(req, res, sid, kc1JSON) {
        const {verifierKey, modulusFingerprint, keyexchangeSharedSecret} = await this.verifyRegReqPayload(sid, kc1JSON);
        log("With his verifier key now at hand,",
            "\nBob's server checks if Alice' signature on the payload (in JWS) is valid ...");
        let verifiedPayload;
        let verifiedClient;
        try {
            verifiedPayload = JWS.verify(kc1JSON, verifierKey, { algorithms: [this.protocolValidation] });
            verifiedClient = true;
        } catch (err) {
            verifiedClient = false;
            console.error('Verification error:', err);
            const errorMessage = this.errMsgInvalidSignature;
            res.statusCode = 401;
            res.setHeader('WWW-Authenticate', `Mutual ${this.protocolParams}, sid="${sid}", error="${errorMessage}"`);
            res.end();
        }
        log("Alice' signature is valid (verified with decrypted verifier key svk):", verifiedClient);
        log("Now, Bob's server checks if svkRetrieval is supported and user has requested it for future logins ...");
        const svkRetrieval = kc1Payload.svkRetrieval && svkRetrievalSupport;
        log("svkRetrieval:", svkRetrieval);
        log("... and extracts Alice' OPFR server (Bob's default or selected by Alice) and client ID ...");
        const kc1PayloadString = kc1JSON.payload;
        const kc1Payload = JSON.parse(kc1PayloadString);
        const oprfServer = kc1Payload.oprfServer;
        const oprfID = kc1Payload.oprfID;
        log(`Alice' OPRF server: "${oprfServer}",\n... and client ID: "${oprfID}"`);
        log("Finally, Bob's server creates a new database record for Alice, containing:\n",
            "- her username and modulus fingerprint,\n",
            "- her OPRF server and client ID, as well as\n",
            "- her (decrypted) verifier key svk, and the svkRetrieval flag.");
        this.userDB[kc1Payload.user] = {fingerprint: modulusFingerprint, oprfServer, oprfID, svk: verifierKey, svkRetrieval};
        log("and updates the registration process with the provided information...");
        this.registrationSessions[sid] = {...this.registrationSessions[sid], kc1Payload};
        log("Then, he signs the registration message (kc1 payload) as a JWS himself,",
            "\nusing svk in the role of a signing key ...");
        const verifierKeyPriv = jose.JWK.asKey({
            kty: 'RSA',
            alg: this.protocolValidation,
            d: verifierKey.e, // use the 'public' exponent as 'private' exponent
            n: verifierKey.n,
        });
        const signatureServer = JWS.createSign({ format: 'compact' }, verifierKeyPriv)
                                   .update(kc1PayloadString)
                                   .final();
        log("Bob's signed JWS:", signatureServer);
        log("... and encrypts it as a JWE with the shared secret key ...");
        const signatureServerEncrypted = JWE.encrypt(signatureServer, keyexchangeSharedSecret, 
                                                        {alg: this.jweAlg, enc: this.jweEnc});
        return signatureServerEncrypted;
    } 
    /**
     * The first registration flow initiates the process with a 401-REG-INIT message from the server.
     * It receives a regular HTTP GET request from the client without any authentication attempt (1),
     * and responds with a 401-R-INIT WWW-Authenticate header (2) including the following parameters:
     * The realm, protocol parameters, a new session ID and the ks1 message containing the following:
     * messageType "User Registration Invitation", a timestamp, the server name, default OPRF server,
     * whether or not svkRetrieval is supported, as well as the server's ECDH keyexchange public key.
    */
    async registerFlow1(req, res) {
        // message type of 401-R-INIT response
        const messageType = this.msgTypeRegInvitation;
        log("Bob's server receives a regular HTTP GET Request (1)",
            "\nwithout any authentication attempt from Alice's browser.",
            "\nBecause it requests the /register endpoint, he initiates a registration process.",
            "\nHe generates a session ID and constructs a registration invitation message (401-R-INIT)",
            "\nwith a ks1 parameter contraining a ECDH public key, timestamp and other parameters.");
        const sid = this.newSID();
        const {ks1JSON, timestampObj, keyexchangeServer} = await this.generateKs1JSON(messageType);
        log("ks1JSON:", ks1JSON);
        const ks1String = JSON.stringify(ks1JSON);
        const ks1 = Buffer.from(ks1String).toString('base64');
        log("He stores the session ID and ks1 in his registration session cache ...")
        registrationSessions[sid] = {ks1JSON, timestampObj, keyexchangeServer};
        log("... and sends the first HTTP Response with the registration invitation message ks1 (2) to Alice's browser.");
        res.setHeader('WWW-Authenticate', 
            `Mutual realm="${realmRegister}", ${protocolParams}, sid="${sid}", ks1="${ks1}"`);
        res.statusCode = 401;
        res.end();
    }
    /**
     * This flow processes the second HTTP request with the registration request (3) from the client.
     * It receives a HTTP request with 401-R-REQ Authorization header including following parameters:
     * The realm and protocol parameters, the session ID, and a kc1 message containing the following:
     * messageType "User Registration Request", timestamp & server name, the OPRF server & client ID,
     * An encrypted svk, fingerprint of the svk modulus and the client's ECDH keyexchange public key.
     * If everything is valid, the user will be registered and the registration process is completed.
     * The 200-R-VFY HTTP response (4) with an WWW-Authenticate header includes following parameters:
     * The realm and protocol parameters, the session ID, and a vks message containing the following:
     * The server's signature on kc1, created with the svk, and encrypted with the shared secret key.
    */
    async registerFlow2(req, res) {
        log("Bob's server receives the user registration request (3) from Alice's browser.",
                "\nThe 401-R-REQ Authorization header including a kc1 parameter.");
        const authHeaderParams = this.parseAuthHeader(authHeader);
        log("Bob's server checks the Authorization header for the following parameters:\n",
                    "- if the realm is 'User Registration',\n",
                    "- if the protocol parameters (version, algorithm and validation) are valid,");
        this.checkAuthHeader(req, res, realmRegister);
        log(" - if the sid is valid and the registration process has not expired,");
        const { sid } = authHeaderParams; 
        this.checkSession(req, res, sid, realmRegister);
        log("Now, he decodes the kc1 parameter, extracts its JWS payload.");
        const { kc1 } = authHeaderParams; 
        const kc1Buffer = Buffer.from(kc1, 'base64');
        const kc1String = kc1Buffer.toString();
        // kc1 is a JWS (JSON Web Signature) with the payload containing the registration request
        const kc1JSON = JSON.parse(kc1String);
        // unverified kc1 payload
        const kc1Payload = kc1JSON.payload;
        log(kc1Payload);
        log("Then, checks if the username requested therein equals the header parameter 'user'.");
        const kc1User = kc1Payload.user;
        if (kc1User === authHeaderParams.user) {
            log(true);
        } else {
            log(false);
            res.statusCode = 401;
            const errorMessage = this.errMsgUserMismatch;
            res.setHeader('WWW-Authenticate', `Mutual realm="${this.realmRegister}", ${this.protocolParams},`
                                            + ` sid="${sid}", error="${errorMessage}"`);
            res.end();
        }
        log("If so, he checks the registration request, validating the servername, timestamp,",
            "\nand server public key, as well as the availability of the requested username:");
        this.checkRegRequest(req, res, sid, kc1Payload);
        log("If everything matches, he starts processing Alice' registration request:");
        const signatureServerEncrypted = await this.processRegRequest(req, res, sid, kc1JSON);
        log("Bob's AES-encrypted JWS (JWE):", signatureServerEncrypted);
        log("Finally, he sends the confirmation message with the JWE to Alice's browser.");
        const vks = JSON.stringify(signatureServerEncrypted);
        res.setHeader('Authentication-Info', 
            `Mutual realm="${this.realmRegister}", ${this.protocolParams}, sid="${sid}", vks="${vks}"`);
        // HTTP response body with registration confirmation
        const kc1Fingerprint = kc1Payload.fingerprint;
        const message = "Registration confirmation\nYou have successfully registered\n"
                      + `with the username ${kc1User}\nand the fingerprint ${kc1Fingerprint}\n`
                      + `at ${this.serverDomain} !\nYou can now login at: /login\n`;
        // 200-VFY-S response
        res.statusCode = 200;
        res.end(message);

    }
    loginFlow1(req, res) {
        const sid = this.newSID();
        const messageType = this.msgTypeLoginInvitation
        const authenticationServer = this.serverName;
        const timestampObj = new Date();
        const timestamp = timestampObj.toISOString();
        const nonceServerBytes = forge.random.getBytesSync(32);
        const nonceServer = forge.util.bytesToHex(nonceServerBytes);
        ks1JSON = {messageType, authenticationServer, timestamp, nonceServer};
        log("Bob's server generates a nonce and a timestamp,",
        "\nand sends a HTTP authorization header with an login invitation to Alice's browser (HTTP Response 1):\n", 
        loginMessage);
        const ks1String = JSON.stringify(ks1JSON);
        const ks1 = Buffer.from(ks1String).toString('base64');
        // 401-INIT message: login invitation message to start the login process
        this.loginSessions[sid] = {ks1JSON, timestampObj};
        res.setHeader('WWW-Authenticate', 
            `Mutual realm="${this.realmLogin}", ${this.protocolParams}, sid="${sid}", ks1="${ks1}", time="3600"`);
        res.statusCode = 401;
        res.end();
    }
    loginFlow2(req, res) { 
        const authHeader = req.headers.authorization;
        const authHeaderParams = this.parseAuthHeader(authHeader);
        const { version, algorithm, validation, realm, sid, user, kc1 } = authHeaderParams; 
        const authHeaderResponse = this.protocolParams + `, realm="${realm}", sid="${sid}", user="${user}"`;
        log("... and checks:\n",
        "- if version is 1,    algorithm is  'mA3PAKE',   validation is  'RSA-PSS' and realm is  'User Login");
        this.checkAuthHeader(req, res, realmLogin);
        log(" - if the sid is valid and the login process has not expired,");
        this.checkSession(req, res, sid, realmLogin);
        const session = loginSessions[sid];
        log("Then he decodes the kc1 parameter..."); 
        const kc1Buffer = Buffer.from(kc1, 'base64');
        const kc1String = kc1Buffer.toString();
        const kc1JSON = JSON.parse(kc1String);
        log("kc1 from Client:", kc1JSON);
        log("... and checks:");
        log(" - if the message type is 'user login request',");
        const kc1MessageType = kc1JSON.messageType;
        if (kc1MessageType === "user login request") {
            log(true);
        } else {
            log(false, "kc1MessageType:", kc1MessageType);
            res.statusCode = 401;
            const errorMessage = "invalid message type";
            res.setHeader('WWW-Authenticate', "Mutual " + authHeaderResponse + `, error="${errorMessage}"`);
            res.end();
        }
        log(" - if the authentication servername and timestamp are matching,");
        // map kc1Payload to variables  
        const kc1AuthenticationServer = kc1JSON.authenticationServer;
        const kc1Timestamp = new Date(kc1JSON.timestamp);
        // map session to variables
        const sessionKs1 = session.ks1JSON;
        const ks1AuthenticationServer = sessionKs1.authenticationServer;
        const ks1Timestamp = sessionKs1.timestampObj;
        // check if all variables match
        if (kc1AuthenticationServer === ks1AuthenticationServer && kc1Timestamp === ks1Timestamp) {
            log(true);
        } else {
            log(false, 
                "kc1AuthenticationServer:", kc1AuthenticationServer, "ks1AuthenticationServer:", ks1AuthenticationServer,
                "kc1Timestamp:", kc1Timestamp, "ks1Timestamp:", ks1Timestamp);
            res.statusCode = 401;
            const errorMessage = "invalid kc1 session parameter (server or timestamp mismatch)";
            res.setHeader('WWW-Authenticate', "Mutual " + authHeaderResponse + `, error="${errorMessage}"`);
            res.end();
        }
        log(" - if the username exists in his database.");
        const userExists = this.userDB[user];
        if (userExists) {
            log(true);
        } else {
            log(false, "user:", user);
            res.statusCode = 401;
            const errorMessage = "user does not exist";
            res.setHeader('WWW-Authenticate', "Mutual " + authHeaderResponse + `, error="${errorMessage}"`);
            res.end();
        }
        log("If so, Bob's server creates a key exchange message containing:",
        "\n- message type, timestampt and authentication server,",
        "\n- Alice' username, fingerprint and modulus, as well as",
        "\n- her OPRF server and client ID, and her svkRetrieval permit.");
        const messageType = "User Login Keyexchange";
        const timestampObj = new Date();
        const timestamp = timestampObj.toISOString();
        const fingerprint = this.userDB[user].fingerprint;
        const modulus = svk.n.toString();
        const oprfServer = this.userDB[user].oprfServer;
        const oprfID = this.userDB[user].oprfID;
        const svkRetrieval = this.userDB[user].svkRetrieval;
        const ks2JSON = {messageType, timestamp, authenticationServer, username, fingerprint, modulus,
                     oprfServer, oprfID, svkRetrieval};
        log("Bob's server updates the session timestamp ..."); 
        timeStampObj = new Date();
        log("... and adds the key exchange message to the session record.");
        loginSessions[sid] = {...loginSessions[sid], kc1JSON, ks2JSON, timestampObj};
        log("Then, he sends it as HTTP Response 2 to Alice's browser:\n", ks2JSON);
        const ks2String = JSON.stringify(ks2JSON);
        const ks2 = Buffer.from(ks2String).toString('base64');
        res.statusCode = 401;
        res.setHeader('WWW-Authenticate', `Mutual ${authHeaderResponse}, ks2="${ks2}", time="3600"`);
        res.end();
    }
    async loginFlow3(req, res) { 
        const authHeaderParams = this.parseAuthHeader(authHeader);
        const { version, algorithm, validation, realm, sid, user, kc2 } = authHeaderParams; 
        const authHeaderResponse = `version="${version}", algorithm="${algorithm}", validation="${validation}", `
                                 + `realm="${realm}", sid="${sid}", user="${user}"`;
        log("... and checks:\n",
        "- if version is 1,    algorithm is  'mA3PAKE',   validation is  'RSA-PSS' and realm is  'User Login");
        this.checkAuthHeader(req, res, realmLogin);
        log(" - if the sid is valid and the login process has not expired,");
        this.checkSession(req, res, sid, realmLogin);
        const session = loginSessions[sid];
        log(" - if the user parameter matches the one in the session record.");
        const sessionUser = session.ks2JSON.username;
        if (user === sessionUser) {
            log(true);
        } else {
            log(false, "user:", user, "sessionUser:", sessionUser);
            res.statusCode = 401;
            const errorMessage = errMsgUserMismatch;
            res.setHeader('WWW-Authenticate', "Mutual " + authHeaderResponse + `, error="${errorMessage}"`);
            res.end();
        }
        log("Then he decodes the kc2 parameter as JSON, ...");
        const kc2Buffer = Buffer.from(kc2, 'base64');
        const kc2String = kc2Buffer.toString();
        const kc2JSON = JSON.parse(kc2String);
        log("... extracts the authenticated client public key (JWS), ...")
        const kc2ClietPubKeyJWS = JWS.parse();
        log("kc2JWS from Client:", kc2ClietPubKeyJWS);
        log("... and checks if the signature is valid with svk (as \"public key\").");
        const svkJSON = userDB[user].svk;
        const svkPub = jose.JWK.asKey({
            kty: 'RSA',
            alg: 'PS256',
            e: svkJSON.e.toString(16),
            n: svkJSON.n.toString(16)
        });
        let clientPublicKey;
        let kc2JWSVerified;
        try {
            clientPublicKey = JWS.verify(kc2ClietPubKeyJWS, svkPub, { algorithms: ['PS256'] });
            kc2JWSVerified = true;
        } catch (err) {
            console.error('Verification error:', err);
            kc2JWSVerified = false;
        }
        log("Bob's server was able to verify Alice' signature:", kc2JWSVerified);
        log("He extracts the authenticated DH client public key as JWK ...");
        const clientPublicKeyJWK = JWK.asKey(clientPublicKey);
        log("kc2 client public key JWK:", kc2ClientPubKeyJWK);
        log("Now, he checks the key type, creates his own key-pair (matching Alice' parameters) ...");
        const {kty, crv} = clientPublicKeyJWK;
        if (kty !== "EC") {
            log(false, "kty:", kty);
            res.statusCode = 401;
            const errorMessage = "invalid or unsupported JWK key type";
            res.setHeader('WWW-Authenticate', "Mutual " + authHeaderResponse + `, error="${errorMessage}"`);
            res.end();
        }
        const serverKeyPair = await JWK.createKeyPair(kty, crv);
        log("... and derives the shared secret from his private key and Alice' public key.");
        const sharedSecret = calculate('ECDH-ES', serverKeyPair, clientPublicKeyJWK);
        log("Shared secret:\n", sharedSecret);
        const serverPublicKeyJWK = sharedSecret.toJSON();
        log("Bob's server public key:", serverPublicKeyJWK);
        const serverPublicKey = JSON.stringify(serverPublicKeyJWK);
        log("Bob's server now creates a login challenge message containing:",
                "\n- message type, timestampt and authentication server,",
                "\n- Alice' username and fingerprint,",
                "\n- svkRetrieval: the server's verifier key svk will be sent encrypted in confirmation message,",errorMessage);
        const timestampObj = new Date();
        const timestamp = timestampObj.toISOString();
        const svkRetrievalPermit = userDB[user].svkRetrievalPermit;
        const svkRetrievalRequested = session.kc1.svkRetrieval;
        const svkRetrieval = svkRetrievalSupport && svkRetrievalPermit && svkRetrievalRequested;
        const challengeJSON = {messageType, timestamp, authenticationServer, 
                         user, fingerprint, svkRetrieval, clientPublicKey, serverPublicKey};
        log("Now, he signs the login challenge message with his verifier key svk ...");
        const challengeString = JSON.stringify(challengeJSON);
        const challengeJWS = JWS.sign(challengeString, svk, {alg: 'PS256'});
        log("Signed login challenge message:", challengeJWS);
        log("... and encrypts it with the shared secret with AES Key Wrap (A256KW) and AES GCM (A256GCM).");
        const challenge = JWE.encrypt(challengeJWS, sharedSecret, {alg: 'ECDH-ES+A256KW', enc: 'A256GCM'});
        log("Bob's server updates the session timestamp ...");
        timeStampObj = new Date();
        log("... and adds the login challenge message to the session record.");
        loginSessions[sid] = {... loginSessions[sid], kc2JSON, sharedSecret, challengeJSON, timestampObj};
        log("Then, he sends the encrypted challenge together with his server public key as HTTP Response 3 to Alice's browser:\n", ks3JSON);
        const ks3JSON = {serverPublicKey, challenge};
        const ks3String = JSON.stringify(ks3JSON);
        const ks3 = Buffer.from(ks3String).toString('base64');
        res.statusCode = 401;
        res.setHeader('WWW-Authenticate', `Mutual ${authHeaderResponse}, ks3="${ks3}", time="3600"`);
        res.end();
    }
    loginFlow4(req, res) { 
        log("Bob's server receives the user login confirmation message (HTTP Request 4)...");
        const authHeaderParams = this.parseAuthHeader(authHeader);
        const { version, algorithm, validation, realm, sid, user, kc3 } = authHeaderParams; 
        const authHeaderResponse = `version="${version}", algorithm="${algorithm}", validation="${validation}", `
                                 + `realm="${realm}", sid="${sid}", user="${user}"`;
        log("... and checks:\n",
        "- if version is 1,    algorithm is  'mA3PAKE',   validation is  'RSA-PSS' and realm is  'User Login");
        this.checkAuthHeader(req, res, realmLogin);
        log(" - if the sid is valid and the login process has not expired,");
        this.checkSession(req, res, sid, realmLogin);
        const session = loginSessions[sid];
        log(" - if the user parameter matches the one in the session record.");
        const sessionUser = session.ks2JSON.username;
        if (user === sessionUser) {
            log(true);
        } else {
            log(false, "user:", user, "sessionUser:", sessionUser);
            res.statusCode = 401;
            const errorMessage = errMsgUserMismatch;
            res.setHeader('WWW-Authenticate', "Mutual " + authHeaderResponse + `, error="${errorMessage}"`);
            res.end();
        }
        log("Then he decodes the kc3 parameter, ...");
        const kc3Buffer = Buffer.from(kc3, 'base64');
        const kc3String = kc3Buffer.toString();
        const kc3JSON = JSON.parse(kc3String);
        log("kc3 from Client:", kc3JSON);
        log("... extracts the kc3 client signature JWT (JWS) ...");
        const kc3ClientJWS = JWS.parse(kc3JSON.clientSignature);
        log("kc3 client JWS:", kc3ClientJWS);
        log("... and verifies the JWT signature (JWS) with Alice' verifier key svk (as \"public key\").");
        const svkJSON = userDB[user].svk;
        const svkPub = JWK.asKey({
            kty: 'RSA',
            alg: 'PS256',
            e: svkJSON.e,
            n: svkJSON.n
        });
        let verifiedPayload;
        try {
            verifiedPayload = JWS.verify(kc3ClientJWS, svkPub, { algorithms: ['PS256'] });
            log(true, "Alice' signature is valid (verified with verifier key svk).");
        } catch (err) {
            console.error(false, 'Verification error:', err);
            res.statusCode = 401;
            const errorMessage = "invalid signature";
            res.setHeader('WWW-Authenticate', "Mutual " + authHeaderResponse + `, error="${errorMessage}"`);
            res.end();
        }
        log("He checks:");
        log(" - if the payload is matching the ks3 session record.");
        const sessionKs3 = session.ks3JSON;
        if (verifiedPayload === sessionKs3) {
            log(true);
        } else {
            log(false, "kc3ClientJwsPayload:", verifiedPayload, "sessionKs3:", sessionKs3);
            res.statusCode = 401;
            const errorMessage = "payload mismatch";
            res.setHeader('WWW-Authenticate', "Mutual " + authHeaderResponse + `, error="${errorMessage}"`);
            res.end();
        }
        log("he sends a login confirmation message to Alice's browser.");
        log("\nIf Alice has registered with svkRetrieval and requesets it now, he includes the encrypted svk.");
        const messageType = "User Login Confirmation";
        const timestampObj = new Date();
        const timestamp = timestampObj.toISOString();
        const svkRetrieval = verifiedPayload.svkRetrieval;
        const ks4JSON = {messageType, timestamp, authenticationServer, user};
        if (svkRetrieval) {
            const svk = JSON.stringify(svkJSON);
            ks4JSON = {...ks4JSON, svk};
        }
        log("Bob retrieves the shared secret from the session record ...");
        const sharedSecret = session.sharedSecret;
        log("Shared secret:\n", sharedSecret);
        log("... and encrypts the confirmation message (potentially including the svk) with the shared secret.");
        const ks4JWE = JWE.encrypt(ks4JSON, sharedSecret, {alg: 'ECDH-ES+A256KW', enc: 'A256GCM'});
        const ks4 = Buffer.from(ks4JWE).toString('base64');
        log("Bob's server updates the session timestamp ...");
        timeStampObj = new Date();
        timestamp = timeStampObj.toISOString();
        log("... and adds the login confirmation message to the login session record.");
        loginSessions[sid] = {... loginSessions[sid], kc3JSON, ks4JSON};
        log("Then, he archives the login session record with the timestamp to the user DB...");
        userDB[user].loginSessions[timestamp] = loginSessions[sid];
        log("... deletes the login session record ...");
        delete loginSessions[sid];
        log("... recreates sid and adds the user and the shared secret to the loggedinUsers.");
        sid = this.newSID();
        this.loggedinUsers[user] = {sid, timestampObj, sharedSecret};
        log("Finally, he sends the login confirmation message to Alice's browser (HTTP Response 4):\n", ks4JSON);
        res.statusCode = 200;
        res.setHeader('WWW-Authenticate', `Mutual ${authHeaderResponse}, ks4="${ks4}", time="3600"`);
        res.end();
    }
    logoutFlow1(req, res) {
        const realm = "User Logout";
        const sid = this.newSID();
        const messageType = "User Logout Invitation";
        const timestampObj = new Date();
        const timestamp = timestampObj.toISOString();
        const nonceServerBytes = forge.random.getBytesSync(32);
        const nonceServer = forge.util.bytesToHex(nonceServerBytes);
        ks1JSON = {messageType, authenticationServer, timestamp, nonceServer};
        log("Bob's server generates a nonce and a timestamp,",
        "\nand sends a HTTP authorization header with an logout invitation to Alice's browser (HTTP Response 1):\n", 
        logoutMessage);
        const ks1String = JSON.stringify(ks1JSON);
        const ks1 = Buffer.from(ks1String).toString('base64');
        // 401-INIT message: logout invitation message to start the logout process
        logoutSessions[sid] = {ks1JSON, timestampObj};
        res.setHeader('WWW-Authenticate', 
            `Mutual ${protocolParams}", realm="${realm}", sid="${sid}", ks1="${ks1}", time="3600"`);
        res.statusCode = 401;
        res.end();
    }
    logoutFlow2(req, res) { 
        const messageTypeClient = "user logout request";
        const messageTypeServer = "user logout confirmation";
        log("Bob's server receives the user logout request message (HTTP Request 2)...");
        const authHeaderParams = this.parseAuthHeader(authHeader);
        log("... and checks:\n",
        "- if version is 1, algorithm is 'mA3PAKE', validation is 'RSA-PSS' and realm is 'User Logout");
        this.checkAuthHeader(req, res, realmLogout);
        const { sid, user, kc1 } = authHeaderParams; 
        log(" - if the sid is valid and the logout process has not expired,");
        this.checkSession(req, res, sid, realmLogout);
        const session = logoutSessions[sid];
        log(" - if the provided user is currently logged in.");
        const loggedinUser = loggedinUsers[user];
        if (loggedinUser) {
            log(true);
            log("Then he decodes the kc1 parameter..."); 
            const kc1ClientJWS = JWS.parse(kc1);
            log("... and checks if the clients signature is valid.");
            const svkJSON = userDB[user].svk;
            const svkPub = JWK.asKey({
                kty: 'RSA',
                alg: 'PS256',
                e: svkJSON.e,
                n: svkJSON.n
            });
            let verifiedPayload;
            let payloadIsMatching;
            try {
                verifiedPayload = JWS.verify(kc1ClientJWS, svkPub, { algorithms: ['PS256'] });
                log(true, "Alice' signature is valid (verified with verifier key svk).");
                log8("He also checks if the payload is matching the ks1 session record.");
                const sessionKs1 = session.ks1JSON;
                if (verifiedPayload === JSON.stringify(sessionKs1)) {
                    log(true);
                    payloadIsMatching = true;
                } else {
                    log(false, "kc1ClientJwsPayload:", verifiedPayload, "sessionKs1:", sessionKs1);
                    payloadIsMatching = false;
                }
            } catch (err) {
                console.error(false, 'Verification error:', err);
                clientSignatureValid = false;
            }

        } 
        if (!loggedinUser || !clientSignatureValid || !payloadIsMatching) {
            log(false, "user:", user);
            res.statusCode = 401;
            const errorMessage = "user not logged in, or invalid signature or payload";
            res.setHeader('WWW-Authenticate', `Mutual ${protocolParams}", realm="${realmLogout}", sid="${sid}", error="${errorMessage}"`);
            res.end();
        }
        log("He creates a logout confirmation message ...");
        const timestampObj = new Date();
        const timestamp = timestampObj.toISOString();
        const ks2JSON = {messageTypeServer, timestamp, authenticationServer, user};
        log("... signs it with svk ...");
        const ks2String = JSON.stringify(ks2JSON);
        const ks2JWS = JWS.sign(ks2String, svk, {alg: 'PS256'});
        const ks2JWSString = JSON.stringify(ks2JWS);
        log("... encrypts it with the shared secret ...");
        const sharedSecret = loggedinUser.sharedSecret;
        const ks2JWE = JWE.encrypt(ks2JWSString, sharedSecret, {alg: 'ECDH-ES+A256KW', enc: 'A256GCM'});
        const ks2 = Buffer.from(ks2JWE).toString('base64');
        log("... and sends it to Alice's browser (HTTP Response 2):\n", ks2JSON);
        res.statusCode = 200;
        res.setHeader('WWW-Authenticate', `Mutual ${protocolParams}", realm="${realmLogout}", sid="${sid}", ks2="${ks2}", time="3600"`);
        res.end();
    }
    transactionFlow1(req, res) {
        log("Bob's server receives a regular HTTP Request 1. ",
        "\nIts request body contains an unauthorized transaction request message,",
        "\ne.g. {action:{user:'alice1',type:'purchase',itemNr:12345,price:99.99,currency:'EUR'}}.",
        "\nBecause it was directed at the /transaction endpoint, it needs to be authorized.",
        "\nBob's server initiates a transaction process to get a binding signature from Alice's.");
        const action = req.body.action;
        const realm = "User Transaction";
        const sid = this.newSID();
        const messageType = "User Transaction Invitation";
        const timestampObj = new Date();
        const timestamp = timestampObj.toISOString();
        const nonceServerBytes = forge.random.getBytesSync(32);
        const nonceServer = forge.util.bytesToHex(nonceServerBytes);
        ks1JSON = {messageType, authenticationServer, timestamp, nonceServer};
        log("Bob's server generates a nonce and a timestamp,",
        "\nand sends a HTTP authorization header with an transaction invitation to Alice's browser (HTTP Response 1):\n", 
        transactionMessage);
        const ks1String = JSON.stringify(ks1JSON);
        const ks1 = Buffer.from(ks1String).toString('base64');
        // 401-INIT message: transaction invitation message to start the transaction process
        transactionSessions[sid] = {ks1JSON, timestampObj};
        res.setHeader('WWW-Authenticate', `Mutual ${protocolParams}", realm="${realm}", sid="${sid}", ks1="${ks1}", time="3600"`);
        res.statusCode = 401;
        res.end();
    }
    errorFlow(req, res, realm) {
        res.statusCode = 404;
        errorMessage = this.errMsgInvalidRequest;
        res.setHeader('WWW-Authenticate', 
            `Mutual ${protocolParams}", realm="${realm}", error="${errorMessage}"`);
        res.end();
    }
    // Start the server, listening on the specified port
    listen(port) {
        this.server.listen(port);
    }
}

// #region Demo Server
// Instantiatiate and start the mA3PAKE Demo Server
const serverDomain = "bob.example.com";;
//const oprfServerDefault = "oprf.example.com";
//const svkRetrievalSupport = true;
const myServer = new mA3PAKEserver(serverDomain, oprfServerDefault, svkRetrievalSupport);
myServer.listen(3000);
// #endregion


const axios = require('axios');
// Step 1: Generate a key-pair generator (KPG) and a signing key (ssk)
const generatekeyPairGenBaseRSA  = require('../mA3PAKEkeyPairGen/generateKeyPairGenBaseRSA.js');
const isSafePrime = require('../utils/isSafePrime.js');
const generatefingerprintRandomart = require('../utils/fingerprintRandomart.js');
// number of threads to use for key generation (number of detected CPU cores)
const threads = isBrowser ? navigator.hardwareConcurrency : require('os').cpus().length;; 
// const nBits = 1024;
const base64url = require('base64url');
const mA3PAKEkeyPairGen = require('../mA3PAKEkeyPairGen/mA3PAKEkeyPairGen.js');
const { sign } = require('node:crypto');
const { parseArgs } = require('node:util');

async function preparationPhase() {
    log("### PREPARATION PHASE ###"
      + "\nBefore Alice can register with Bob, she needs to generate a key-pair generator base."
      + "\nIn case of RSA, the key base consists of (p,q), where both are safe primes.");
    // Generate RSA key base
    log("Alice opens her mA3PAKE Browser-Plugin, an klicks 'Generate new Key-pair Generator Base'.",
        "\nHer Browser now starts creating a new RSA-type Key Base consisting of two Safe Primes, \nfor", 
        nBits, "bit RSA, so her Browser uses ", threads, "threads in parallel to speed up the process.");
    // Instantiate KeyPairGenerator
    const keyPairGen = new mA3PAKEkeyPairGen();
    // Initialize KeyPairGenerator with base generation
    await keyPairGen.init({type: 'RSA', threads: 8, nBitsRSA: 1024});
    // const base = await mA3PAKEkeyPairGen.generateBase({nBitsRSA:nBits});  
    const base = await keyPairGen.getBase();
    log("Alice' new RSA-type Key-pair Generator (KPG) Base has been successfully generated",
        "(and the Browser-Plugin's RSA Key-pair Generator was initialized with it):");
    log(JSON.stringify(base, null, 4));
    // const p = base64urlToBigInteger(base.p);
    // const q = base64urlToBigInteger(base.q);
    // log("base.p:", p.toString(10), "\nbase.q:", q.toString(10));
    const fingerprint = await keyPairGen.getFingerprint();
    // log("Modulus fingerprint:\n" + fingerprint);
    log("Alice' browser now generates a randomart image of the base fingerprint (hashed modulus)...");
    const fingerprintRandomart = await generatefingerprintRandomart(fingerprint);
    log("And displays it to Alice:\n" + fingerprintRandomart,
    "\nAlice should memorize this fingerprint (as randomart) of her personal KPG Base.",
    "\nOptionally, she can store the key base in a key vault app on a trusted device",
    "\nso she can later use it for registrations with other servers with the same fingerprint.",
    "\nInstead of the key vault:",
    "\nShe can also recover p and q from any verifier exponent v and corresponding secret exponent s.",
    "\nFor this, she permits the server to send her the verifier exponent v after successful authentication.",
    "\nThis permit is part of the registration and optionally commitment (registration authority) process.");
    log("Alice' browser is now ready to register with Bob's server.");
    return base;
}

/**
 * 
 *
 console.log("Alice's browser receives the HTTP authorization header with the rgistration invitation.",
 "\nHe verifies the timestamp and asks user Alice if she wants to register with", registrationServer,
 "\nAlice confirms and her browser asks her if she wants to use the default OPRF server", oprfServerBob,
 "\nThe browser might also be configured to override it with a custom OPRF server by default.",
 "\n(In any case, her choice should be based on the trustworthiness of the OPRF server,",
 "\nas well as her privacy and availability preferences.)");
const oprfURL = "https://" + oprfServer;
console.log("She chose a custom OPRF server", oprfServer);
// This can be any OPRF client identifier (e.g. a random alphanumeric string, email address, username, etc.)
const oprfID = "0x0pRfC1i3ntId"; 
console.log("Her browser checks if the OPRF server is available, generates a random OPRF client ID,",
 "\ndisplays it and waits for her to confirm:", oprfID,
 "\nIn most cases, she will just confirm, but she can also customize it (e.g. her email address or username).",
 "\nIn case Bob's server offers svkRetrieval, Alice can decide if wants to use it to recover her key base later.",
 "\nAfter OPRF server and client ID selection/confirmation, and svkRetrieval decision,",
 "\nAlice' browser promts her to enter her username and password.");
console.log("Alice enters her username and password:\n", username, "\n", password);
console.log("Her browser is starting the OPRF evaluation of her password, now ...");
let passseed;
try {
passseed = await oprfClient(oprfURL, oprfID, password, "hex");
console.log("OPRF has been successfully evaluated. The password-derived seed (passseed) is:\n", 
Buffer.from(passseed).toString('hex'));
} catch (error) {
console.error("An error occurred:", error);
}
console.log("Starting derivation of secret (signing) exponent s from passseed ...");
const s = new BigInteger(deriveRSAExponent(passseed, nBits - 1));
console.log("Exponent s has been derived:", s.toString(radix));
console.log("Starting derivation of verifier exponent v from s and phi ...");
const v = new BigInteger(deriveVerifierKey(s, phi));
console.log("Exponent v has been derived:", v.toString(radix));
console.log("Browser creates the signing key ssk (s, n) ...");
const ssk = pki.setRsaPublicKey(n, s);
console.log("…and verifier key svk (v, n) ...");
const svk = pki.setRsaPublicKey(n, v);
console.log("ssk and svk have been created.");
 */

function parseAuthHeader(authHeader) {
    const authHeaderParts = new parsers.WWW_Authenticate(authHeader);
    const authHeaderParams = authHeaderParts.parms;
    return authHeaderParams;
}

function signMessage(message, signingKey) {
    const messageString = JSON.stringify(message);
    const messageJWS = JWS.sign(messageString, signingKey, {alg: 'PS256'});
    return messageJWS;
}
async function registerUser(username, password, 
    keyPairGeneratorBase, oprfServer, oprfClientID, svkRetrievalPermit) {
    
    // Step 2: Send HTTP Request 1 to the server's /register endpoint
    let ks1, kc1, kc2, ks2, keyexchangeClient, keyexchangeClientPubkey, keyexchangeClientPrivate,
    keyexchangeServerPubkey, keyexchangeSharedSecret;
    try {
        const response = await axios.post('http://localhost:3000/register');
        // Handle 2xx status code response
    } catch (error) {
        if (error.response && error.response.status === 401) {
            const response = error.response;
            let parsed;
            // Step 3: Extract ks1 parameter from the response
            if (response.headers['www-authenticate']) {
                parsed = new parsers.WWW_Authenticate(response.headers['www-authenticate']);
                log("Parsed WWW-Authenticate header:", JSON.stringify(parsed, null, 4));           
            } else {
                console.log('Authorization header is missing');
            }
            const ks1 = parsed.parms.ks1;
            // decode ks1 (base64)
            const ks1Buffer = Buffer.from(ks1, 'base64');
            const ks1String = ks1Buffer.toString();
            const ks1JSON = JSON.parse(ks1String);
            log("ks1 from Server:", JSON.stringify(ks1JSON, null, 4));

            // instantiate key-pair generator with key-pair generator base
            const keyPairGen = new mA3PAKEkeyPairGen(keyPairGeneratorBase);
            keyPairGen.init();

            // Derive passseed from password with OPRF
            const OprfURL = "https://" + oprfServer;
            const passseed = await oprfClient(OprfURL, oprfClientID, password, "hex");
            // generate a generator base key-pair (ssk, svk) with oprfClient()
            const keyPair = keyPairGen.generateKeyPair(passseed);
            const ssk = keyPair.ssk;
            log("ssk:", ssk);

            log("keyexchangeServerPubkey:", JSON.stringify(ks1JSON.keyexchangeServerPubkey, null, 4));

            // Generate keyexchangeClientPubkey ECDH key pair
            keyexchangeServerPubkey = ks1JSON.keyexchangeServerPubkey;

            keyexchangeClient = await JWK.createKey('EC', "P-256", {use: 'enc', alg: 'ECDH-ES'});
            keyexchangeClientPrivate = keyexchangeClient.toJSON(true);
            console.log("keyexchangeClientPrivate:", JSON.stringify(keyexchangeClientPrivate, null, 4));
            keyexchangeClientPubkey = keyexchangeClient.toJSON(false);
            console.log("keyexchangeClientPubkey:", JSON.stringify(keyexchangeClientPubkey, null, 4));
            // create keystore from keyexchangeClient
            const keystore = jose.JWK.createKeyStore();
            await keystore.add(keyexchangeClient);

            // Derive shared secret from keyexchangeClient and keyexchangeServerPubkey
            keyexchangeSharedSecret = await jose.JWE.createDecrypt(keystore).decrypt({
                use: 'enc',
                alg: 'ECDH-ES',
                enc: 'A256GCM',
                key: keyexchangeServerPubkey,

            });  
            
            console.log("keyexchangeSharedSecret:",
                keyexchangeSharedSecret.plaintext.toString('utf8')); // 'shared secret'
            // Step 4: Create registration request message (kc1)
            kc1 = {
                messageType: "User Registration Request",
                timestamp: ks1JSON.timestamp,
                registrationServer: ks1JSON.registrationServer,
                username,
                fingerprint: keyPairGeneratorBase.fingerprint,
                oprfServer,
                oprfClientID,
                svkRetrievalPermit,
                keyexchangeServerPubkey: ks1JSON.keyexchangeServerPubkey,
                keyexchangeClientPubkey
            };
            // Step 5: Sign kc1 message with signing key (ssk)
            const signedKc1 = signMessage(kc1, 'ssk');
            // Step 6: Send signed kc1 message as HTTP Request 2 to the server's /register endpoint
            try {
                const response = await axios.post('http://localhost:3000/register', { kc1: signedKc1 });
                // Handle 2xx status code response
            } catch (error) {
                if (error.response && error.response.status === 401) {
                   // Step 7: Handle the response received from the server (ks2 parameter)
                   const ks2 = parseAuthHeader(error.response.headers['www-authenticate']);
                   // Step 8: Decrypt payload of ks2 using shared secret
                   const decryptedPayload = decryptPayload(ks2.payload, 'sharedSecret');
                   // Step 9: Verify signature of payload using signing key (ssk)
                   const isSignatureValid = verifySignature(decryptedPayload, ks2.signature, 'ssk');
                   if (isSignatureValid) {
                       console.log('Registration successful!');
                   } else {
                       console.log('Registration failed. Invalid signature.');
                   }
               } else if (error.request) {
                   // The request was made but no response was received
                   console.log(error.request);
               } else {
               // Something happened in setting up the request that triggered an Error
               console.log('Error', error.message);
               }
           }
       }
    }
}


// Call the registerUser function with the necessary parameters
// generate random oprfClientID
async function userDemo() {
    // The preparation phase is not part of the mA3PAKE protocol.
    // It is just a demonstration of how the key-pair generator base is generated.
    // And how a KPG could be implemented in a browser plugin.
    const kpgb = await preparationPhase();

    // User credentials
    const user = 'alice1';
    const pass = 'password123';
    // OPRF server and client ID
    const oSrv = 'oprf.reich.org';
    const clID = '0x0pRfC1i3ntId';
    // SVK retrieval permit
    const svkR = true;
    // Register user with the server using above parameters and the generated KPG base
    const successful = registerUser(user, pass, kpgb, oSrv, clID, svkR);
    return successful;
}
userDemo();


async function registerUser_old(username, password, 
    keyPairGeneratorBase, oprfServer, oprfClientID, svkRetrievalPermit) {
    // Step 2: Send HTTP Request 1 to the server's /register endpoint
    let ks1, kc1, kc2, ks2, keyexchangeClient, keyexchangeClientPubkey, keyexchangeSharedSecret;
    axios.post('http://localhost:3000/register')
    .then(response => {
        // Handle 2xx status code response
    })
    .catch(error => {
        if (error.response) {
            // The request was made and the server responded with a status code
            // that falls out of the range of 2xx
            if (error.response.status === 401) {
                const response = error.response;
                let parsed;
                // Step 3: Extract ks1 parameter from the response
                if (response.headers['www-authenticate']) {
                    parsed = new parsers.WWW_Authenticate(response.headers['www-authenticate']);
                    log("Parsed WWW-Authenticate header:", JSON.stringify(parsed, null, 4));           
                } else {
                    console.log('Authorization header is missing');
                }
                const ks1 = parsed.parms.ks1;
                // decode ks1 (base64)
                const ks1Buffer = Buffer.from(ks1, 'base64');
                const ks1String = ks1Buffer.toString();
                const ks1JSON = JSON.parse(ks1String);
                log("ks1 from Server:", JSON.stringify(ks1JSON, null, 4));

                // Generate keyexchangeClientPubkey ECDH key pair
                //keyexchangeClient = await JWK.createKey(serverDHkty, serverDHcurveName, {use: 'enc'});
                keyexchangeClientPubkey = keyexchangeClient.toJSON(false);
                keyexchangeSharedSecret = calculate('ECDH-ES', keyexchangeClient, keyexchangeServerPubkey);
                // Step 4: Create registration request message (kc1)
                kc1 = {
                    messageType: "User Registration Request",
                    timestamp: ks1.timestamp,
                    registrationServer: ks1.registrationServer,
                    username,
                    fingerprint: keyPairGeneratorBase.fingerprint,
                    oprfServer,
                    oprfClientID,
                    svkRetrievalPermit,
                    keyexchangeServerPubkey: ks1.keyexchangeServerPubkey,
                    keyexchangeClientPubkey
                };
                // Step 5: Sign kc1 message with signing key (ssk)
                const signedKc1 = signMessage(kc1, 'ssk');
                // Step 6: Send signed kc1 message as HTTP Request 2 to the server's /register endpoint
                axios.post('http://localhost:3000/register', { kc1: signedKc1 })
                .then(response => {
                    // Handle 2xx status code response
                })
                .catch(error => {
                    if (error.response) {
                        // The request was made and the server responded with a status code
                        // that falls out of the range of 2xx
                        if (error.response.status === 401) {
                            // Step 7: Handle the response received from the server (ks2 parameter)
                            const ks2 = parseAuthHeader(error.response.headers['www-authenticate']);
                            // Step 8: Decrypt payload of ks2 using shared secret
                            const decryptedPayload = decryptPayload(ks2.payload, 'sharedSecret');
                            // Step 9: Verify signature of payload using signing key (ssk)
                            const isSignatureValid = verifySignature(decryptedPayload, ks2.signature, 'ssk');
                            if (isSignatureValid) {
                                console.log('Registration successful!');
                            } else {
                                console.log('Registration failed. Invalid signature.');
                            }
                        } else if (error.request) {
                            // The request was made but no response was received
                            console.log(error.request);
                        } else {
                        // Something happened in setting up the request that triggered an Error
                        console.log('Error', error.message);
                        }
                    }
                });
            }
        } else if (error.request) {
            // The request was made but no response was received
            console.log(error.request);
        } else {
            // Something happened in setting up the request that triggered an Error
            console.log('Error', error.message);
        }
    });
}

/** Use-case scenario and demo script for the Mutual authentication protocol mA3PAKE
 * 
 * THE KEY-PAIR GENERATOR (KPG) ITS BASE - GENERAL CONCEPT:
 * The KPG base is the basis or 'configuration' for the (re)creation of the KPG.
 * INPUT: The KPG takes a high-entropy seed (in hex) as input.
 * PROCESSING: 
 * 1. From the given input seed it deterministically derives the secret signing key (ssk),
 *    which includes a component that is a one-way function (OWF) of KPG base.
 * 2. From the ssk it derives the corresponding secret verifier key (svk).
 *    The ssk-svk derivation is using an(other) one-way function (OWF),
 *    that is dependent on the KPG base as its (otherwise randomized) 'configuration'.
 *    The svk may also include a component that is a one-way function (OWF) of KPG base.
 * OUTPUT: Then it outputs the key-pair (ssk, svk).
 * 
 * AN RSA-BASED INSTANCIATION OF THE KPG AND ITS BASE:
 * The KPG base consists of (p,q), where both are safe primes.
 * The KPG is based on RSA key-pair generation.
 * INPUT: It takes a high-entropy seed (in hex) as input.
 * PROCESSING:
 * 1. It derives the secret signing key (ssk) from the given input seed:
 * 1.1 Calculate the modulus n = p * q (OWF of the KPG base assuming the factorization problem is hard).
 * 1.2 Deterministically derive the secret exponent s of length nBits - 1 from the input seed,
 *     using e.g. PBKDF2 with SHA-256 and a high iteration count.
 * 1.3 Creates the signing key ssk = (n, s). (n is the component that is an OWF of KPG base.)
 * 2. It derives the corresponding secret verifier key (svk) from the ssk:
 * 2.1 Calculate the totient phi = (p - 1) * (q - 1).
 * 2.2 Use the totient phi and the secret exponent s to calculate the verifier exponent v,
 *     which is the multiplicative inverse of s modulo phi (OWF dependent on (p,q) as KPG base).
 * 2.3 Create the verifier key svk = (n, v). (n is the component that is an OWF of KPG base.)
 * OUTPUT: Then it outputs the key-pair (ssk, svk).
 * 
 * OPRF SERVICES AND THE SECRET GENERATION OF PASSWORD-DERIVED SEEDS (PASSSEED) - GENERAL CONCEPT:
 * Oblious Pseudo Random Functions (OPRF) can be used to derive high-entropy outputs from low-entropy inputs,
 * revealing nothing:
 * - neither the input nor the output to:
 * -- neither passive or active attacks on the input or output,
 * -- nor to the OPRF function itself,
 * - even if: 
 * -- the OPRF function is used multiple times, and/or
 * -- the input is reused, and/or
 * -- the OPRF function is malicious (trying to learn its input or output).
 * Due to the nature of the preparation and handlung if its inputs and outputs,
 * OPRF functions are suitable for use in a client-server architecture.
 * 
 * OPRF Clients can evaluate the OPRF function of a given (low-entropy) input by the following steps:
 * 0. Chose an OPRF server with a supported OPRF function, implementation and protocol.
 * 1. Prepare the (low-entroy) input:
 * 1.1 Use a hash-to-group (H2G) function to map the input to a member of a group of elements of a prime order p,
 * 1.2 Generate a random (high-entroy) mask for that group.
 * 1.3 Use a blinding function with that mask to blind the input as a (high-entropy) masked group element.
 * 1.4 Encode the blinded input using an encoding supported by the OPRF server.
 * 2a Send the encoded blinded input (masked group element) to the OPRF server and keep the mask secret.
 * 2b Optionally: Include a client ID in the request to be recognized by the OPRF server.
 * 3. Receive the response with the encoded (high-entropy) blinded output from the OPRF server.
 * 4. Prepare the (high-entropy) output:
 * 4.1 Use the decoding function to decode the blinded output to a masked salted group element.
 * 4.2 Use the unblinding function with the original mask to unblind the output to a salted group element.
 * 4.3 Use an encoding function to encode the salted group element to a (high-entropy) output, e.g. in hex.
 * 5. Return the (high-entropy) output.
 * 
 * OPRF Servers can evaluate the the blinded input by the following steps:
 * 1. Receives the blinded input (masked group element) from the client.
 * 2a If the client is recognized (e.g. by a client ID), use the client's secret salt value.
 * 2b Else, generate a random (high-entropy) salt value. Optionally store it for later use with that client.
 * 3. Prepare to use the salt value as the key parameter for a keyed One-Way Function (OWF).
 * 4. Evaluates the keyed OWF on the input (masked group element) to derive the high-entropy output.
 * 5. He sends the output (masked salted group element) to the client.
 * 
 * Note: 
 * The OPRF server does neither learn the input nor the output.
 * The OPRF client does not learn the salt value.
 * An adaptive adversary can neither learn input, output nor salt value.
 * There are only two ways to learn the output from a given input:
 * a) either querying the OPRF server with the same input, or
 * b) compromising the OPRF server and learning the salt value.
 * There are only two ways to learn the input from a given output:
 * a) an online dictionary attack on the input, or
 * b) compromising the OPRF server, and performing an offline dictionary attack on the output using the salt value.
 * The only way to learn the salt value is to compromise the OPRF server.
 * There are only two types of information that can be learned from a compromised OPRF server:
 * a) the salt values of the OPRF clients, and
 * b) their client IDs.
 * A malicious OPRF server is equivalent to an attacker that has compromised the OPRF server;
 * plus a malicious OPRF server can learn when a client is using the OPRF (by the client ID),
 * and can learn if a client is (re)using the OPRF server multiple times with the same or different IDs.
 * 
 * OPRF AND VERIFIABLE OPRF (VOPRF) INSTANCIATIONS:
 * for specifications see:
 * - https://datatracker.ietf.org/doc/draft-irtf-cfrg-voprf/ 
 * and for implementations:
 * - https://github.com/multiparty/oprf/
 * - https://github.com/bytemare/voprf/
 * 
 * 
 * OUR OPRF IMPLEMENTATION:
 * Our implementation of the OPRF server and client is based on multiparty/oprf project.
 * 
 * QUOTES ON EC-OPRF AND RISTRETTO:
 * "It uses Ristretto255, and does not suffer from small cofactor attacks.",
 * "Implementation inspired by Burns et. al. 
 *  https://pdfs.semanticscholar.org/5d33/ea1d3fda454875a6a6ee7c535c80c74af512.pdf" 
 * - github.com/multiparty/oprf 
 * "Ristretto is a technique for constructing prime order elliptic curve groups with non-malleable encodings. 
 *  It extends Mike Hamburg's Decaf approach to cofactor elimination to support cofactor-\(8\) curves such as Curve25519.
 *  In particular, this allows an existing Curve25519 library to implement a prime-order group with only a thin abstraction layer, 
 *  and makes it possible for systems using Ed25519 signatures to be safely extended with zero-knowledge protocols, 
 *  with no additional cryptographic assumptions and minimal code changes.
 *  Ristretto can be used in conjunction with Edwards curves with cofactor \(4\) or \(8\), 
 *  and provides the following specific parameter choices:
 *  - ristretto255, built on top of Curve25519." - https://ristretto.group/
 * "Ristretto is a new unified point compression format for curves over large-characteristic fields, 
 *  which divides the curve’s cofactor by 4 or 8 at very little cost of performance, 
 *  efficiently implementing a prime-order group." - https://libsodium.gitbook.io/doc/advanced/point-arithmetic/ristretto
 * 
 * USING OPRF SERVICES FOR OBLIVIOUS PASSWORD-HARDENING AND PASSWORD-BASED SEED DERIVATION:
 * From both the client-server architecture and the security guarantees outlined above, 
 * we can derive the following use-case: 
 * The OPRF service allow the client i.e. user the secure remote derivation of a high-entropy salted secret, 
 * from a low-entropy secret like one of her passwords.
 * 
 * PASSSEEDS: 
 * A hgh-entropy seed derived from an OPRF-evaluated password we call a 'passseed'.
 * This passseed can then be used as an input to the key-pair generator (KPG),
 * which generates a key-pair (ssk, svk), that in turn is though based on the low-entropy password,
 * however, is not directly derived from it (as a password-based key derivation function (PBKDF) would do),
 * and thus not vulnerable to offline dictionary attacks.
 * This approach allows the user to use the same password for multiple servers,
 * without the servers being able to learn anything about the password.
 * At the same time, the user can issue each server its own secret verifier key (svk),
 * which can not only be used to authenticate the user to the server, but to do so in a non-repudiable way.
 * Signatures created by the ssk allow for auditing the signed challenge messages, by verifying them with the corresponding svk.
 * A user who has committed to her svk with a registration authority (RA), can therefore not deny having signed a challenge message.
 * For the users, this means that they can use the same password for multiple servers,
 * without the servers being able to learn anything about the password,
 * and without the user being able to deny having signed a challenge message.
 * 
 * NON-REPUDIATION, REGISTRATION AUTHORITIES (RA) AND AUDITABILITY:
 * In order to prevent the user from denying having signed a challenge message,
 * the user needs to commit to her svk with a registration authority (RA).
 * This can be done by the RA signing the svk with its signing key.
 * This signature can then be verified by the server with the RAs public key.
 * The RA can be a trusted third party, or a smart contract on a blockchain.
 * The RA can also be the server itself, if it is trusted to not misuse the RA role,
 * as would be the case if the server is a government authority, or a bank.
 * This would void the auditability of the signatures, however, it would still allow for non-repudiation,
 * as long as the user is not repudiating her sole ownership of the corresponding ssk.
 * 
 * REASONABLENESS OF, AND JUSTIFICATION FOR REQUIRING AUDITABLE USER COMMITMENT TO THE SVK:
 * From the server's perspective requiring the user to commit to her svk with a registration authority (RA) may seem necessary,
 * in order to prevent the user from denying having signed a challenge message.
 * While Auditable aPAKE (A2PAKE) and Mutually Authenticate A2PAKE (mA3PAKE) protocols offer a viable solution to this problem,
 * the user may be sceptical about the security of these schemes.
 * Thus, the reasonablness of requiring auditable user commitment to the svk must be justified with a threat model,
 * that outlines both the security assumptions and guarantees of the protocol, as well as the risks of not requiring it.
 * 
 * THREAT MODEL:
 * The threat model for the Mutual authentication protocol mA3PAKE is as follows:
 * // TODO
 * 
 * RISKS OF NOT REQUIRING AUDITABLE USER COMMITMENT TO THE SVK:
 * Auditable user commitment to the svk offers advantages for both the user and the server.
 * In order to justyfy the requirement of auditable user commitment to the svk, 
 * not only the security assumptions and guarantees of the protocol,
 * but also the risks of not requiring it as well as the protection value, practical advantages like ease of use, 
 * and the new possibilities it offers to the users with respect to online transactions, need to be outlined.
 * 
 * ADVANTAGES OF AUDITABLE USER COMMITMENT TO THE SVK:
 * There are three main advantages for the user:
 * 1. The user can use the same password for multiple servers,
 *   without the servers being able to learn anything about the password.
 * 2. The user can issue each server its own secret verifier key (svk),
 *  which can not only be used to authenticate the user to the server, but to do so in a non-repudiable way.
 * 3. Signatures created by the ssk allow for auditing the signed challenge messages, by verifying them with the corresponding svk.
 * 
 * USE-CASE SCENARIO FOR THE MUTUAL AUTHENTICATION PROTOCOL mA3PAKE - GENERAL CONCEPT:
 * Alice uses a browser that supports the Mutual authentication protocol mA3PAKE,
 * and wants to register with Bob's server, which requires mA3PAKE for non-repudiation.
 * After successful registration, she wants to login, perform a transaction, and logout.
 * The server supports svkRetrieval, so Alice can register her svkRetrieval permit,
 * and later request her svk after successful authentication, in order to recover her key base.
 * Without svkRetrieval, she would have to rely on her key vault app to recover her key base.
 * 
 * DESCRIPTION OF THE DEMO SCRIPT FOR THE mA3PAKE USE-CASE SCENARIO:
 * 0. CREATE A NEW KPG BASE: 
 * 0.1 Alice's lets her browser generate a key-pair generator base.
 * 0.2 Alice's browser displays the modulus fingerprint (randomart-visualized hash value) of her newly created key-pair generator base.
 * 0.3 Alice intensively memorizes the fingerprint randomart of her key-pair generator base.
 * 0.4 Optional: Additionally, she stores the key-pair generator base in a key vault app on a trusted device.
 * 1. 
 * 1.1 Alice's browser sends a HTTP Request 1 to Bob's server containing:
 * - the /register endpoint,
 * 1.2 Alice's browser receives the registration invitation and extracts the ks1 parameter containing:
 * - message type, timestamp and authentication server,
 * - the server's keyexchange public key, simultaneously acting as challenge nonce.
 * 1.3 Alice's browser creates a registration request message kc1 containing:
 * - message type, timestamp and authentication server,
 * - her username and fingerprint, as well as
 * - her OPRF server and client ID, and her svkRetrieval permit.
 * - the server's and her own keyexchange public key, simultaneously acting as challenge nonces.
 * - her secret verifier key svk, encrypted with the shared secret.
 * Alice's browser signs kc1 with her signing key ssk,and sends it to Bob's server as HTTP Request 2.
 * 1.4 Alice's browser receives the registration confirmation and extracts the ks2 parameter containing:
 * - the payload of her kc1 message, signed by Bob's server with his signing key svk and encrypted with the shared secret.
 * Alice's browser decrypts the payload with the shared secret, and verifies the signature with her singing key ssk.
*/


/**
 * 2. Client Demo Script - User Login:
 * 2.1 Alice's browser sends a HTTP Request 1 to Bob's server containing:
 *   - the /login endpoint,

 * 2.2 Alice's browser receives the login invitation and extracts the ks1 session record.
 * 2.3 Alice's browser creates a login request message containing:
 *    - message type, timestamp and authentication server,
 *   - her username and fingerprint, as well as
 *  - the nonce from the ks1 session record.
 *  Alice's browser signs the login request message with her signing key ssk.
*/
 
/**
 * 3. Client Demo Script - User Logout:
 * 3.1 Alice's browser sends a HTTP Request 1 to Bob's server containing:
 *  - the /logout endpoint,
 * 3.2 Alice's browser receives the logout invitation and extracts the ks1 session record.
 * 3.3 Alice's browser creates a logout request message containing:
 *   - message type, timestamp and authentication server,
 *  - her username and fingerprint, as well as
 * - the nonce from the ks1 session record.
 * Alice's browser signs the logout request message with her signing key ssk.
*/

/**
 * 4. Client Demo Script - User Transaction:
 * 4.1 Alice's browser sends a HTTP Request 1 to Bob's server containing:
 * - the /transaction endpoint,
 * - an unauthorized action object in the request body, 
 *   e.g. {user:'alice1',type:'purchase',itemNr:12345,price:99.99,currency:'EUR'}
 *   objects like this are created by Alice's browser and sent to Bob's server with regular HTTP requests.
 *  // action = {user:'alice1',type:'purchase',itemNr:12345,price:99.99,currency:'EUR'};
 *  // req.body.action = action;
 *  // req.send();
 *  // On the server-side `log.info("req.body:", req.body)` would look like this:
 *  // { action: { user: 'alice1', type: 'purchase', itemNr: 12345, price: 99.99, currency: 'EUR' } }
*/

// #region Old Code
function parseAuthHeader(authHeader) {
    const authHeaderParts = authHeader.split(' ');
    const authHeaderParams = authHeaderParts[1].split(',');
    const authHeaderParamsObj = {};
    authHeaderParams.forEach(param => {
        const [key, value] = param.split('=');
        authHeaderParamsObj[key.trim()] = value.replace(/"/g, '');
    });
    return authHeaderParamsObj;
}
function modulusFingerprint(verifierKey) {
    const modulus = verifierKey.n;
    const modulusBuf = Buffer.from(modulus, 'base64');
    const modulusHash = crypto.createHash('sha256');
    modulusHash.update(modulusBuf);
    const modulusFingerprintBuf = modulusHash.digest();
    const modulusFingerprint = modulusFingerprintBuf.toString('hex');
    return modulusFingerprint;
}


const server = http.createServer(async (req, res) => { 
    // Set headers to comply with RFC 7235 and RFC 8120
   res.setHeader('Content-Type', 'application/json');
   res.setHeader('Cache-Control', 'no-store');
   res.setHeader('Pragma', 'no-cache');
   async function generateKs1JSON(messageType){
       let ks1JSON;
       let keyexchangeServerKeypair;
       const timestampObj = new Date();
       const timestamp = timestampObj.toISOString();
       switch (messageType) {
           case msgTypeRegInvitation: {
               log("He generates an ECDH-ES key pair...");
               keyexchangeServerKeypair = await JWK.createKey(serverDHkty, serverDHcurveName, {use: 'enc', alg: 'ECDH-ES'});
               log("... exports the public key ...");
               const keyexchangeServerPubkey = keyexchangeServerKeypair.toJSON(false);
               log("Bob's DH keyexchange public key:", keyexchangeServerPubkey);
               log("Regarding OPRF, Bob can suggest his default OPRF server to Alice ...");
               log("Bob's default OPRF server:", oprfServerDefault,
                       "\n... but she can customize it to a server of her choice.",
                       "\nNow, he replies with an 401-REG-INIT authorization header containing the ks1 parameter with:",
                       `\n - the message type "${messageType}",`,
                       "\n - his server name",
                       "\n - his default OPRF server,",
                       "\n - whether he supports svkRetrieval (sending his (encrypted) svk to Alice after successful authentication),",
                       "\n - his DH keyexchange public key, and ",
                       "\n - a timestamp.");
               ks1JSON = { messageType, timestamp, registrationServer, 
                       oprfServer: oprfServerDefault, svkRetrieval: svkRetrievalSupport, keyexchangeServerPubkey};
               } break;
           case msgTypeRegChallenge: {
               // TODO
               } break;
           default: {
               // TODO
           } break;
       }
       return {ks1JSON, timestampObj, keyexchangeServerKeypair};
   }
   // Checks Authorization header for Mutual authentication
   function checkAuthHeader(authHeader, realmExpected){
       let errorMessage;
       if (! (authHeader.version === protocolVersion 
           && authHeader.algorithm === protocolAlgorithm 
           && authHeader.validation === protocolValidation)) {
           log(false, "version:", authHeader.version, 
                            "algorithm:", authHeader.algorithm, 
                           "validation:", authHeader.validation);
           res.statusCode = 401;
           errorMessage = errMsgInvalidProtParams;
       } else 
       if (authHeader.realm !== realmExpected) {
           log(false, "realm:", authHeader.realm);
           res.statusCode = 401;
           errorMessage = errMsgInvalidRealm;
       } 
       if (errorMessage) {
           res.setHeader('WWW-Authenticate', 
               `Mutual realm="${realmExpected}", ${protocolParams}, error="${errorMessage}"`);
           res.end();
       } else {
           log(true);
       }
   }
   // Checks if session is valid and not expired
   function checkSession(sid, realm){
       const authHeaderResponse =  protocolParams;
       let sessionExpired;
       let session;
       let errorMessage;
       if (sid) {
           authHeaderResponse += `, sid="${sid}"`;
           switch (realm) {
               case "User Registration":
                   session = registrationSessions[sid];
                   break;
               case "User Login":
                   session = loginSessions[sid];
                   break;
               case "User Logout":
                   session = logoutSessions[sid];
                   break;
               default:
                   session = null;
                   break;
           }
           if (session) {
               const sessionTimestamp = session.timestamp;
               const now = new Date();
               const sessionExpired = (now - sessionTimestamp) > 3600;
               if (sessionExpired) {
                   errorMessage = "Session expired";
               }    
           } else {
               errorMessage = "Session ID not found";
           } 
       } else {
           errorMessage = "No session ID provided";
       }
       if (session && !sessionExpired) {
           log(true);
       } else {
           log(false, "session:", session, "sessionExpired:", sessionExpired);
           res.statusCode = 401;
           authHeaderResponse += `, error="${errorMessage}"`;
           res.setHeader('WWW-Authenticate', "Mutual " + authHeaderResponse);
           res.end();
       }
   }
   // Checks if registration request is valid
   function checkRegRequest(sid, kc1Payload) {
       let error;
       const sessionKs1 = registrationSessions[sid];
       log("Bob's server checks:\n",
                   `- if the message type is "${msgTypeRegRequest}",`);
       kc1MessageType = kc1Payload.messageType;
       if (kc1MessageType === msgTypeRegRequest) {
           log(true);
       } else {
           log(false);
           error = errMsgInvalidMsgType;
       }
       log(" - if the registration servername, timestamp, and server public key are valid,");
       // check if all parameters are valid
       if (kc1Payload.registrationServer === sessionKs1.registrationServer && 
           kc1Payload.timestamp            === sessionKs1.timestampObj.toISOString() &&
           kc1Payload.keyexchangePubkeyServer === sessionKs1.keyexchangePubkeyServer) {
           log(true);
       } else {
           log(false);
           error = errMsgInvalidRegKc1;
       }        
       log(" - if the requested username is available",
           "   (ideally handled by the application prior to the registration).");
       // check if username is not already taken
       if (!userDB[kc1User]) {
           log(true);
       } else {
           log(false);
           error = errMsgUsernameTaken;
       }
       if (error) {
           res.statusCode = 401;
           res.setHeader('WWW-Authenticate', 
               `Mutual realm="${realmRegister}", ${protocolParams}, error="${error}"`);
           res.end();
       }
   }
   // Process registration request message (3) in header parameter kc1 from client (flow 2)
   async function processRegRequest(sid, kc1JSON) {
       const session = registrationSessions[sid];
       log("From Alice' registration request message kc1 payload, he now extracts her ECDH public key...");
       const kc1PayloadString = kc1JSON.payload;
       const kc1Payload = JSON.parse(kc1PayloadString);
       const keyexchangePubkeyClient = kc1Payload.keyexchangePubkeyClient;
       const kc1KeyexchangePubkeyClient = await JWK.asKey(keyexchangePubkeyClient);
       log("Alice's ECDH public key (JWK):", kc1KeyexchangePubkeyClient);
       log("... retrieves his ECDH keypair from the cached registration session initiated with ks1 ...");
       const keyexchangeServer = session.keyexchangeServer;
       log("Bob's ECDH keypair (JWK):", keyexchangeServer);
       log("... and uses it to compute their shared secret ...");
       // keyexchangeSharedSecret is the shared secret of data type Buffer
       const keyexchangeSharedSecret = keyexchangeServer.derive(kc1KeyexchangePubkeyClient);
       log("Their shared secret (buffer to hex):", keyexchangeSharedSecret.toString('hex'));
       log("Bob's server now extracts Alice' encrypted verifier key svk (JWE) from the kc1 payload ...");
       const verifierKeyEncryptedJweString = kc1Payload.verifierKeyEncrypted;
       const verifierKeyEncryptedJWE= JSON.parse(verifierKeyEncryptedJweString);
       log("Alice' encrypted verifier key svk (JWE):", verifierKeyEncryptedJWE);
       log("... and decrypts it with the shared secret key ...");
       const verifierKeyBuffer = JWE.decrypt(verifierKeyEncryptedJWE, keyexchangeSharedServer);
       const verifierKeyString = verifierKeyBuffer.toString();
       const verifierKeyJSON = JSON.parse(verifierKeyString);
       const verifierKey = await jose.JWK.asKey(verifierKeyJSON);
       log("Alice' decrypted verifier key svk (JWE):", verifierKey);
       log("Bob's server now calculates the modulus fingerprint (hash) of the verifier key ...");
       const modulusFingerprint = modulusFingerprint(verifierKey);
       log("Modulus fingerprint (hash) of Alice' verifier key svk:", modulusFingerprint);
       log("Bob's server checks if the fingerprint matches the one in the registration message:");
       const kc1Fingerprint = kc1Payload.fingerprint;
       if (kc1Fingerprint === modulusFingerprint) {
           log(true);
       } else {
           log(false);
           res.statusCode = 401;
           const errorMessage = errMsgFingerprintMismatch;
           res.setHeader('WWW-Authenticate', `Mutual realm="${realm}", sid="${sid}", error="${errorMessage}"`);
           res.end();
       }
       log("With his verifier key now at hand,",
           "\nBob's server checks if Alice' signature on the payload (in JWS) is valid ...");
       let verifiedPayload;
       let verifiedClient;
       try {
           verifiedPayload = JWS.verify(kc1JSON, verifierKey, { algorithms: [validation] });
           verifiedClient = true;
       } catch (err) {
           verifiedClient = false;
           console.error('Verification error:', err);
           const errorMessage = errMsgInvalidSignature;
           res.statusCode = 401;
           res.setHeader('WWW-Authenticate', `Mutual ${protocolParams}, sid="${sid}", error="${errorMessage}"`);
           res.end();
       }
       log("Alice' signature is valid (verified with decrypted verifier key svk):", verifiedClient);
       log("Now, Bob's server checks if svkRetrieval is supported and user has requested it for future logins ...");
       const svkRetrieval = kc1Payload.svkRetrieval && svkRetrievalSupport;
       log("svkRetrieval:", svkRetrieval);
       log("... and extracts Alice' OPFR server (Bob's default or selected by Alice) and client ID ...");
       const oprfServer = kc1Payload.oprfServer;
       const oprfID = kc1Payload.oprfID;
       log(`Alice' OPRF server: "${oprfServer}",\n... and client ID: "${oprfID}"`);
       log("Finally, Bob's server creates a new database record for Alice, containing:\n",
           "- her username and modulus fingerprint,\n",
           "- her OPRF server and client ID, as well as\n",
           "- her (decrypted) verifier key svk, and the svkRetrieval flag.");
       userDB[kc1User] = {fingerprint: modulusFingerprint, oprfServer, oprfID, svk: verifierKey, svkRetrieval};
       log("and updates the registration process with the provided information...");
       registrationSessions[sid] = {...registrationSessions[sid], kc1Payload};
       log("Then, he signs the registration message (kc1 payload) as a JWS himself,",
           "\nusing svk in the role of a signing key ...");
       const verifierKeyPriv = jose.JWK.asKey({
           kty: 'RSA',
           alg: validation,
           d: verifierKey.e, // use the 'public' exponent as 'private' exponent
           n: verifierKey.n,
       });
       const signatureServer = JWS.createSign({ format: 'compact' }, verifierKeyPriv)
                                  .update(kc1PayloadString)
                                  .final();
       log("Bob's signed JWS:", signatureServer);
       log("... and encrypts it as a JWE with the shared secret key ...");
       const signatureServerEncrypted = JWE.encrypt(signatureServer, keyexchangeSharedSecret, 
                                                       {alg: jweAlg, enc: jweEnc});
       return signatureServerEncrypted;
   }
   // HTTP Authentication header of client request
   const authHeader = req.headers.authorization;
   /**
    * The first registration flow initiates the process with a 401-REG-INIT message from the server.
    * It receives a regular HTTP GET request from the client without any authentication attempt (1),
    * and responds with a 401-R-INIT WWW-Authenticate header (2) including the following parameters:
    * The realm, protocol parameters, a new session ID and the ks1 message containing the following:
    * messageType "User Registration Invitation", a timestamp, the server name, default OPRF server,
    * whether or not svkRetrieval is supported, as well as the server's ECDH keyexchange public key.
   */
   async function registerFlow1() {
       // message type of 401-R-INIT response
       const messageType = msgTypeRegInvitation;
       log("Bob's server receives a regular HTTP GET Request (1)",
           "\nwithout any authentication attempt from Alice's browser.",
           "\nBecause it requests the /register endpoint, he initiates a registration process.",
           "\nHe generates a session ID and constructs a registration invitation message (401-R-INIT)",
           "\nwith a ks1 parameter contraining a ECDH public key, timestamp and other parameters.");
       const sid = crypto.randomBytes(16).toString('hex');
       const {ks1JSON, timestampObj, keyexchangeServer} = await generateKs1JSON(messageType);
       log("ks1JSON:", ks1JSON);
       const ks1String = JSON.stringify(ks1JSON);
       const ks1 = Buffer.from(ks1String).toString('base64');
       log("He stores the session ID and ks1 in his registration session cache ...")
       registrationSessions[sid] = {ks1JSON, timestampObj, keyexchangeServer};
       log("... and sends the first HTTP Response with the registration invitation message ks1 (2) to Alice's browser.");
       res.setHeader('WWW-Authenticate', `Mutual realm="${realmRegister}", ${protocolParams}, sid="${sid}", ks1="${ks1}"`);
       res.statusCode = 401;
       res.end();
   }
   /**
    * This flow processes the second HTTP request with the registration request (3) from the client.
    * It receives a HTTP request with 401-R-REQ Authorization header including following parameters:
    * The realm and protocol parameters, the session ID, and a kc1 message containing the following:
    * messageType "User Registration Request", timestamp & server name, the OPRF server & client ID,
    * An encrypted svk, fingerprint of the svk modulus and the client's ECDH keyexchange public key.
    * If everything is valid, the user will be registered and the registration process is completed.
    * The 200-R-VFY HTTP response (4) with an WWW-Authenticate header includes following parameters:
    * The realm and protocol parameters, the session ID, and a vks message containing the following:
    * The server's signature on kc1, created with the svk, and encrypted with the shared secret key.
   */
   async function registerFlow2() {
       log("Bob's server receives the user registration request (3) from Alice's browser.",
               "\nThe 401-R-REQ Authorization header including a kc1 parameter.");
       const authHeaderParams = this.parseAuthHeader(authHeader);
       log("Bob's server checks the Authorization header for the following parameters:\n",
                   "- if the realm is 'User Registration',\n",
                   "- if the protocol parameters (version, algorithm and validation) are valid,");
       checkAuthHeader(authHeaderParams, realmRegister);
       log(" - if the sid is valid and the registration process has not expired,");
       const { sid } = authHeaderParams; 
       checkSession(sid, realmRegister);
       log("Now, he decodes the kc1 parameter and extracts its JWS payload:"); 
       const { kc1 } = authHeaderParams; 
       const kc1Buffer = Buffer.from(kc1, 'base64');
       const kc1String = kc1Buffer.toString();
       // kc1 is a JWS (JSON Web Signature) with the payload containing the registration request
       const kc1JWS = JSON.parse(kc1String);
       // unverified kc1 payload
       const kc1Payload = kc1JSON.payload;
       log(kc1Payload);
       log("Then, checks if the username requested therein equals the header parameter 'user'.");
       const kc1User = kc1Payload.user;
       if (kc1User === authHeaderParams.user) {
           log(true);
       } else {
           log(false);
           res.statusCode = 401;
           const errorMessage = errMsgUserMismatch;
           res.setHeader('WWW-Authenticate', `Mutual realm="${realmRegister}", ${protocolParams},`
                                           + ` sid="${sid}", error="${errorMessage}"`);
           res.end();
       }
       log("If so, he checks the registration request, validating the servername, timestamp,",
           "\nand server public key, as well as the availability of the requested username:");
       checkRegRequest(sid, kc1Payload);
       log("If everything matches, he starts processing Alice' registration request:");
       const signatureServerEncrypted = await processRegRequest(sid, kc1JSON);
       log("Bob's AES-encrypted JWS (JWE):", signatureServerEncrypted);
       log("Finally, he sends the confirmation message with the JWE to Alice's browser.");
       const vks = JSON.stringify(signatureServerEncrypted);
       res.setHeader('Authentication-Info', `Mutual realm="${realmRegister}", versino="1", `
           +`algorithm="${algorithm}", validation="${validation}", sid="${sid}", vks="${vks}"`);
       // HTTP response body with registration confirmation
       const kc1Fingerprint = kc1Payload.fingerprint;
       const message = "Registration confirmation\nYou have successfully registered\n"
                     + `with the username ${kc1User}\nand the fingerprint ${kc1Fingerprint}\n`
                     + `at ${registrationServer} !\nYou can now login at: /login\n`;
       // 200-VFY-S response
       res.statusCode = 200;
       res.end(message);
   }
   // Handle the root path (Start page)
   if(req.url === '/'){
       // Set the status code to 200 (OK) and send a welcome message
       res.statusCode = 200;
       res.end(welcomeHTML);
   }
   // Handle the register path
   if (req.url === '/register') {
       /**
        * Check if any "Authorization" header is present, and if not, initiate the registration process.
       */
       if (!authHeader) {
           await registerFlow1();
       } else 
       /**
        * Check if the Authorization header for 'Mutual' HTTP Authentication includes the 'kc1' message.
       */
       if (authHeader.startsWith('Mutual ') && authHeader.includes('kc1=')) {
           await registerFlow2();
       } else {
       /**
        * Any Authorization header without the 'kc1* parameter is invalid. The server sends a 401-R-INIT
        * WWW-Authenticate header with error message 'invalid authorization header' and protocol params.
        * 
       */
           res.statusCode = 401;
           const errorMessage = "invalid authorization header";
           res.setHeader('WWW-Authenticate', `Mutual realm="${realmRegister}", ${protocolParams}, error="${errorMessage}"`);
           res.end();
       } 
   }
   
   /** ************* Login Simulation: *****************************************************
    * // AUTHENTICATION PHASE
   async function authenticationPhase(client, server) {
   const [registrationServer, username, password, svkRetrieval] 
    = [client.registrationServer, client.username, client.password, client.svkRetrieval];
   const [fingerprint, svkStr, oprfServer, oprfID]
    = [server.fingerprint, server.svkString, server.oprfServer, server.oprfID];
   svkJSON = JSON.parse(svkStr);
   const svk = pki.setRsaPublicKey(new BigInteger(svkJSON.n), new BigInteger(svkJSON.e));
   log("\n### AUTHENTICATION PHASE ###");
   const authenticationServer = "bob.example.com";
   log("Alice wants to log into her account with " + authenticationServer + ", again.",
           "\nShe clicks on the login link: https://", registrationServer, "/login",
           "\nand her browser sends a regular GET request for that URL to Bob's server (HTTP Request 1).");
   log(horizonalLine);
   ////////////////////////////////////////////////////////
   log("Bob's server receives HTTP Request 1. ",
           "\nBecause it's for the /login endpoint, he initiates a login/authentication process.");
   messageType = "user login invitation";
   const nonceServerBytes = forge.random.getBytesSync(32);
   const nonceServer = forge.util.bytesToHex(nonceServerBytes);
   timestamp = Date.now()
   loginMessage = {messageType, timestamp, authenticationServer, 
                   nonceServer
               };
   log("Bob's server generates a nonce and a timestamp,",
           "\nand sends a HTTP authorization header with an login invitation to Alice's browser (HTTP Response 1):\n", 
           loginMessage);
   log(horizonalLine);
   ////////////////////////////////////////////////////////
   log("Alice's browser receives the HTTP authorization header with the login message,",
           "\nand asks her to enter her if she wants to login with", authenticationServer,
           "\nIf she confirms, he prompt her for her username and password.",
           "\nShe enters the same username and password as before:\n",
           "username:", username, "\npassword:", password);
   messageType = "user login request";
   const nonceClientBytes = forge.random.getBytesSync(32);
   const nonceClient = forge.util.bytesToHex(nonceClientBytes);
   loginMessage = {messageType, timestamp, authenticationServer, username, 
                   nonceServer, nonceClient
               };
   log("Alice's browser updates the loginMessage with the username and a nonce,",
           "\nand sends it to Bob's server (HTTP Request 2):\n", loginMessage);
   log(horizonalLine);
   ////////////////////////////////////////////////////////
   log("Bob's server receives the login request and checks if the username exists in his database.",
           "\nIf so, Bob's server creates an login message containing:",
           "\nAlice' username, her OPRF server and client ID, her modulus and her fingerprint.");
   messageType = "user login challenge";
   const modulus = svk.n.toString();
   loginMessage = {messageType, timestamp, authenticationServer, username, fingerprint, modulus, 
                   svkRetrieval, oprfServer, oprfID,
                   nonceServer, nonceClient 
               };
   log("Bob's server sends the login challenge message to Alice's browser (HTTP Response 2):\n", 
               loginMessage);
   log(horizonalLine);
   ////////////////////////////////////////////////////////
   log("\nAlice's browser receives the login challenge, validates it, and calculates the modulus fingerprint,",
           "\ncompares it with the one in the message, displays it's randomart image and asks Alice to verify it.",
           "\nIf Alice confirms, her browser now starts the OPRF evaluation of her password ...");
   let passseed; 
   const oprfURL = "https://" + oprfServer;
   try {
       passseed = await oprfClient(oprfURL, oprfID, password, "hex");
       log("OPRF has been evaluated. Passseed:", Buffer.from(passseed).toString('hex'));
   } catch (error) {
       console.error("An error occurred:", error);
   }
   log("Alice's browser derives the secret exponent s from the passseed ...");
   const s = new BigInteger(deriveRSAExponent(passseed, nBits - 1));
   log("Exponent s has been derived:", s.toString(radix));
   log("Construct ssk from s and n ...");
   const n = new BigInteger(modulus);
   const ssk = pki.setRsaPublicKey(n, s);
   log("Alice's browser signs the authentication message with ssk ...");
   const loginMsgString = JSON.stringify(loginMessage);
   const md2 = forge.md.sha256.create();
   const loginMsgHash = md2.update(loginMsgString);
   const signatureClientBytes = customSignPSS(loginMsgHash, ssk, rsaPssParams);
   const signatureClient = forge.util.bytesToHex(signatureClientBytes);
   log("Alice's signature:", signatureClient);
   log("Alice' browser creates a random AES key and OAEP-encrypts it with ssk ...");
   const aesKey = forge.random.getBytesSync(32);
   log("Alice's AES key:", aesKey.toString('hex'));
   const aesKeyEncryptedBytes = ssk.encrypt(aesKey, "RSA-OAEP", rsaOAEPParams);
   const encryptedKey = forge.util.bytesToHex(aesKeyEncryptedBytes);
   log("Alice's browser updates the login message with the signature and the encrypted AES key ...");
   messageType = "user login response";
   loginMessage = {messageType, timestamp, authenticationServer, username, fingerprint, modulus, 
                   svkRetrieval, oprfServer, oprfID,
                   nonceServer, nonceClient,
                   signatureClient, encryptedKey
               };
   log("Alice's browser sends the login response (and signature) to Bob's server (HTTP Request 3):\n",
               loginMessage);
   log(horizonalLine);
   ////////////////////////////////////////////////////////
   log("Bob's server receives the login response and verifies the signature with Alice' verifier key svk.",
           "\nIf the signature is valid, he sends a login confirmation message to Alice's browser.",
           "\nIf Alice has registered with svkRetrieval and requesets it now, he includes the encrypted svk.");
   const signatureClientBytesFromHex = forge.util.hexToBytes(loginMessage.signatureClient);
   const md3 = forge.md.sha256.create();
   const loginMsgHash2 = md3.update(loginMsgString);
   const verifiedClient2 = svk.verify(loginMsgHash.digest().bytes(), signatureClientBytes, pssObj);
   log("Bob's server was able to verify Alice' signature:", verifiedClient2);
   log("He decrypts the encrypted AES key with svk ...");

   const encryptedKeyFromHex = forge.util.hexToBytes(loginMessage.encryptedKey);
   const aesKey2DecryptedBytes = customDecryptOAEP(encryptedKeyFromHex, svk, rsaOAEPParams);
   const aesKey2Decrypted = forge.util.bytesToHex(aesKey2DecryptedBytes);
   log("Bob's server decrypted the AES key successfully:", aesKey2Decrypted);
   log("He encrypts svk with the AES key ...");
   const svkString = JSON.stringify({n: svk.n.toString(), e: svk.e.toString()});
   const svkBuffer = forge.util.createBuffer(svkString);
   const aesKey2DecryptedBinary = forge.util.hexToBytes(aesKey2Decrypted.toString('hex'));
   const svkCipher = forge.cipher.createCipher('AES-CBC', aesKey2DecryptedBinary);
   var verifierKeyEncryptedIvBytes = forge.random.getBytesSync(16);
   var verifierKeyEncryptedIV = forge.util.bytesToHex(verifierKeyEncryptedIvBytes);
   svkCipher.start({iv: verifierKeyEncryptedIvBytes});
   svkCipher.update(svkBuffer);
   svkCipher.finish();
   const verifierKeyEncryptedBuffer = svkCipher.output;
   var verifierKeyEncrypted = verifierKeyEncryptedBuffer.toHex();
   log("Bob's AES-encrypted verifier key:", verifierKeyEncrypted);
   log("Bob's server updates the login message with the encrypted verifier key and IV and signs it ...");
   messageType = "user login confirmation";
   loginMessage = {messageType, timestamp, authenticationServer, username, fingerprint, 
                   nonceServer, nonceClient,
                   verifierKeyEncrypted, verifierKeyEncryptedIV
               };
   const loginMsgString2 = JSON.stringify(loginMessage);
   const md4 = forge.md.sha256.create();
   const loginMsgHash3 = md4.update(loginMsgString2);
   const signatureServer2Bytes = customSignPSS(loginMsgHash3, svk, rsaPssParams);
   const signatureServer2 = forge.util.bytesToHex(signatureServer2Bytes);
   log("Bob's signature:", signatureServer2);
   log("Bob's server encrypts the signature with the AES key ...");
   const signatureServer2Buffer = forge.util.createBuffer(signatureServer2Bytes);
   const signatureCipher2 = forge.cipher.createCipher('AES-CBC', aesKey2DecryptedBinary);
   var signatureServerEncryptedIvBytes = forge.random.getBytesSync(16);
   var signatureServerEncryptedIV = forge.util.bytesToHex(signatureServerEncryptedIvBytes);
   signatureCipher2.start({iv: signatureServerEncryptedIvBytes});
   signatureCipher2.update(signatureServer2Buffer);
   signatureCipher2.finish();
   var signatureServerEncryptedBytes = signatureCipher2.output;
   var signatureServerEncrypted = forge.util.bytesToHex(signatureServerEncryptedBytes);
   log("Bob's AES-encrypted signature:", signatureServerEncrypted);
   log("Bob's server updates the login message with the encrypted signature and IV ...");
   loginMessage = {messageType, timestamp, authenticationServer, username, fingerprint, 
                   nonceServer, nonceClient,
                   verifierKeyEncrypted, verifierKeyEncryptedIV,
                   signatureServerEncrypted, signatureServerEncryptedIV
               };
   
   log("Bob's server updates the login confirmation with the encrypted svk and signature, and IVs ...");
   log("He sends the login confirmation message to Alice's browser (HTTP Response 3):\n",
               loginMessage);
   log(horizonalLine);
   ////////////////////////////////////////////////////////
   log("Alice's browser receives the login confirmation and decrypts the encrypted signature with her AES key ...");
   const signatureServerFromHex2 = forge.util.hexToBytes(loginMessage.signatureServerEncrypted);
   const signatureServerIVFromHex2 = forge.util.hexToBytes(loginMessage.signatureServerEncryptedIV);
   const signatureDecipher2 = forge.cipher.createDecipher('AES-CBC', aesKey2DecryptedBinary);
   signatureDecipher2.start({iv: signatureServerIVFromHex2});
   signatureDecipher2.update(forge.util.createBuffer(signatureServerFromHex2));
   signatureDecipher2.finish();
   const signatureServerDecrypted2Buffer = signatureDecipher2.output;
   const signatureServerDecrypted2Bytes = signatureServerDecrypted2Buffer.bytes();
   const signatureServerDecrypted2 = forge.util.bytesToHex(signatureServerDecrypted2Bytes);
   log("Alice decrypted Bob's signature:", signatureServerDecrypted2);
   log("... and now verifies it with her signing key ssk.");
   const md5 = forge.md.sha256.create();
   const loginMsgHash4 = md5.update(loginMsgString2);
   const verifiedServerSignature2 = ssk.verify(loginMsgHash4.digest().bytes(), signatureServerDecrypted2Bytes, pssObj);
   log("Alice's browser decrypts the encrypted verifier key with her AES key ...");
   const verifierKeyEncryptedFromHex = forge.util.hexToBytes(loginMessage.verifierKeyEncrypted);
   const verifierKeyEncryptedIVFromHex = forge.util.hexToBytes(loginMessage.verifierKeyEncryptedIV);
   const verifierKeyDecipher = forge.cipher.createDecipher('AES-CBC', aesKey2DecryptedBinary);
   verifierKeyDecipher.start({iv: verifierKeyEncryptedIVFromHex});
   verifierKeyDecipher.update(forge.util.createBuffer(verifierKeyEncryptedFromHex));
   verifierKeyDecipher.finish();
   const verifierKeyDecryptedBuffer = verifierKeyDecipher.output;
   const verifierKeyDecrypted = verifierKeyDecryptedBuffer.toString();
   log("Alice's browser decrypted the verifier key successfully:", verifierKeyDecrypted);
   log("Alice's browser checks the modulus of the decrypted verifier key against the one in the login message ...");
   const verifierKeyDecryptedJSON = JSON.parse(verifierKeyDecrypted);
   const verifierKeyDecryptedN = new BigInteger(verifierKeyDecryptedJSON.n);
   log("The modulus matches the one in the login message:", verifierKeyDecryptedN.equals(ssk.n));
   const verfierKeyDecryptedE = new BigInteger(verifierKeyDecryptedJSON.e);
   const v = verfierKeyDecryptedE;
   log("Alice's browser is starting PQrecovery from s and v ...");
   const [rp, rq] = recoverPQ(n, s, v);
   log("rp:", rp.toString());
   log("rq:", rq.toString());
   log("Alice' browser successfully recovered her key-pair generator base (p, q) from s and v.",
               "\nAs long as her browser is caching the key base, she can register with other servers,",
               "\nwith the same fingerprint.");
   return {signatureClient};
   }
    */
   // Handle the login path
   if (req.url === '/login') {
       // Check if authentification header is present.
       // This flow initiates the login process with a login invitation message (401-INIT).
       if (!authHeader) {
           /** 
            * As is typical in general HTTP protocol designs, a client will at
            * first request a resource without any authentication attempt (1).
            * If the requested resource is protected by the Mutual
            * authentication protocol, the server will respond with a message
            * requesting authentication (401-INIT) 
           */
           log("Bob's server receives HTTP Request 1. ",
           "\nBecause it's for the /login endpoint, he initiates a login/authentication process.");
           const realm = "User Login";
           const sid = crypto.randomBytes(16).toString('hex');
           const messageType = "User Login Invitation";
           const timestampObj = new Date();
           const timestamp = timestampObj.toISOString();
           const nonceServerBytes = forge.random.getBytesSync(32);
           const nonceServer = forge.util.bytesToHex(nonceServerBytes);
           ks1JSON = {messageType, authenticationServer, timestamp, nonceServer};
           log("Bob's server generates a nonce and a timestamp,",
           "\nand sends a HTTP authorization header with an login invitation to Alice's browser (HTTP Response 1):\n", 
           loginMessage);
           const ks1String = JSON.stringify(ks1JSON);
           const ks1 = Buffer.from(ks1String).toString('base64');
           // 401-INIT message: login invitation message to start the login process
           loginSessions[sid] = {ks1JSON, timestampObj};
           res.setHeader('WWW-Authenticate', `Mutual realm="${realm}", versino="1", algorithm="${algorithm}", `
                                           + `validation="${validation}", sid="${sid}", ks1="${ks1}", time="3600"`);
           res.statusCode = 401;
           res.end();
       } else  
       // Check if authentication header is present, starts with 'Mutual ' and contains a kc1 parameter.
       // This flow processes the login request message (401-REQ) and sends a key exchange message (401-KE).
       if (authHeader.startsWith('Mutual ') && authHeader.includes('kc1=')) {
           log("Bob's server receives the user login request message (HTTP Request 2)...");
           const authHeaderParams = this.parseAuthHeader(authHeader);
           const { version, algorithm, validation, realm, sid, user, kc1 } = authHeaderParams; 
           const authHeaderResponse = `version="${version}", algorithm="${algorithm}", validation="${validation}", `
                                    + `realm="${realm}", sid="${sid}", user="${user}"`;
           log("... and checks:\n",
           "- if version is 1,    algorithm is  'mA3PAKE',   validation is  'RSA-PSS' and realm is  'User Login");
           checkAuthHeader(authHeaderParams, realmLogin);
           log(" - if the sid is valid and the login process has not expired,");
           this.checkSession(req, res, sid, realmLogin);
           const session = loginSessions[sid];
           log("Then he decodes the kc1 parameter..."); 
           const kc1Buffer = Buffer.from(kc1, 'base64');
           const kc1String = kc1Buffer.toString();
           const kc1JSON = JSON.parse(kc1String);
           log("kc1 from Client:", kc1JSON);
           log("... and checks:");
           log(" - if the message type is 'user login request',");
           kc1MessageType = kc1JSON.messageType;
           if (kc1MessageType === "user login request") {
               log(true);
           } else {
               log(false, "kc1MessageType:", kc1MessageType);
               res.statusCode = 401;
               const errorMessage = "invalid message type";
               res.setHeader('WWW-Authenticate', "Mutual " + authHeaderResponse + `, error="${errorMessage}"`);
               res.end();
           }
           log(" - if the authentication servername and timestamp are matching,");
           // map kc1Payload to variables  
           const kc1AuthenticationServer = kc1JSON.authenticationServer;
           const kc1Timestamp = new Date(kc1JSON.timestamp);
           // map session to variables
           const sessionKs1 = session.ks1JSON;
           const ks1AuthenticationServer = sessionKs1.authenticationServer;
           const ks1Timestamp = sessionKs1.timestampObj;
           // check if all variables match
           if (kc1AuthenticationServer === ks1AuthenticationServer && kc1Timestamp === ks1Timestamp) {
               log(true);
           } else {
               log(false, 
                   "kc1AuthenticationServer:", kc1AuthenticationServer, "ks1AuthenticationServer:", ks1AuthenticationServer,
                   "kc1Timestamp:", kc1Timestamp, "ks1Timestamp:", ks1Timestamp);
               res.statusCode = 401;
               const errorMessage = "invalid kc1 session parameter (server or timestamp mismatch)";
               res.setHeader('WWW-Authenticate', "Mutual " + authHeaderResponse + `, error="${errorMessage}"`);
               res.end();
           }
           log(" - if the username exists in his database.");
           const userExists = userDB[user];
           if (userExists) {
               log(true);
           } else {
               log(false, "user:", user);
               res.statusCode = 401;
               const errorMessage = "user does not exist";
               res.setHeader('WWW-Authenticate', "Mutual " + authHeaderResponse + `, error="${errorMessage}"`);
               res.end();
           }
           log("If so, Bob's server creates a key exchange message containing:",
           "\n- message type, timestampt and authentication server,",
           "\n- Alice' username, fingerprint and modulus, as well as",
           "\n- her OPRF server and client ID, and her svkRetrieval permit.");
           const messageType = "User Login Keyexchange";
           const fingerprint = userDB[user].fingerprint;
           const modulus = svk.n.toString();
           const oprfServer = userDB[user].oprfServer;
           const oprfID = userDB[user].oprfID;
           const svkRetrieval = userDB[user].svkRetrieval;
           const ks2JSON = {messageType, timestamp, authenticationServer, username, fingerprint, modulus,
                        oprfServer, oprfID, svkRetrieval};
           log("Bob's server updates the session timestamp ..."); 
           timeStampObj = new Date();
           log("... and adds the key exchange message to the session record.");
           loginSessions[sid] = {...loginSessions[sid], kc1JSON, ks2JSON, timestampObj};
           log("Then, he sends it as HTTP Response 2 to Alice's browser:\n", ks2JSON);
           const ks2String = JSON.stringify(ks2JSON);
           const ks2 = Buffer.from(ks2String).toString('base64');
           res.statusCode = 401;
           res.setHeader('WWW-Authenticate', `Mutual ${authHeaderResponse}, ks2="${ks2}", time="3600"`);
           res.end();
       } else
       // check if authentication header is present, starts with 'Mutual ' and contains a kc2 parameter
       // This flow processes the key exchange message (401-KE) and sends a login challenge message (401-CH)
       if (authHeader.startsWith('Mutual ') && authHeader.includes('kc2=')) {
           log("Bob's server receives the user login response message (HTTP Request 3)...");
           const authHeaderParams = this.parseAuthHeader(authHeader);
           const { version, algorithm, validation, realm, sid, user, kc2 } = authHeaderParams; 
           const authHeaderResponse = `version="${version}", algorithm="${algorithm}", validation="${validation}", `
                                    + `realm="${realm}", sid="${sid}", user="${user}"`;
           log("... and checks:\n",
           "- if version is 1,    algorithm is  'mA3PAKE',   validation is  'RSA-PSS' and realm is  'User Login");
           checkAuthHeader(authHeaderParams, realmLogin);
           log(" - if the sid is valid and the login process has not expired,");
           this.checkSession(req, res, sid, realmLogin);
           const session = loginSessions[sid];
           log(" - if the user parameter matches the one in the session record.");
           const sessionUser = session.ks2JSON.username;
           if (user === sessionUser) {
               log(true);
           } else {
               log(false, "user:", user, "sessionUser:", sessionUser);
               res.statusCode = 401;
               const errorMessage = errMsgUserMismatch;
               res.setHeader('WWW-Authenticate', "Mutual " + authHeaderResponse + `, error="${errorMessage}"`);
               res.end();
           }
           log("Then he decodes the kc2 parameter as JSON, ...");
           const kc2Buffer = Buffer.from(kc2, 'base64');
           const kc2String = kc2Buffer.toString();
           const kc2JSON = JSON.parse(kc2String);
           log("... extracts the authenticated client public key (JWS), ...")
           const kc2ClietPubKeyJWS = JWS.parse();
           log("kc2JWS from Client:", kc2ClietPubKeyJWS);
           log("... and checks if the signature is valid with svk (as \"public key\").");
           const svkJSON = userDB[user].svk;
           const svkPub = jose.JWK.asKey({
               kty: 'RSA',
               alg: 'PS256',
               e: svkJSON.e.toString(16),
               n: svkJSON.n.toString(16)
           });
           let clientPublicKey;
           let kc2JWSVerified;
           try {
               clientPublicKey = JWS.verify(kc2ClietPubKeyJWS, svkPub, { algorithms: ['PS256'] });
               kc2JWSVerified = true;
           } catch (err) {
               console.error('Verification error:', err);
               kc2JWSVerified = false;
           }
           log("Bob's server was able to verify Alice' signature:", kc2JWSVerified);
           log("He extracts the authenticated DH client public key as JWK ...");
           const clientPublicKeyJWK = JWK.asKey(clientPublicKey);
           log("kc2 client public key JWK:", kc2ClientPubKeyJWK);
           log("Now, he checks the key type, creates his own key-pair (matching Alice' parameters) ...");
           const {kty, crv} = clientPublicKeyJWK;
           if (kty !== "EC") {
               log(false, "kty:", kty);
               res.statusCode = 401;
               const errorMessage = "invalid or unsupported JWK key type";
               res.setHeader('WWW-Authenticate', "Mutual " + authHeaderResponse + `, error="${errorMessage}"`);
               res.end();
           }
           const serverKeyPair = await JWK.createKeyPair(kty, crv);
           log("... and derives the shared secret from his private key and Alice' public key.");
           const sharedSecret = calculate('ECDH-ES', serverKeyPair, clientPublicKeyJWK);
           log("Shared secret:\n", sharedSecret);
           const serverPublicKeyJWK = sharedSecret.toJSON();
           log("Bob's server public key:", serverPublicKeyJWK);
           const serverPublicKey = JSON.stringify(serverPublicKeyJWK);
           log("Bob's server now creates a login challenge message containing:",
                   "\n- message type, timestampt and authentication server,",
                   "\n- Alice' username and fingerprint,",
                   "\n- svkRetrieval: the server's verifier key svk will be sent encrypted in confirmation message,",
                   "\n                if server supports it, user has registered permit, and requests it now,",
                   "\n- the keyexchange server and client public keys, acting as challenge nonces,");
           const messageType = "User Login Signature";
           const timestampObj = new Date();
           const timestamp = timestampObj.toISOString();
           const svkRetrievalPermit = userDB[user].svkRetrievalPermit;
           const svkRetrievalRequested = session.kc1.svkRetrieval;
           const svkRetrieval = svkRetrievalSupport && svkRetrievalPermit && svkRetrievalRequested;
           const challengeJSON = {messageType, timestamp, authenticationServer, 
                            user, fingerprint, svkRetrieval, clientPublicKey, serverPublicKey};
           log("Now, he signs the login challenge message with his verifier key svk ...");
           const challengeString = JSON.stringify(challengeJSON);
           const challengeJWS = JWS.sign(challengeString, svk, {alg: 'PS256'});
           log("Signed login challenge message:", challengeJWS);
           log("... and encrypts it with the shared secret with AES Key Wrap (A256KW) and AES GCM (A256GCM).");
           const challenge = JWE.encrypt(challengeJWS, sharedSecret, {alg: 'ECDH-ES+A256KW', enc: 'A256GCM'});
           log("Bob's server updates the session timestamp ...");
           timeStampObj = new Date();
           log("... and adds the login challenge message to the session record.");
           loginSessions[sid] = {... loginSessions[sid], kc2JSON, sharedSecret, challengeJSON, timestampObj};
           log("Then, he sends the encrypted challenge together with his server public key as HTTP Response 3 to Alice's browser:\n", ks3JSON);
           const ks3JSON = {serverPublicKey, challenge};
           const ks3String = JSON.stringify(ks3JSON);
           const ks3 = Buffer.from(ks3String).toString('base64');
           res.statusCode = 401;
           res.setHeader('WWW-Authenticate', `Mutual ${authHeaderResponse}, ks3="${ks3}", time="3600"`);
           res.end();
       } else 
       // check if authentication header is present, starts with 'Mutual ' and contains a kc3 parameter
       // This flow processes the login challenge response message (401-CH) and sends a login confirmation message (200-VFY)
       if (authHeader.startsWith('Mutual ') && authHeader.includes('kc3=')) {
           log("Bob's server receives the user login confirmation message (HTTP Request 4)...");
           const authHeaderParams = this.parseAuthHeader(authHeader);
           const { version, algorithm, validation, realm, sid, user, kc3 } = authHeaderParams; 
           const authHeaderResponse = `version="${version}", algorithm="${algorithm}", validation="${validation}", `
                                    + `realm="${realm}", sid="${sid}", user="${user}"`;
           log("... and checks:\n",
           "- if version is 1,    algorithm is  'mA3PAKE',   validation is  'RSA-PSS' and realm is  'User Login");
           checkAuthHeader(authHeaderParams, realmLogin);
           log(" - if the sid is valid and the login process has not expired,");
           this.checkSession(req, res, sid, realmLogin);
           const session = loginSessions[sid];
           log(" - if the user parameter matches the one in the session record.");
           const sessionUser = session.ks2JSON.username;
           if (user === sessionUser) {
               log(true);
           } else {
               log(false, "user:", user, "sessionUser:", sessionUser);
               res.statusCode = 401;
               const errorMessage = errMsgUserMismatch;
               res.setHeader('WWW-Authenticate', "Mutual " + authHeaderResponse + `, error="${errorMessage}"`);
               res.end();
           }
           log("Then he decodes the kc3 parameter, ...");
           const kc3Buffer = Buffer.from(kc3, 'base64');
           const kc3String = kc3Buffer.toString();
           const kc3JSON = JSON.parse(kc3String);
           log("kc3 from Client:", kc3JSON);
           log("... extracts the kc3 client signature JWT (JWS) ...");
           const kc3ClientJWS = JWS.parse(kc3JSON.clientSignature);
           log("kc3 client JWS:", kc3ClientJWS);
           log("... and verifies the JWT signature (JWS) with Alice' verifier key svk (as \"public key\").");
           const svkJSON = userDB[user].svk;
           const svkPub = JWK.asKey({
               kty: 'RSA',
               alg: 'PS256',
               e: svkJSON.e,
               n: svkJSON.n
           });
           let verifiedPayload;
           try {
               verifiedPayload = JWS.verify(kc3ClientJWS, svkPub, { algorithms: ['PS256'] });
               log(true, "Alice' signature is valid (verified with verifier key svk).");
           } catch (err) {
               console.error(false, 'Verification error:', err);
               res.statusCode = 401;
               const errorMessage = "invalid signature";
               res.setHeader('WWW-Authenticate', "Mutual " + authHeaderResponse + `, error="${errorMessage}"`);
               res.end();
           }
           log("He checks:");
           log(" - if the payload is matching the ks3 session record.");
           const sessionKs3 = session.ks3JSON;
           if (verifiedPayload === sessionKs3) {
               log(true);
           } else {
               log(false, "kc3ClientJwsPayload:", verifiedPayload, "sessionKs3:", sessionKs3);
               res.statusCode = 401;
               const errorMessage = "payload mismatch";
               res.setHeader('WWW-Authenticate', "Mutual " + authHeaderResponse + `, error="${errorMessage}"`);
               res.end();
           }
           log("he sends a login confirmation message to Alice's browser.");
           log("\nIf Alice has registered with svkRetrieval and requesets it now, he includes the encrypted svk.");
           const messageType = "User Login Confirmation";
           const timestampObj = new Date();
           const timestamp = timestampObj.toISOString();
           const svkRetrieval = verifiedPayload.svkRetrieval;
           const ks4JSON = {messageType, timestamp, authenticationServer, user};
           if (svkRetrieval) {
               const svk = JSON.stringify(svkJSON);
               ks4JSON = {...ks4JSON, svk};
           }
           log("Bob retrieves the shared secret from the session record ...");
           const sharedSecret = session.sharedSecret;
           log("Shared secret:\n", sharedSecret);
           log("... and encrypts the confirmation message (potentially including the svk) with the shared secret.");
           const ks4JWE = JWE.encrypt(ks4JSON, sharedSecret, {alg: 'ECDH-ES+A256KW', enc: 'A256GCM'});
           const ks4 = Buffer.from(ks4JWE).toString('base64');
           log("Bob's server updates the session timestamp ...");
           timeStampObj = new Date();
           timestamp = timeStampObj.toISOString();
           log("... and adds the login confirmation message to the login session record.");
           loginSessions[sid] = {... loginSessions[sid], kc3JSON, ks4JSON};
           log("Then, he archives the login session record with the timestamp to the user DB...");
           userDB[user].loginSessions[timestamp] = loginSessions[sid];
           log("... deletes the login session record ...");
           delete loginSessions[sid];
           log("... recreates sid and adds the user and the shared secret to the loggedinUsers.");
           sid = crypto.randomBytes(16).toString('hex');
           loggedinUsers[user] = {sid, timestampObj, sharedSecret};
           log("Finally, he sends the login confirmation message to Alice's browser (HTTP Response 4):\n", ks4JSON);
           res.statusCode = 200;
           res.setHeader('WWW-Authenticate', `Mutual ${authHeaderResponse}, ks4="${ks4}", time="3600"`);
           res.end();
       } else { // invalid HTTP Request
           log("Bob's server receives an invalid HTTP Request.");
           res.statusCode = 401;
           const errorMessage = "invalid HTTP Request";
           res.setHeader('WWW-Authenticate', `Mutual ${protocolParams}", realm="${realmLogin}", error="${errorMessage}"`);
           res.end();
       }
   } else
   // Handle the logout path
   if (req.url === '/logout') {
       const realmLogout = "User Logout";
       // Check if authentification header is present.
       // This flow initiates the logout process with a logout invitation message (401-INIT).
       if (!authHeader) {
           /** 
            * As is typical in general HTTP protocol designs, a client will at
            * first request a resource without any authentication attempt (1).
            * If the requested resource is protected by the Mutual
            * authentication protocol, the server will respond with a message
            * requesting authentication (401-INIT) 
           */
           res.statusCode = 401;
           log("Bob's server receives HTTP Request 1. ",
           "\nBecause it's for the /logout endpoint, he initiates a logout process.");
           const realm = "User Logout";
           const sid = crypto.randomBytes(16).toString('hex');
           const messageType = "User Logout Invitation";
           const timestampObj = new Date();
           const timestamp = timestampObj.toISOString();
           const nonceServerBytes = forge.random.getBytesSync(32);
           const nonceServer = forge.util.bytesToHex(nonceServerBytes);
           ks1JSON = {messageType, authenticationServer, timestamp, nonceServer};
           log("Bob's server generates a nonce and a timestamp,",
           "\nand sends a HTTP authorization header with an logout invitation to Alice's browser (HTTP Response 1):\n", 
           logoutMessage);
           const ks1String = JSON.stringify(ks1JSON);
           const ks1 = Buffer.from(ks1String).toString('base64');
           // 401-INIT message: logout invitation message to start the logout process
           logoutSessions[sid] = {ks1JSON, timestampObj};
           res.setHeader('WWW-Authenticate', `Mutual ${protocolParams}", realm="${realm}", sid="${sid}", ks1="${ks1}", time="3600"`);
           res.statusCode = 401;
           res.end();
       } else  
       // Check if authentication header is present, starts with 'Mutual ' and contains a kc1 parameter.
       // This flow processes the logout request message (401-REQ) and sends a logout confirmation message (200-VFY).
       if (authHeader.startsWith('Mutual ') && authHeader.includes('kc1=')) {
               const messageTypeClient = "user logout request";
               const messageTypeServer = "user logout confirmation";
               log("Bob's server receives the user logout request message (HTTP Request 2)...");
               const authHeaderParams = this.parseAuthHeader(authHeader);
               log("... and checks:\n",
               "- if version is 1, algorithm is 'mA3PAKE', validation is 'RSA-PSS' and realm is 'User Logout");
               checkAuthHeader(authHeaderParams, realmLogout);
               const { sid, user, kc1 } = authHeaderParams; 
               log(" - if the sid is valid and the logout process has not expired,");
               checkSession(sid, realmLogout);
               const session = logoutSessions[sid];
               log(" - if the provided user is currently logged in.");
               const loggedinUser = loggedinUsers[user];
               if (loggedinUser) {
                   log(true);
                   log("Then he decodes the kc1 parameter..."); 
                   const kc1ClientJWS = JWS.parse(kc1);
                   log("... and checks if the clients signature is valid.");
                   const svkJSON = userDB[user].svk;
                   const svkPub = JWK.asKey({
                       kty: 'RSA',
                       alg: 'PS256',
                       e: svkJSON.e,
                       n: svkJSON.n
                   });
                   let verifiedPayload;
                   let payloadIsMatching;
                   try {
                       verifiedPayload = JWS.verify(kc1ClientJWS, svkPub, { algorithms: ['PS256'] });
                       log(true, "Alice' signature is valid (verified with verifier key svk).");
                       log8("He also checks if the payload is matching the ks1 session record.");
                       const sessionKs1 = session.ks1JSON;
                       if (verifiedPayload === JSON.stringify(sessionKs1)) {
                           log(true);
                           payloadIsMatching = true;
                       } else {
                           log(false, "kc1ClientJwsPayload:", verifiedPayload, "sessionKs1:", sessionKs1);
                           payloadIsMatching = false;
                       }
                   } catch (err) {
                       console.error(false, 'Verification error:', err);
                       clientSignatureValid = false;
                   }

               } 
               if (!loggedinUser || !clientSignatureValid || !payloadIsMatching) {
                   log(false, "user:", user);
                   res.statusCode = 401;
                   const errorMessage = "user not logged in, or invalid signature or payload";
                   res.setHeader('WWW-Authenticate', `Mutual ${protocolParams}", realm="${realmLogout}", sid="${sid}", error="${errorMessage}"`);
                   res.end();
               }
               log("He creates a logout confirmation message ...");
               const timestampObj = new Date();
               const timestamp = timestampObj.toISOString();
               const ks2JSON = {messageTypeServer, timestamp, authenticationServer, user};
               log("... signs it with svk ...");
               const ks2String = JSON.stringify(ks2JSON);
               const ks2JWS = JWS.sign(ks2String, svk, {alg: 'PS256'});
               const ks2JWSString = JSON.stringify(ks2JWS);
               log("... encrypts it with the shared secret ...");
               const sharedSecret = loggedinUser.sharedSecret;
               const ks2JWE = JWE.encrypt(ks2JWSString, sharedSecret, {alg: 'ECDH-ES+A256KW', enc: 'A256GCM'});
               const ks2 = Buffer.from(ks2JWE).toString('base64');
               log("... and sends it to Alice's browser (HTTP Response 2):\n", ks2JSON);
               res.statusCode = 200;
               res.setHeader('WWW-Authenticate', `Mutual ${protocolParams}", realm="${realmLogout}", sid="${sid}", ks2="${ks2}", time="3600"`);
               res.end();
       } else { // invalid HTTP Request
           log("Bob's server receives an invalid HTTP Request.");
           res.statusCode = 401;
           const errorMessage = "invalid HTTP Request";
           res.setHeader('WWW-Authenticate', `Mutual ${protocolParams}", realm="${realmLogout}", error="${errorMessage}"`);
           res.end();
       }
   } else 
   // Handle transactions 
   if (req.url === '/transaction') {
       // Check if authentification header is present and if the body contains an action object
       // This flow initiates the transaction process with a transaction invitation message (401-INIT).
       if (!authHeader && req.body.action) {
           /** 
            * As is typical in general HTTP protocol designs, a client will at
            * first request a resource without any authentication attempt (1).
            * If the requested resource is protected by the Mutual
            * authentication protocol, the server will respond with a message
            * requesting authentication (401-INIT) 
           */
           res.statusCode = 401;
           log("Bob's server receives a regular HTTP Request 1. ",
           "\nIts request body contains an unauthorized transaction request message,",
           "\ne.g. {action:{user:'alice1',type:'purchase',itemNr:12345,price:99.99,currency:'EUR'}}.",
           "\nBecause it was directed at the /transaction endpoint, it needs to be authorized.",
           "\nBob's server initiates a transaction process to get a binding signature from Alice's.");
           const action = req.body.action;
           const realm = "User Transaction";
           const sid = crypto.randomBytes(16).toString('hex');
           const messageType = "User Transaction Invitation";
           const timestampObj = new Date();
           const timestamp = timestampObj.toISOString();
           const nonceServerBytes = forge.random.getBytesSync(32);
           const nonceServer = forge.util.bytesToHex(nonceServerBytes);
           ks1JSON = {messageType, authenticationServer, timestamp, nonceServer};
           log("Bob's server generates a nonce and a timestamp,",
           "\nand sends a HTTP authorization header with an transaction invitation to Alice's browser (HTTP Response 1):\n", 
           transactionMessage);
           const ks1String = JSON.stringify(ks1JSON);
           const ks1 = Buffer.from(ks1String).toString('base64');
           // 401-INIT message: transaction invitation message to start the transaction process
           transactionSessions[sid] = {ks1JSON, timestampObj};
           res.setHeader('WWW-Authenticate', `Mutual ${protocolParams}", realm="${realm}", sid="${sid}", ks1="${ks1}", time="3600"`);
           res.statusCode = 401;
           res.end();
       } else  
       // Check if authentication header is present, starts with 'Mutual ' and contains a kc1 parameter.
       // This flow processes the transaction request message (401-REQ) and sends a transaction challenge message (401-CH).
       if (authHeader.startsWith('Mutual ') && authHeader.includes('kc1=')) {
           // TODO
       } else {
           res.statusCode = 404;
           res.end();
       }
   }
});
//server.listen(3000, () => {
//   log('Server running at http://localhost:3000/');
// });

// #endregion