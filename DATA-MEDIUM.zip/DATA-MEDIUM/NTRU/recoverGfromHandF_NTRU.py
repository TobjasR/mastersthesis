import numpy as np
# Parameters and Polynomials from Wikipedia example
# Given parameters
q = 3  # Modulo value
N = 11  # Degree + 1
# Given polynomials
f = [-1,  1,   1,   0, -1,  0,  1,   0,  0,   1, -1][::-1]
g = [-1,  0,   1,   1,  0,  1,  0,   0, -1,   0, -1][::-1]
h = [ 8, -7, -10, -12, 12, -8, 15, -13, 12, -13, 16][::-1]

def mod_XN_1(poly, N):
    """Reduce a polynomial modulo (x^N - 1)."""
    divisor = np.zeros(N + 1)
    divisor[0] = -1
    divisor[N] = 1  # x^N - 1
    quotient, remainder = np.polydiv(poly, divisor)
    # Ensure coefficients are integers
    remainder = np.round(remainder).astype(int)
    return remainder

def print_poly(poly, fun = "f", var="x"):
    """Print a polynomial in readable form."""
    terms = [f"{coef}{var}^{i}" for i, coef in enumerate(poly) if coef != 0]
    poly_str = " + ".join(terms[::-1])
    print(f"{fun}(x) = {poly_str}")

# Step 1: Compute f * h
fh_mul = np.polymul(f, h)
# Step 2: Reduce the polynomial modulo (x^N - 1)
fh_mod_xN_1 = mod_XN_1(fh_mul, N)
# Step 3a: Compute modulo q+1
fh_mod_q = np.mod(fh_mod_xN_1, q+1)
# Step 3b: Map coefficients to {-q/2, …, 0, …, q/2}
q_2 = ((q-1)//2)+1
fh = np.where(fh_mod_q != 0, fh_mod_q - q_2, fh_mod_q)

# Output the polynomials
print_poly(f, "f")
print_poly(h, "h")
print_poly(fh, "f*h")
print_poly(g, "  g")
# Check if f*h is equal to g
print("f*h equals to g: ", np.array_equal(fh, g))