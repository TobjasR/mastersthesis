const Worker = require('tiny-worker');
const path = require('path');
const forge = require('node-forge');
const BigInteger = forge.jsbn.BigInteger;
const { bigIntegerToBase64url } = require('../utils/backups/base64url_BigInteger');
const { log, error: logError, timeStamp } = require('console');

/** Generate a Key-pair Generator Base for RSA, i.e. two safe primes p and q.
 * @param {number} bits - The number of bits of the safe primes.
 * @param {number} threads - The number of threads to use.
 * @returns {Promise<{p: BigInteger, q: BigInteger}>} - A promise to a n object containing the two safe primes p and q.
 * @throws {Error} - If the worker throws an error.
 */
async function generateKeyPairGenBaseRSA(bits, threads) { 
    let counter = 0; // DEBUG - count the number of keys generated and tested for safe primes
    const start = Date.now(); // DEBUG - measure the time this takes
    // Generate two safe primes in parallel
    const safePrimes = await new Promise((resolve, reject) => {
        const factory = []; // Array to accommodate our tireless tiny-workers
        const storage = []; // Array to store the safe primes they have found
        let done = false; // Let the workers know when to stop
        // Start the workers
        log("Starting workers ...");
        for (let i = 0; i < threads; i++) {
            const worker = new Worker(path.join(__dirname, 'worker_node-forge.js'));
            worker.name = `Tiny Worker ${i}`; // Assign a name to the worker
            // log(`Pushing ${worker.name} into \`factory\` Array ...`);
            factory.push(worker);
            // Handle messages from the worker
            worker.onmessage = function(delivery) {
                counter++; //DEBUG
                // Extract the worker's the results from its message
                const workpieces = delivery.data;
                // check if piece of the workpieces is not null and push it into the storage array
                for (let piece in workpieces) {
                    if (workpieces[piece] !== null) {
                        const time = ((Date.now() - start)/1000).toFixed(5);
                        const safePrime = workpieces[piece];
                        log(`Safe prime found by ${this.name} after ${time} seconds:\n${safePrime}`, );
                        storage.push(safePrime);
                    }
                }
                // If the array has two safe primes, terminate the worker and resolve the promise
                if (storage.length >= 2 && !done) {
                    done = true;
                    log("Terminating workers ...");
                    factory.forEach(worker => {
                        /// log(`Terminating ${worker.name} ...`); 
                        worker.terminate();
                    });
                    resolve(storage);
                } else if (!done) {
                    // Continue generating
                    worker.postMessage(bits);
                }
            };
            // Handle errors from the worker
            worker.onerror = function(error) {
                logError(`${this.name} encountered an error: ${error.message}`);
                reject(error);
            };
            worker.postMessage(bits);
        }
        log(threads + " workers started.")
    }).then(array => {
    log("Workers have finished.");
    return array;
    });
    log("Time it took:", ((Date.now() - start)/60000).toFixed(7), "min"); //DEBUG
    log("Primes tested:", 2 * counter); //DEBUG
    // convert decimal to base64url
    const pInt = new BigInteger(safePrimes[0]);
    const qInt = new BigInteger(safePrimes[1]);
    const jwk = {
        kty: "RSA",
        p: bigIntegerToBase64url(pInt),
        q: bigIntegerToBase64url(qInt),
        e: null, d: null, n: null,
    };
    return jwk;
}

module.exports = generateKeyPairGenBaseRSA;