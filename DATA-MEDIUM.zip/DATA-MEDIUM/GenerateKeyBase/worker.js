// Detect environment
const isBrowser = typeof window !== 'undefined';
const isNodeJs = typeof process !== 'undefined' 
            && process.versions != null && process.versions.node != null;
// Import crypto module depending on the environment
const crypto = isNodeJs ? require('node:crypto') : require('crypto-browserify');
// Use crypto.subtle for WebCrypto API
const subtle = crypto.subtle;
// Handle paths depending on the environment
const path = require('path');
// Import utility functions for safe prime testing and base64url (JWK formart) conversion
const isSafePrime = require(path.resolve(__dirname, 'utils/isSafePrime.js'));
const { base64urlToBigInteger } = require(path.resolve(__dirname, 'utils/base64url_BigInteger.js'));

// Generates RSA private key (JWK format) and returns p and q as BigIntegers
async function generatePrimes(bits) {
    // RSA key generation parameters for WebCrypto API
    const params = {
        name: "RSASSA-PKCS1-v1_5",
        modulusLength: bits,
        publicExponent: new Uint8Array([1, 0, 1]),
        hash: "SHA-256"
    };
    // Usage of the key pair
    const usage = ["sign", "verify"];
    // Generate a new RSA key pair (with p and q) using the WebCrypto API
    const keyPair = await subtle.generateKey(params, true, usage);
    // Extract the private key (holding the primes p and q) ...
    const privKey = keyPair.privateKey;
    // ... and export it as JWK (JSON Web Key) with p and q in base64url format
    const privKeyJwk = await subtle.exportKey("jwk", privKey);
    // Convert p and q to BigIntegers ...
    const p = base64urlToBigInteger(privKeyJwk.p);
    const q = base64urlToBigInteger(privKeyJwk.q);
    // ... and return them for the caller to check if they are safe primes
    return [p, q];
}

// Generate RSA private key and test if p or q is a safe prime
async function generateAndTest(bits) {
    const [p, q] = await generatePrimes(bits);
    const result = {
        // Return a safe prime if found (as decimal string), otherwise return null
        p: isSafePrime(p)? p.toString(10) : null,
        q: isSafePrime(q)? q.toString(10) : null
    };
    return result;
}

// Self-reference for the worker depending on the environment
const globalObject = isBrowser ? self : global;

// Handle messages from the caller (main thread) which is telling the worker...
globalObject.onmessage = event => {
    // ...  the needed bit length for the safe primes for him to generate and test.
    const bits = event.data;
    // So, the worker now starts generating primes and tests if they are safe primes ...
    generateAndTest(bits).then(result => {
        // ... and, as thr result, sends the found safe primes (if any) back to the caller.
        globalObject.postMessage(result);
    }).catch(error => { // Handle errors
        console.error('Error while generating (and testing for safe-)primes:', error);
    });
};