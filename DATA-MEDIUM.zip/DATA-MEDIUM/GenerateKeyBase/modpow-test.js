const forge = require('node-forge');
const BigInteger = forge.jsbn.BigInteger;


// generate three random bigintegers of 2028 bits each and test the modpow function with them
function getRandomBigInteger(bitLength) {
    const byteLength = Math.ceil(bitLength / 8);
    const randomBytes = forge.random.getBytesSync(byteLength);
    const randomHex = forge.util.bytesToHex(randomBytes);
    return new BigInteger(randomHex, 16);
}

// forloop with 1000 iterations

let bits = 2000;
for (let i = 0; i < 100; i++) {
    const a = getRandomBigInteger(bits);
    const b = getRandomBigInteger(bits);
    const c = getRandomBigInteger(bits);
    // stop the time 
    const start = Date.now();
    for (let i = 0; i < 1; i++) {
        const result = a.modPow(b, c);
    }
    const stop = Date.now();
    console.log((stop - start) /1000, "s");
    bits = bits + 100;
    console.log(bits, "bits");
}

