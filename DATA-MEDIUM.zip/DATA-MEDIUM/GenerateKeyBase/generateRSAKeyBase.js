const forge = require('node-forge');
const BigInteger = forge.jsbn.BigInteger;
const ONE = new BigInteger("1");
const TWO = new BigInteger("2");

const generateRandom = require('../utils/generateRandom');

function findPrime(num, callback) {
    /* Note: All primes are of the form 30k+i for i < 30 and gcd(30, i)=1. The
    number we are given is always aligned at 30k + 1. Each time the number is
    determined not to be prime we add to get to the next 'i', eg: if the number
    was at 30k + 1 we add 6. */
    
    // primes are 30k+i for i = 1, 7, 11, 13, 17, 19, 23, 29
    const GCD_30_DELTA = [6, 4, 2, 4, 2, 4, 6, 2];
    let deltaIdx = 0;
  
    // find prime nearest to 'num' for 100ms
    let start = Date.now();
    while(Date.now() - start < 100000) {
      // do primality test (only 2 iterations assumes at
      // least 1251 bits for num)
      if(num.isProbablePrime(2)) {
        return callback(num);
      }
      // get next potential prime
      num.dAddOffset(GCD_30_DELTA[deltaIdx++ % 8], 0);
    }
  
    // keep trying (setImmediate would be better here)
    setTimeout(function() {
      findPrime(num, callback);
    });
}

function generateSophieGermainPrime(bits) {
    let prime;
    let num;
    let sg;
    function setprime(number){prime = number;}
    do {
        // generate random BigInteger
        num = generateRandom(bits);
        // find prime nearest to random number
        findPrime(num, setprime);
        sg = prime.multiply(TWO).add(ONE);
    } while (!(sg.isProbablePrime(2)));
    return prime;
}

function generateSafePrime(bits) {
    const sophieGermain = generateSophieGermainPrime(bits - 1);
    const safePrime = sophieGermain.multiply(TWO).add(ONE);
    return safePrime;
}

function generateRSAKeyBase(bits) {
    let startTime = process.hrtime();
    let elapsedTime = process.hrtime(startTime);
    console.log(`Starting generateRSAKeyBase() for ${bits} bits: ${elapsedTime[0]}s ${elapsedTime[1] / 1e6}ms`);
    const bytes = bits / 8;
    const p = generateSafePrime(bits);
    elapsedTime = process.hrtime(startTime);
    console.log(`Elapsed time for generateSafePrime, p: ${elapsedTime[0]}s ${elapsedTime[1] / 1e6}ms`);
    console.log(`p: ${p.toString(10)}`);
    const q = generateSafePrime(bits);
    elapsedTime = process.hrtime(startTime);
    console.log(`Elapsed time for generateSafePrime, q: ${elapsedTime[0]}s ${elapsedTime[1] / 1e6}ms`);
    console.log(`q: ${q.toString(10)}`);
    const n = p.multiply(q);
    console.log(`n: ${n.toString(10)}`);
    const phi = p.subtract(ONE).multiply(q.subtract(ONE));
    const keybase = {p, q, n, phi};
    return keybase;
}

module.exports = generateRSAKeyBase;