const Worker = require('tiny-worker');
const path = require('path');
const forge = require('node-forge');
const BigInteger = forge.jsbn.BigInteger;
const { bigIntegerToBase64url } = require('../utils/backups/base64url_BigInteger');
const { log, error: logError, timeStamp } = require('console');

/** Generate a Key-pair Generator Base for RSA, i.e. two safe primes p and q.
 * @param {number} bits - The number of bits of the safe primes.
 * @param {number} threads - The number of threads to use.
 * @returns {Promise<{p: BigInteger, q: BigInteger}>} - A promise to a n object containing the two safe primes p and q.
 * @throws {Error} - If the worker throws an error.
 */
function generateKeyPairGenBaseRSA(bits, threads) { 
    return new Promise((resolve, reject) => {
    let counter = 0; // DEBUG - count the number of keys generated and tested for safe primes
    const start = Date.now(); // DEBUG - measure the time this takes
    // Generate two safe primes in parallel
    const factory = []; // Array to accommodate our tireless tiny-workers
    const storage = []; // Array to store the safe primes they have found
    let done = false; // Let the workers know when to stop
    // Start the workers
    //log("Starting workers ...");
    log(threads + " workers started.")
    for (let i = 0; i < threads; i++) {
        const worker = new Worker(path.join(__dirname, 'worker_node-forge.js'));
        worker.name = `Tiny Worker ${i}`; // Assign a name to the worker
        // log(`Pushing ${worker.name} into \`factory\` Array ...`);
        factory.push(worker);
        // Handle messages from the worker
        worker.onmessage = function(delivery) {
            counter++; //DEBUG
            // Extract the worker's the results from its message
            const workpieces = delivery.data;
            // check if piece of the workpieces is not null and push it into the storage array
            for (let piece in workpieces) {
                if (workpieces[piece] !== null) {
                    const time = ((Date.now() - start)/1000).toFixed(5);
                    const safePrime = workpieces[piece];
                    log(`Safe prime found by ${this.name} after ${time} seconds:\n${safePrime}`, );
                    storage.push(safePrime);
                }
            }
            // If the array has two safe primes, terminate the worker and resolve the promise
            if (storage.length >= 2 && !done) {
                done = true;
                log("Terminating workers ...");
                factory.forEach(worker => worker.terminate());

                // convert decimal to base64url
                const pInt = new BigInteger(storage[0]);
                const qInt = new BigInteger(storage[1]);
                const jwk = {
                    kty: "RSA",
                    p: bigIntegerToBase64url(pInt),
                    q: bigIntegerToBase64url(qInt),
                    e: null, d: null, n: null,
                };
                resolve(jwk); // resolve the promise with the jwk object
            } else if (!done) {
                worker.postMessage(bits);
            }
        };

        worker.onerror = function(error) {
            logError(`${this.name} encountered an error: ${error.message}`);
            reject(error); // reject the promise with the error
        };

        worker.postMessage(bits);
    }
});
}
module.exports = generateKeyPairGenBaseRSA;