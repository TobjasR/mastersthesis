
// Detect environment
const isBrowser = typeof window !== 'undefined';
const isNodeJs = typeof process !== 'undefined' 
            && process.versions != null && process.versions.node != null;
let forge;
if (isNodeJs) { // Node.js environment
    forge = require('node-forge');
} else if (isBrowser) { // Browser environment
    import('node-forge').then((module) => { forge = module; });
} else {
    throw new Error("Unknown environment.");
}
const ONE = new forge.jsbn.BigInteger('1');
const TWO = new forge.jsbn.BigInteger('2');

// Check if a number is a safe prime (p = 2q + 1, where q is also prime)
function isSafePrime(p, iterations = 5) {
    // Sophie Germain prime candidate
    const q = p.subtract(ONE).divide(TWO);
    // Check if candidate is prime
    const pIsSafePrime = q.millerRabin(iterations);
    return pIsSafePrime;
}
module.exports = isSafePrime;