const forge = require('node-forge');
const BigInteger = forge.jsbn.BigInteger;
const ONE = new BigInteger('1');
const TWO = new BigInteger('2');
const pki = forge.pki;
// Handle paths depending on the environment
const path = require('path');
// Import utility functions for safe prime testing and base64url (JWK formart) conversion
const isSafePrime = require(path.resolve(__dirname, 'utils/isSafePrime'));
const { base64urlToBigInteger } = require(path.resolve(__dirname, 'utils/base64url_BigInteger'));

// #region For tests with CUSTOMIZED prime number generation and pseudo-Miller-Rabin primality test
// Generates a random BigInteger of the given bit length
function getRandomBigInteger(bitLength) {
    const byteLength = Math.ceil(bitLength / 8);
    const randomBytes = forge.random.getBytesSync(byteLength);
    const randomHex = forge.util.bytesToHex(randomBytes);
    return new BigInteger(randomHex, 16);
}
// Custom pseudo-Miller-Rabin primality test
function pseudoMillerRabin(p, k = 3) {
    const e = p.subtract(ONE);
    for (let i = 0; i < k; i++) {
        const r = getRandomBigInteger(p.bitLength());
        const rPowEmodP = r.modPow(e, p);
        if (!rPowEmodP.equals(ONE)) {
            return false;
        }
    }
    return true;
}
// Keeps generating random numbers until a prime is found and returns it
function generatePrimesRandom(bits) {
    factorBits = Math.floor(bits / 2);
    let p;
    do {
        p = getRandomBigInteger(factorBits);
    } while (!pseudoMillerRabin(p));
    const q = null;
    return [p, q];
}
// Test if p is a safe prime using a pseudo-Miller-Rabin primality test
function isSafePrimePseudoMR(p) {
    // if p is no BigInteger, return false
    if (!(p instanceof BigInteger)) {
        return false;
    }
    if (!pseudoMillerRabin(p)) {
        throw new Error('p is not even prime');
    }
    // Sophie Germain prime candidate
    const q = p.subtract(ONE).divide(TWO);
    // Check if candidate is prime
    const pIsSafePrime = pseudoMillerRabin(q);
    return pIsSafePrime;
}
// Tests if p is a Sophie Germain prime using a pseudo-Miller-Rabin primality test
function isSophieGermainPrime(p) {
    // if p is no BigInteger, return false
    if (!(p instanceof BigInteger)) {
        return false;
    }
    if (!pseudoMillerRabin(p)) {
        throw new Error('p is not even prime');
    }
    // Sophie Germain prime candidate
    const q = p.subtract(ONE).divide(TWO);
    // Check if candidate is prime
    const pIsSafePrime = pseudoMillerRabin(q);
    return pIsSafePrime;
}
// For tests with CUSTOMIZED prime number generation and pseudo-Miller-Rabin primality test:
// p = isSophieGermainPrime(p)? p.multiply(TWO).add(ONE) : p;
// q = isSophieGermainPrime(q)? q.multiply(TWO).add(ONE) : q;

// #endregion

// Generates RSA private key (node-forge) and tests if p or q is a safe prime
function generatePrimesPKI(bits) {
    // RSA key generation parameters for node-forge
    const keypair = pki.rsa.generateKeyPair({bits: bits - 1 , workers: -1});
    // Get private key parameters (p and q) as BigInteger
    const p = keypair.privateKey.p;
    const q = keypair.privateKey.q;
    return [p, q];
}

// Generate RSA private key and test if p or q is a safe prime
function generateAndTest(bits) {
    let [p, q] = generatePrimesPKI(bits);
    const result = {
        // Return a safe prime if found (as decimal string), otherwise return null
        p: isSafePrime(p)? p.toString(10) : null,
        q: isSafePrime(q)? q.toString(10) : null
    };
    return result;
}

// Detect environment
const isBrowser = typeof window !== 'undefined';
// Self-reference for the worker depending on the environment
const globalObject = isBrowser ? self : global;
// Handle messages from the caller (main thread) which is telling the worker...
globalObject.onmessage = event => {
    // ...  the needed bit length for the safe primes for him to generate and test.
    const bits = event.data;
    // So, the worker now starts generating primes and tests if they are safe primes ...
    try {
        const result = generateAndTest(bits);
        // ... and, as the result, sends the found safe primes (if any) back to the caller.
        globalObject.postMessage(result);
    } catch (error) { // Handle errors
        console.error('Error while generating (and testing for safe-)primes:', error);
    }
};