const forge = require('node-forge');
const BigInteger = forge.jsbn.BigInteger;

// convert base64url to BigInteger
function base64urlToBigInteger(b64url) {
    const base64 = b64url.replace(/-/g, '+').replace(/_/g, '/');
    const buffer = Buffer.from(base64, 'base64');
    hex = '0x'+buffer.toString('hex');
    return BigInteger(hex);
}
// convert BigInteger to base64url
function bigIntegerToBase64url(bigint) {
    const hex = BigInteger.toString(16);
    const buffer = Buffer.from(hex, 'hex');
    const base64 = buffer.toString('base64');
    const base64url = base64.replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');
    return base64url;
}
module.exports = { base64urlToBigInteger, bigIntegerToBase64url };