#include <iostream>
#include <gmp.h>
#include <cstdlib>

void RecoverPQ(mpz_t n, mpz_t e, mpz_t d, mpz_t &p, mpz_t &q) {
    mpz_t k, r, t, y, g, x, temp;
    mpz_inits(k, r, t, y, g, x, temp, NULL);

    // Step 1: Let k = de – 1. If k is odd, then go to Step 4
    mpz_mul(k, d, e);
    mpz_sub_ui(k, k, 1);

    if (mpz_even_p(k)) {
        // Step 2
        mpz_set(r, k);
        mpz_set_ui(t, 0);

        while (mpz_even_p(r)) {
            mpz_tdiv_q_ui(r, r, 2);
            mpz_add_ui(t, t, 1);
        }

        // Step 3
        bool success = false;
        gmp_randstate_t state;
        gmp_randinit_default(state);

        for (int i = 1; i <= 100; i++) {
            // 3a
            do {
                mpz_urandomm(g, state, n);
            } while (mpz_cmp(g, n) >= 0);

            // 3b
            mpz_powm(y, g, r, n);

            // 3c
            if (mpz_cmp_ui(y, 1) == 0 || mpz_cmp(y, n) == 0) {
                continue;
            }

            // 3d
            for (mpz_set_ui(temp, 1); mpz_cmp(temp, t) < 0; mpz_add_ui(temp, temp, 1)) {
                mpz_powm_ui(x, y, 2, n);
                if (mpz_cmp_ui(x, 1) == 0) {
                    success = true;
                    break;
                }
                if (mpz_cmp(x, n) == -1) {
                    continue;
                }
                mpz_set(y, x);
            }

            // 3e
            mpz_powm_ui(x, y, 2, n);
            if (mpz_cmp_ui(x, 1) == 0) {
                success = true;
                break;
            }
        }

        if (success) {
            // Step 5
            mpz_sub_ui(temp, y, 1);
            mpz_gcd(p, temp, n);
            mpz_tdiv_q(q, n, p);
            return;
        }
    }
    throw std::runtime_error("Cannot compute P and Q");
}

int main() {
    mpz_t n, e, d, p, q;
    mpz_inits(n, e, d, p, q, NULL);

    std::cout << "Enter n: ";
    gmp_scanf("%Zd", &n);

    std::cout << "Enter e: ";
    gmp_scanf("%Zd", &e);

    std::cout << "Enter d: ";
    gmp_scanf("%Zd", &d);

    try {
        RecoverPQ(n, e, d, p, q);
        gmp_printf("p: %Zd\n", p);
        gmp_printf("q: %Zd\n", q);
    } catch (const std::exception& ex) {
        std::cerr << ex.what() << std::endl;
    }

    mpz_clears(n, e, d, p, q, NULL);
    return 0;
}

