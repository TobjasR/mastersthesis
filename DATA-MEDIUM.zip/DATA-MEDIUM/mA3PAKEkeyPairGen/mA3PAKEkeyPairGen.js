// #region Imports, constants, and global variables
// Detect environment
const isBrowser = typeof window !== 'undefined';
const isNodeJs = typeof process !== 'undefined' 
            && process.versions != null && process.versions.node != null;

const crypto = isNodeJs ? require('node:crypto') // use node.js crypto module
             : isBrowser? require('crypto-browserify') // use browserify crypto module
             : null;
if (!crypto) {
    throw new Error("Unknown environment.");
}
const forge = require('node-forge');
const BigInteger = forge.jsbn.BigInteger;
const ZERO = new BigInteger('o');
const ONE = new BigInteger('1');
const TWO = new BigInteger('2');
const { bigIntegerToBase64url, base64urlToBigInteger } = require('../utils/backups/base64url_BigInteger.js');
const { timeStamp, log, error, time } = require('console');
// const generateKeyPairGenBaseRSA = require('./generateKeyPairGenBaseRSA.js');
const generateKeyPairGenBaseRSA = require('./generateKeyPairGenBaseRSA_node-forge.js');
const e = require('express');
// #endregion

// Generic Key-pair Generator (KPG) Class
class mA3PAKEkeyPairGen {
    // Name of this class
    static name = 'Key-pair Generator (KPG)';
    // Custom string tag (name) for this class (displayed as the constructor name)
    //static get [Symbol.toStringTag]() {
    //    return this.name;
    //} // private fields of the KPG instance: 
    #type;// the KPG type,
    #base;// its base, and
    #fingerprint;// base fingerprint
    #threads; // number of threads for key generation

    static TYPES = {
        // RSA-based KPG is the only type currently supported
        // is defined in the static RSA property below this class
        RSA: "RSA",
        // TODO: Add other types here...
        // NEW_TYPE: "NEW_TYPE",

    }
    // get the type of this KPG instance
    get type () { 
        return this.#type;  
    } 
    // return a base or (await) the promise to the base (and then return it)
    async getBase() {
        return await this.#base;
    }
    // Get the fingerprint of this KPG instance 
    async getFingerprint () {
        return await this.#fingerprint;
    }
    // Constructor for the Key-pair Generator (KPG) object
        constructor(base, threads = null) {
        const TYPES = this.constructor.TYPES;
        const isSupportedType = this.constructor.isSupportedType;
        const isSupportedBase = this.constructor.isSupportedBase;
        const errMsgInvalid = this.constructor.errMsgInvalid;

        this.#threads = threads || this.constructor.threads;

        if (!base) { // check if nothing (no argument true argument) is passed for typeOrBase
            this.#type = TYPES.DEFAULT; // if so, use default KPG type
            log("Set KPG base to default type :" + this.#type);
        } else if (isSupportedType(base)) { // else, check if a supported KPG type string is passed
            const type = base.toUpperCase(); // if yes, put to upper case ...
            this.#type = type; // ... and set the type of this KPG instance accordingly
        } else if (isSupportedBase(base)) { // else, check if a supported JWK is passed
            // if so, pass it to the setter for it to check and set the base of this KPG instance accordingly
            log ("Setting KPG base to the provided base:" + base);
            this.#setKeyPairGenBase(base).then(() => {
                log("KPG base set to the provided base:", this.#base);
            }).catch((err) => {
                throw new Error(errMsgInvalid("base") + base);
            });
        } else { // if none of the above is the case, it is an invalid argument
            throw new Error(errMsgInvalid("argument") + base);
        }
    }
    async init({type = this.#type, threads = this.#threads, nBitsRSA = null} = {}) {
        const generateBase = this.constructor.generateBase;
        log("In init, now");
        //log("Instructing `generateBase()` with the generation of a new" 
         //   + type + "-type KPG base,", "using", threads, "threads.");
        if (!this.#base) {
            log("No base set yet, generating a new one.");
            try {
                const base = await generateBase({type, threads, nBitsRSA});
                //log("Setting KPG base to the generated base:" + base);
                await this.#setKeyPairGenBase(base);
            } catch (err) {
                error("base" + err);
            }
        }
    }
    static get threads() {
        // default number of threads for key generation (number of detected CPU cores)
        const threads = (isBrowser ? navigator.hardwareConcurrency 
                                  : require('os').cpus().length);
        return threads;
    }
    // error messages for name of this class
    static errMsgInvalid(issue) { 
        return `Invalid ${issue} for KPG + ": `;
    }
    // Generate a new key-pair generator base (KPGB) and return it
    // (this is an asynchronous function, which returns a promise to the KPGB)
    // By default (if no type is specified), generate RSA-based KPGB
    static generateBase({
            type = mA3PAKEkeyPairGen.TYPES.RSA, 
            threads = this.threads, 
            nBitsRSA = null
        } = {}) {
        const errMsgInvalid = mA3PAKEkeyPairGen.errMsgInvalid;
        // check if type is a string, if not, throw an error
        if (!(typeof type === 'string' || type instanceof String)) {
            throw new Error(errMsgInvalid("type") + type);
        }
        // to upper case type
        type = type.toUpperCase();
        let base = null;
        // if type is invalid (not one of the TYPES), throw an error
        //log ("mA3PAKEkeyPairGen.TYPES[type]:" + mA3PAKEkeyPairGen.TYPES[type]);
        if (!mA3PAKEkeyPairGen[type]) {
            throw new Error(errMsgInvalid("type") + type);
        } // check if type is RSA
        //log ("type === mA3PAKEkeyPairGen.TYPES.RSA (should be true):" 
          //  + (type === mA3PAKEkeyPairGen.TYPES.RSA));
        if (type === mA3PAKEkeyPairGen.TYPES.RSA) {
            // in case of RSA, generate a new safe prime key base
            // nBitsRSA: (nBitsRSA? nBitsRSA : mA3PAKEkeyPairGen.RSA.nBits)});
            log("Starting generation of a new", (nBitsRSA? nBitsRSA : mA3PAKEkeyPairGen.RSA.nBits) 
               +"-bit RSA-type KPG base, using", threads, "threads in parallel.");
            try {
                base = generateKeyPairGenBaseRSA(nBitsRSA, threads);
            } catch (err) {
                console.error('An error occurred generating the RSA KPG:', error);
            }
        } else // check if type is one of the other TYPES
        if (mA3PAKEkeyPairGen.TYPES[type]) {
            // as long as no other TYPES are implemented, this `else` will not be reached
        } else 
        // TODO: Add other types here... 
        // if (type === mA3PAKEkeyPairGen.TYPES.NEW_TYPE)
        // {
                // set the type accordingly and generate a new key base of type NEW_TYPE 
        // } else 
        { // if type is invalid (not one of the TYPES), throw an error
            throw new Error(errMsgInvalid("type") + type);
        }
        // return the promise to the key base
        return base;
    }
    // Checks if the type is supported (one of the TYPES)
    static isSupportedType(type) {
        // if it is not a string, return false
        if (!(typeof type === 'string' || type instanceof String)) {
            return false;
        }
        // check if it is a valid type (one of the TYPES)
        if (type.toUpperCase() in mA3PAKEkeyPairGen.TYPES) { // if so, return true
            return true;
        } else { // if it is not a valid type, return false
            return false;
        }
    }
    // Checks if the base is supported (a JWK object with kty in TYPES)
    static isSupportedBase(base) {
        const TYPES = mA3PAKEkeyPairGen.TYPES;
        if (!(typeof base === 'object' || base instanceof Object)) {
            log("base is not an object");
            return false;
        }
        // check if the base has the JWK property 'kty' (key type), else throw an error
        if (!base.kty) {
            log("base has no kty");
            return false;
        }
        // check if this JWK has a valid type (upper case kty in TYPES)
        const type = base.kty.toUpperCase();
        if (!TYPES[type]) {
            log("base has invalid type");
            return false;
        }
        //log("base has valid type");
        return true;
    }
    // Set the base of this KPG instance
    async #setKeyPairGenBase(base) {
        const errMsgInvalid = mA3PAKEkeyPairGen.errMsgInvalid;
        const isSupportedBase = mA3PAKEkeyPairGen.isSupportedBase;
        const TYPES = mA3PAKEkeyPairGen.TYPES;
    
        // check if the base is a JWK object, else throw an error
        if (!isSupportedBase(base)) {
            log("base is not a supported base in setKeyPairGenBase");
            throw new Error(errMsgInvalid("base") + base);
        } 
    
        // depending on the type, check if the base is valid and set it accordingly
        const type = base.kty.toUpperCase();
        switch (type) {
            case TYPES.RSA:
                // generate a fingerprint for the base (also checks if the base is valid)
                this.#fingerprint = mA3PAKEkeyPairGen.RSA.generateFingerprint(base);
                log(`Fingerprint of RSA-type KPG base is:\n${this.#fingerprint}`);
                this.#type = type;
                // if base has no kid (e.g. the fingerprint), add it
                if (!base.kid) {
                    base.kid = this.#fingerprint;
                }
                log(`Added fingerprint to base.`);
                // \nBase:\n${JSON.stringify(base)}`);
                this.#base = base;
                break;
            // TODO: Add other types here...
            // case this.TYPES.NEW_TYPE:
            //     if (this.constructor.validateBaseNEW_TYPE(base)) {
            //         this.#base = base;
            //         this.#type = type;
            //     } else {
            //         throw new Error(errMsgInvalid("base") + base);
            //     } break;
            // default should never be reached, as the type is checked before
            default:
                throw new Error("This should never happen: Invalid type: " + type);
        }
    }
    // Generate a new key-pair from a passseed (password-derived seed)
    generateKeyPair(passseed) {
        const errMsgInvalid = mA3PAKEkeyPairGen.errMsgInvalid;
        const isSupportedBase = mA3PAKEkeyPairGen.isSupportedBase;
        const TYPES = mA3PAKEkeyPairGen.TYPES;
        const generateKeyPairRSA = mA3PAKEkeyPairGen.RSA.generateKeyPair;
        // check if the base is supported (a JWK object with kty in TYPES)
        if (!isSupportedBase(this.#base)) {
            throw new Error(errMsgInvalid("base") + this.#base);
        } // depending on the type, generate a new key-pair
        const type = this.#type;
        switch (type) {
            case TYPES.RSA:
                return generateKeyPairRSA(this.#base, passseed);
            // TODO: Add other types here...
            // case this.TYPES.NEW_TYPE:
            //     return await generateKeyPairNEW_TYPE(this.#base, passseed);
            default:
                throw new Error("This should never happen: Invalid type: " + type);
        }
    }
    // validate a key-pair (ssk and svk) against the key-pair generator base (KPG base)
    validateKeyPair(keyPair) {
        const errMsgInvalid = mA3PAKEkeyPairGen.errMsgInvalid;
        const isSupportedBase = this.constructor.isSupportedBase;
        const TYPES = this.constructor.TYPES;
        const validateKeyPairRSA = mA3PAKEkeyPairGen.RSA.validateKeyPair;
        // check if the base is supported (a JWK object with kty in TYPES)
        if (!isSupportedBase(this.#base)) {
            throw new Error(errMsgInvalid("base") + this.#base);
        } // depending on the type, validate the key-pair
        const type = this.#type;
        switch (type) {
            case TYPES.RSA:
                return validateKeyPairRSA(this.#base, keyPair);
            default:
                throw new Error("This should never happen: Invalid type: " + type);
        }
    }  
};

// defined default type for KPG
mA3PAKEkeyPairGen.TYPES.DEFAULT = mA3PAKEkeyPairGen.TYPES.RSA;

// RSA-based extension to the generic Key-pair Generator (KPG) Class,
// with static variables and methods for RSA-based KPG.
mA3PAKEkeyPairGen.RSA = { 
    // Name of this extension
    description: 'RSA-based Key-pair Generator (KPG)',
    // Custom string tag (name) for this class (displayed as the constructor name)
    get [Symbol.toStringTag]() {
        return this.description;
    },
    type: "RSA", // type name (used in TYPES and check functions)
    nBits: 1024, // default bitlength for RSA modulus n
    minRSA : 1024, // minimum bitlength for RSA modulus n
    hkdfInfo : 'RSA Exponent Derivation', // info string for HKDF
    pbkdf2Iter : 100000, // number of iterations for PBKDF2
    pnkdf2Hmac : 'SHA256', // HMAC for PBKDF2
    // Generates an error message for this extension
    errMsgInvalid(issue) { 
        return `Invalid ${issue} for mA3PAKEkeyPairGen.RSA: `;
    },
    // Checks if the type is supported (JWK with kty = RSA)
    isSupportedType(jwk){
        const errMsgInvalid = mA3PAKEkeyPairGen.RSA.errMsgInvalid;
        // check if the base is an object, else throw an error
        if (!(typeof jwk === 'object' || jwk instanceof Object)) {
            log("key is not an object in isSupportedType");
            throw new Error(errMsgInvalid("key (not an object)") + jwk);
        } 
        // check if the base has the JWK property 'kty' (key type), else throw an error
        if (!jwk.kty) {
            log("key has no kty in isSupportedType");
            throw new Error(errMsgInvalid("JWK (has no kty)") + jwk);
        }
        // check if this JWK has kty 'RSA', else throw an error
        if (!(jwk.kty.toUpperCase() === mA3PAKEkeyPairGen.RSA.type)) {
            throw new Error(errMsgInvalid("JWK (kty is not RSA)") + jwk);
        }
        // if all checks passed, return true
        return true;
    },
    // 
    isSafePrime(p, iterations = 5) {
        // Sophie Germain prime candidate
        const q = p.subtract(ONE).divide(TWO);
        // Check if candidate is prime
        const pIsSafePrime = q.millerRabin(iterations);
        return pIsSafePrime;
    },
    // Checks if a JWK is a valid RSA-based key-pair generator base (KPGB)
    // (has safe primes p and q)
    validateBase(base) {
        //log("In validateBase, now");
        const errMsgInvalid = mA3PAKEkeyPairGen.RSA.errMsgInvalid;
        const isSupportedType = mA3PAKEkeyPairGen.RSA.isSupportedType;
        const isSafePrime = mA3PAKEkeyPairGen.RSA.isSafePrime;
        // check if the base is supported (a JWK object with kty in TYPES)
        if (!isSupportedType(base)) {
            log("base is not a supported base in validateBase");
            throw new Error(errMsgInvalid("base") + base);
        } // convert p and q to BigInteger
        //log("base.p:", base.p);
        //log("base.q:", base.q);
        const p = base64urlToBigInteger(base.p);
        const q = base64urlToBigInteger(base.q);
        //log("p:", p.toString(10));
        //log("q:", q.toString(10));
        // check if p and q have sufficient length (at least minRSA / 2)
        const minPrimeLength = mA3PAKEkeyPairGen.RSA.minRSA / 2.1;
        //log("minPrimeLength:", minPrimeLength);
        const minPQLength = p.min(q).bitLength();
        //log("minPQLength:", minPQLength);
        if ( minPQLength < minPrimeLength ) {
            log("p or q too short in validateBase");
            throw new Error(errMsgInvalid("RSA base (p or q too short)") + base);
        } // check if p and q are safe primes
        if (!isSafePrime(p) || !isSafePrime(q)) {
            log("p or q no safe prime in validateBase");
            throw new Error(errMsgInvalid("RSA base (p or q no safe prime)") + base);
        } // if all checks passed, return true
        log("Base is valid.");
        return true;
    },
    deriveExponent (seed, nBits, seedEncoding = 'utf8') {
        const errMsgInvalid = mA3PAKEkeyPairGen.RSA.errMsgInvalid;
        const pbkdf2Iter = mA3PAKEkeyPairGen.RSA.pbkdf2Iter;
        const pbkdf2Hmac = mA3PAKEkeyPairGen.RSA.pbkdf2Hmac;

        const expBits = nBits - 1;
        let seed_buf;
        // convert seed to a Buffer or throw an error
        if (seed instanceof Uint8Array) {
            // Convert Uint8Array to Buffer
            seed_buf = Buffer.from(seed);
        } else // if seed is a Buffer, use it directly
        if (seed instanceof Buffer) {
            seed_buf = seed;
        } else // if seed is a string, convert it to a Buffer
        if (typeof seed === 'string' || seed instanceof String) {
            try {
                seed_buf = Buffer.from(seed, seedEncoding);
            } catch (err) {
                throw new Error(errMsgInvalid("seed or encoding") 
                    + "encoding: "+ seedEncoding + "\nseed: " + seed);
            }
        } else { // if seed is not a Buffer, Uint8Array or string, throw an error
            throw new Error(errMsgInvalid("seed type: " + typeof seed 
            + ", instance of: " + seed.constructor.name) + seed);
        } // PBKDF2 needs a salt buffer, so we use an empty buffer
        const empty = Buffer.alloc(0);
        // desired bit length is in bytes
        const bytes = Math.ceil(expBits / 8);
        // Expand the seed to the desired length using PBKDF2 (returns a bytes string)
        const expandedBytes = forge.pbkdf2(seed_buf, empty, pbkdf2Iter, bytes, pbkdf2Hmac);
        // Alternative to PBKDF2: expand seed to desired length using HKDF
        // HKDF needs an info string, so we use a constant string
        // const info = this.hkdfInfo;
        // const expanded = crypto.hkdfSync('sha256', buf, empty, info, bytes);
        // ...
        // Convert the bytes string to a BigInteger (via hex)
        let exp = new BigInteger(forge.util.bytesToHex(expandedBytes), 16);
        // Ensure the number is of the desired bit length
        const shiftBits = exp.bitLength() - expBits;
        exp = exp.shiftRight(shiftBits);
        log("exponent length is:", exp.bitLength(), "bits", 
                    "\nand should be:", expBits, "bits");
        // Ensure the number is odd
        exp = exp.or(ONE);
        return exp;
    },
    // Derive a RSA-based verifier exponent from a secret exponent s and the totient phi
    deriveVerifierExponent(s, phi) {
        if (!(s.gcd(phi).equals(ONE))) {
            throw new Error("Custom exponent is not coprime with (p-1)(q-1)");
        } // calculate the multiplicative inverse of s modulo phi
        const v = s.modInverse(phi);
        // if the inverse is zero, throw an error
        if (v.equals(ZERO)) {
            throw new Error("Invalid verifier key");
        }
        return v;
    },
    // Generates a new RSA-based secret signing / verifier key pair (ssk and svk),
    // based on a passseed (Unit8Array) and a RSA-type key-pair generator base (KPGB)
    generateKeyPair(base, passseed) {
        // generate a fingerprint for the base (also checks if the base is valid)
        const fingerprint = mA3PAKEkeyPairGen.RSA.generateFingerprint(base);
        // convert p and q to BigInteger
        const p = base64urlToBigInteger(base.p);
        const q = base64urlToBigInteger(base.q);
        const n = p.multiply(q); // RSA modulus n
        const phi = p.subtract(ONE).multiply(q.subtract(ONE)); // totient phi
        // Derive the RSA-based secret exponent s from the passseed
        const s = mA3PAKEkeyPairGen.RSA.deriveExponent(passseed, n.bitLength());
        // calculate the public exponent v
        const v = mA3PAKEkeyPairGen.RSA.deriveVerifierExponent(s, phi);
        // convert n, s and v to base64url and store them in JWKs ssk and svk
        const sBase64url = bigIntegerToBase64url(s);
        const vBase64url = bigIntegerToBase64url(v);
        const nBase64url = bigIntegerToBase64url(n);
        const ssk = {
            kty: 'RSA',
            alg: 'PS256',
            d: sBase64url,
            n: nBase64url,
            kid: fingerprint // note: this is a promise to the fingerprint
        };
        const svk = {
            kty: 'RSA',
            alg: 'PS256',
            e: vBase64url,
            n: nBase64url,
            kid: fingerprint // note: this is a promise to the fingerprint
        };
        // return the key-pair
        return {ssk, svk};
    },
    // Generates FingerPrint of a RSA-based key-pair generator base (KPGB)
    generateFingerprint(base) {
        log(`Now validating KPG base...`);
        const errMsgInvalid = mA3PAKEkeyPairGen.RSA.errMsgInvalid;
        // check if the base is supported (a JWK object with kty in TYPES)
        if (!mA3PAKEkeyPairGen.RSA.isSupportedType(base)) {
            log("base is not a supported base in generateFingerprint");
            log("base:", base);
            throw new Error(errMsgInvalid("base") + base);
        } // check if the base is a valid RSA-based KPGB (has safe primes p and q)
        if (!mA3PAKEkeyPairGen.RSA.validateBase(base)) {
            log("base is not a valid RSA-based KPGB (has safe primes p and q)");
            throw new Error(errMsgInvalid("RSA base (p or q no safe prime)") + base);
        }
        log(`Now generating fingerprint...`);
        // convert base64url p and q to BigInteger
        const p = base64urlToBigInteger(base.p);
        const q = base64urlToBigInteger(base.q);
        // calculate the modulus n
        const n = p.multiply(q);
        // Convert BigInteger n to a byte array
        const nBA = n.toByteArray();
        // Create a SHA-256 hash of the byte array
        const md = forge.md.sha256.create();
        md.update(nBA);
        const nHash = md.digest().toHex();
        // log(`Fingerprint:\n${nHash}`);
        // return the fingerprint
        return nHash;
    },
    // validate a RSA-based key (ssk or svk) against the RSA-based key-pair generator base (KPG base)
    async validateKey(base, key) {
        const errMsgInvalid = mA3PAKEkeyPairGen.RSA.errMsgInvalid;
        const isSupportedType = mA3PAKEkeyPairGen.RSA.isSupportedType;
        const validateBase = mA3PAKEkeyPairGen.RSA.validateBase;
        const minRSA = mA3PAKEkeyPairGen.RSA.minRSA;
        // check if the base is supported (a JWK kty = RSA)
        if (!isSupportedType(base)) {
            throw new Error(errMsgInvalid("base") + base);
        } // check if the key is supported (a JWK object with kty in TYPES)
        if (!isSupportedType(key)) {
            throw new Error(errMsgInvalid("key") + key);
        } // check if the base is a valid RSA-based KPGB
        try { 
            validateBase(base);
        } catch (err) {
            throw new Error(errMsgInvalid("RSA KPG base") + base);
        } // check if the key has any of the two exponents d or e
        if (!(key.d || key.e)) {
            throw new Error(errMsgInvalid("key (has no exponent)") + key);
        } // if both exponents are present, check if they are equal
        if (key.d && key.e && !(key.d === key.e)) {
            throw new Error(errMsgInvalid("key (has two unequal exponents)") + key);
        } // calculate the modulus n of the base and the key
        const p = base64urlToBigInteger(base.p);
        const q = base64urlToBigInteger(base.q); 
        const nBase = p.multiply(q); // calculated modulus n of the base
        const nKey = base64urlToBigInteger(key.n); // modulus n of the key
        // check if the modulus of the key is equal to the modulus of the base
        if (!nKey.equals(nBase)) { 
            throw new Error(errMsgInvalid("base or key (modulus mismatch)")
                                + "\nkey.n:" + key.n + "\nbase:" + base);
        }   // check the exponent length (s or v): longer than max(p, q),
        // but at least 1024 bits (length of p and q is checked in validateBaseRSA)
        const exp = base64urlToBigInteger(key.d || key.e);
        const maxPQ = p.max(q).bitLength();
        const minBits = maxPQ > minRSA ? maxPQ : minRSA;    
        if (!(exp.bitLength() >= minBits)) {
            throw new Error(errMsgInvalid("key (exponent is too short)") + key);
        } // if all checks passed, return true
        return true;
    },
    // validate a RSA-based key-pair (ssk and svk) against the RSA-based key-pair generator base (KPG base)
    validateKeyPair(base, keyPair) {
        const isSupportedType = mA3PAKEkeyPairGen.RSA.isSupportedType;
        const validateBase = mA3PAKEkeyPairGen.RSA.validateBase;
        const errMsgInvalid = mA3PAKEkeyPairGen.RSA.errMsgInvalid;
        const validateKey = mA3PAKEkeyPairGen.RSA.validateKey;
        // check if the base is supported (a JWK object with kty = RSA)
        if (!isSupportedType(base)) {
            throw new Error(errMsgInvalid("base") + base);
        } // check if the key-pair is supported (two JWK objects with kty = RSA)
        if (!(isSupportedType(keyPair.ssk) && isSupportedType(keyPair.svk))) {
            throw new Error(errMsgInvalid("key-pair") + keyPair);
        } // check if the base is a valid RSA-based KPGB
        try { 
            validateBase(base);
        } catch (err) {
            throw new Error(errMsgInvalid("RSA KPG base") + base);
        }  // check if both keys are valid RSA-based verifier or signing keys
        if (!validateKey(base, keyPair.ssk) || !validateKey(base, keyPair.svk)) {
            throw new Error(errMsgInvalid("key-pair (ssk or svk is invalid)") + keyPair);
        } // check if both keys have the same modulus n
        if (!(keyPair.ssk.n === keyPair.svk.n)) {
            throw new Error(errMsgInvalid("key-pair (modulus mismatch)") + keyPair);
        } // if both keys have a kid (e.g. the fingerprint), check if they are equal
        if (keyPair.ssk.kid && keyPair.svk.kid && !(keyPair.ssk.kid === keyPair.svk.kid)) {
            throw new Error(errMsgInvalid("key-pair (kid mismatch)") + keyPair);
        } // convert n, s and v to BigInteger
        const n = base64urlToBigInteger(base.n);
        const s = base64urlToBigInteger(keyPair.ssk.d);
        const v = base64urlToBigInteger(keyPair.svk.e);
        // check if the exponents of ssk and svk are multiplicative inverses modulo n
        const sTimesV = s.modMul(v, n);
        if (!(sTimesV.equals(ONE))) {
            throw new Error(errMsgInvalid("key-pair (s and v not multiplicative inverse)") 
                                                + keyPair);
        } // if all checks passed, return true
        return true;
    }
};

module.exports = mA3PAKEkeyPairGen;
