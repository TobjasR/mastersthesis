/**
 * This is a randomart generator that gets a hash value as input 
 * and generates a "random" looking ascii art image,
 * that can be used as a "fingerprint", 
 * e.g. for validating server public keys, as for initial SSH sessions.
 * @param {string} input - The input hash value to generate the fingerprint from.
 * @returns {string} - The generated fingerprint as an ASCII art image.
 */
const XLIM = 17; // X-axis limit
const YLIM = 9; // Y-axis limit
const ARSZ = XLIM * YLIM; // Array size
// Array of symbols used to generate the fingerprint
const symbols = [' ', '.', 'o', '+', '=', '*', 'B', 'O', 'X', 
                      '@', '%', '&', '#', '/', '^', 'S', 'E']; 
let array = new Array(ARSZ).fill(0); // Initialize an array of size ARSZ with 0s
// Generates the ASCII art image by printing the symbols in the array
function printGraph() {
    let result = "+--[ RandomArt ]--+\n";
    for (let i = 0; i < YLIM; i++) {
        result += "|";
        for (let j = 0; j < XLIM; j++) {
            result += symbols[array[j + XLIM * i]];
        }
        result += "|\n";
    }
    result += "+-----------------+\n";
    return result;
}
// Checks if a character is a hexadecimal character
function isHex(c) {
    const hexRegex = /^[0-9a-fA-F]$/;
    return hexRegex.test(c);
}
// Convert hexadecimal character to its decimal value
function hexVal(c) {
    return parseInt(c, 16);
}
// Convert hex string to an array of decimal values
function convertString(arg) {
    let string = [];
    for (let i = 0; i < arg.length; i += 2) {
        if (!isHex(arg[i]) || !isHex(arg[i + 1])) {
            throw new Error("Unrecognized character");
        }
        string.push((hexVal(arg[i]) << 4) | hexVal(arg[i + 1]));
    }
    return string;
}
// Calculate the new position of the drunken walk
// depending on the current position and direction 
function new_position(pos, direction) {
    let x0 = pos % XLIM;
    let y0 = Math.floor(pos / XLIM);
    let x1, y1;
    switch (direction) {
        case 0: x1 = x0 - 1; y1 = y0 - 1; break; // NW
        case 1: x1 = x0 + 1; y1 = y0 - 1; break; // NE
        case 2: x1 = x0 - 1; y1 = y0 + 1; break; // SW
        case 3: x1 = x0 + 1; y1 = y0 + 1; break; // SE
        default: x1 = x0; y1 = y0; break;
    }
    x1 = Math.max(0, Math.min(XLIM - 1, x1));
    y1 = Math.max(0, Math.min(YLIM - 1, y1));
    return y1 * XLIM + x1;
}
// Perform the drunken walk guided by the input (hex) string
// and increment the array at the new position
function drunken_walk(inputString) {
    let pos = 76; // Starting position
    const string = convertString(inputString);
    for (let idx = 0; idx < string.length; idx++) {
        let temp = string[idx];
        for (let i = 0; i < 4; i++) {
            const newPos = new_position(pos, temp & 3);
            if (newPos !== pos) {
                array[newPos]++;
            }
            pos = newPos;
            temp >>= 2;
        }
    }
    array[pos] = 16; // End ('E')
    array[76] = 15; // Start ('S')
}
// generate the fingerprint of a hash value (hex string)
// and print it as a random ASCII art image
function generateFingerprintRandomart(hash) {
    drunken_walk(hash);
    return printGraph();
}

module.exports = generateFingerprintRandomart;
