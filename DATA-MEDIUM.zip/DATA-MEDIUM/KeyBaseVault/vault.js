const express = require('express');
const forge = require('node-forge');
const BigInteger = forge.jsbn.BigInteger;

const generateRSAKeyBase = require('../utils/generateRSAKeyBase');
const constructKeyBlob = require('../utils/constructKeyBlob');
const hashWithSHA256 = require('../utils/hashWithSHA256');
const deriveVerifierKey = require('../utils/deriveVerifierKey');

const app = express();
const port = 3000;
const numbersystem = 10;
const rsaBitLength = 256;
let keyBase = null;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
// Serve static files from the 'public' directory
app.use(express.static('public'));
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/public/index.html');
});

app.post('/generateKeyBase', (req, res) => {
    keyBase = generateRSAKeyBase(rsaBitLength);
    const keyBaseJWK = {
        kty: 'RSA',
        n: keyBase.n.toString(numbersystem),
        p: keyBase.p.toString(numbersystem),
        q: keyBase.q.toString(numbersystem)
    };
    const n_buf = Buffer.from(forge.util.hexToBytes(keyBase.n.toString(16)));
    const hashedModulus = hashWithSHA256(n_buf);
    res.json({ keyBaseJWK, hashedModulus });
});
app.post('/deriveVerifierKey', (req, res) => {
    const d = new BigInteger(req.body.exponent, numbersystem);
    console.log("recieved d:", d.toString(numbersystem));
    const n = keyBase.n;
    const phi = keyBase.phi;
    e = deriveVerifierKey(d, phi);
    console.log("derived e:", e.toString(numbersystem));
    const verifierKey = {
        kty: 'RSA',
        n: n.toString(numbersystem),
        d: d.toString(numbersystem),
        e: e.toString(numbersystem)
    };
    const verifierKeyBlob = constructKeyBlob(n, e);
    const hashedVerifierKey = hashWithSHA256(verifierKeyBlob);
    console.log("hashed verifier key (n, e):", hashedVerifierKey);
    res.json({ verifierKey, hashedVerifierKey });
});
app.listen(port, () => {
    console.log(`App listening at http://localhost:${port}`);
});
