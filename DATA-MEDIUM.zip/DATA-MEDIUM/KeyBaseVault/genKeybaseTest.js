const forge = require('node-forge');
const BigInteger = forge.jsbn.BigInteger;
const generateRSAKeyBase = require('../utils/generateRSAKeyBase');
const recoverPQ = require('../utils/recoverPQ');
const { base64urlToBigInt, bigintToBase64url } = require('../utils/base64url_BigInt.js');

const ONE = BigInteger.ONE;
const THREE = new BigInteger("3");

const rsaBitLength = 256;

let keyBase = null;

keyBase = generateRSAKeyBase(rsaBitLength);
const n = keyBase.n;
const phi = keyBase.phi;
const d = phi.subtract(THREE);
console.log(`d: ${d.toString(10)}`);
if (d.gcd(phi).compareTo(ONE) !== 0) {
    throw new Error("Custom exponent is not coprime with (p-1)(q-1)");
}
const e = d.modInverse(phi);
console.log(`e: ${e.toString(10)}`);
try {
    let startTime = process.hrtime();
    const [p, q] = recoverPQ(keyBase.n, e, d);
    let elapsedTime = process.hrtime(startTime);
    console.log(`Elapsed time for recoverPQ: ${elapsedTime[0]}s ${elapsedTime[1] / 1e6}ms`);
    console.log("p:", p.toString(10));
    console.log("q:", q.toString(10));
} catch (error) {
    console.error(error.message);
}
return(0);