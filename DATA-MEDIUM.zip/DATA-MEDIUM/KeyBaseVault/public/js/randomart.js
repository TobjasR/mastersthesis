function randomart(input) {
    const XLIM = 17;
    const YLIM = 9;
    const ARSZ = XLIM * YLIM;
    
    const symbols = [
        ' ', '.', 'o', '+', '=', '*', 'B', 'O', 'X', '@', '%', '&', '#', '/', '^', 'S', 'E'
    ];
    
    let array = new Array(ARSZ).fill(0);
    
    function printGraph() {
        let result = "+-[ Fingerprint ]-+\n";
        for (let i = 0; i < YLIM; i++) {
            result += "|";
            for (let j = 0; j < XLIM; j++) {
                result += symbols[array[j + XLIM * i]];
            }
            result += "|\n";
        }
        result += "+-----------------+\n";
        return result;
    }
    
    function isHex(c) {
        const hexRegex = /^[0-9a-fA-F]$/;
        return hexRegex.test(c);
    }
    
    function hexVal(c) {
        return parseInt(c, 16);
    }
    
    function convertString(arg) {
        let string = [];
        for (let i = 0; i < arg.length; i += 2) {
            if (!isHex(arg[i]) || !isHex(arg[i + 1])) {
                throw new Error("Unrecognized character");
            }
            string.push((hexVal(arg[i]) << 4) | hexVal(arg[i + 1]));
        }
        return string;
    }
    
    function new_position(pos, direction) {
        let x0 = pos % XLIM;
        let y0 = Math.floor(pos / XLIM);
        let x1, y1;
    
        switch (direction) {
            case 0: x1 = x0 - 1; y1 = y0 - 1; break; // NW
            case 1: x1 = x0 + 1; y1 = y0 - 1; break; // NE
            case 2: x1 = x0 - 1; y1 = y0 + 1; break; // SW
            case 3: x1 = x0 + 1; y1 = y0 + 1; break; // SE
            default: x1 = x0; y1 = y0; break;
        }
    
        x1 = Math.max(0, Math.min(XLIM - 1, x1));
        y1 = Math.max(0, Math.min(YLIM - 1, y1));
    
        return y1 * XLIM + x1;
    }
    
    function drunken_walk(inputString) {
        let pos = 76;
        const string = convertString(inputString);
    
        for (let idx = 0; idx < string.length; idx++) {
            let temp = string[idx];
            for (let i = 0; i < 4; i++) {
                const newPos = new_position(pos, temp & 3);
                if (newPos !== pos) {
                    array[newPos]++;
                }
                pos = newPos;
                temp >>= 2;
            }
        }
    
        array[pos] = 16; // End
        array[76] = 15; // Start
    }
    drunken_walk(input);
    return printGraph();
}
