async function generateKeyBase() {
	const response = await fetch('/generateKeyBase', { method: 'POST' });
	const data = await response.json();
	document.getElementById('keyBaseHash').innerHTML = data.hashedModulus;
	document.getElementById('keyBaseFingerprint').innerHTML = randomart(data.hashedModulus);
	document.getElementById('n').innerHTML = data.keyBaseJWK.n;
	document.getElementById('p').innerHTML = data.keyBaseJWK.p;
	document.getElementById('q').innerHTML = data.keyBaseJWK.q;
}
