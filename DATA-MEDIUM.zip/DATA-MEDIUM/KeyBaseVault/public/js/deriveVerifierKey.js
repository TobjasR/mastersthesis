async function deriveVerifierKey() {
	const exponent = document.getElementById('signingKey').value;
	const response = await fetch('/deriveVerifierKey', {
		method: 'POST',
		headers: {
			'Content-Type': 'application/json'
		},
		body: JSON.stringify({ exponent })
	});
	const data = await response.json();
	document.getElementById('verifierKeyHash').innerHTML =  data.hashedVerifierKey;
	document.getElementById('verifierKeyFingerprint').innerHTML =  randomart(data.hashedVerifierKey);
	document.getElementById('e').innerHTML =  data.verifierKey.e;
	document.getElementById('d').innerHTML =  data.verifierKey.d;
}
