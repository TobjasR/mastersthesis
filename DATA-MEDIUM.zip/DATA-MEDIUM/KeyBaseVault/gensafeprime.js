const NodeRSA = require('node-rsa');
const { Worker, isMainThread, parentPort } = require('worker_threads');

// Function to generate RSA key and extract primes
function generateKeyAndExtractPrimes() {
    const key = new NodeRSA({b: 2048});
    const privateKeyComponents = key.exportKey('components-private');
    return { p: privateKeyComponents.p, q: privateKeyComponents.q };
}

// Function to check if a number is a safe prime
function isSafePrime(num, callback) {
    if (isMainThread) {
        const worker = new Worker(__filename, { workerData: num });
        worker.on('message', callback);
        worker.on('error', (err) => { throw err; });
    } else {
        const n = BigInt(workerData);
        const result = (n % 2n === 0n) ? false : true; // Add your safe prime check logic here
        parentPort.postMessage(result);
    }
}

// Main function
function main() {
    let { p, q } = generateKeyAndExtractPrimes();

    // Check if p is a safe prime
    isSafePrime(p, (isPPrime) => {
        if (!isPPrime) {
            console.log('p is not a safe prime. Regenerating...');
            return main();
        }

        // Check if q is a safe prime
        isSafePrime(q, (isQPrime) => {
            if (!isQPrime) {
                console.log('q is not a safe prime. Regenerating...');
                return main();
            }

            console.log('Both p and q are safe primes!');
            console.log('p:', p.toString(16));
            console.log('q:', q.toString(16));
        });
    });
}

main();

