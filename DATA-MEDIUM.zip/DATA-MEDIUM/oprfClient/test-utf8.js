
let input = "ꭈ瑣芧ꁚ靶蟖톰 鱭ᅎ鑆 녛뚊鴕署";
    try {
        const buffer = Buffer.from(input, 'utf8');
        let bool = (buffer.toString('utf8') === input) && (input.length === 16);
        console.log("UTF-8: " + bool);
    } catch (err) {
        console.log("UTF-8: " + err.message);
    }